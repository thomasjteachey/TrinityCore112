-- CENTURION_CharacterPane - CharacterPane.lua
-- Custom character pane stat tweaks for your 3.3.5a client.
--
-- Key goals:
--  1) Avoid combat taint by NOT redefining secure FrameXML globals
--     (notably PDFITEMFLYOUT_*).
--  2) Provide custom hit displays that use BCS helper parsing.
--  3) Add a 6th "Speed" stat only on Base Stats.

BCS = BCS or {}
BCSConfig = BCSConfig or {}

local L = BCS.L

-- Local mirrors of Blizzard UI strings/constants (no global assignment)
local MELEE_HIT_CHANCE = _G.MELEE_HIT_CHANCE or "Hit Chance"
local SPELL_HIT_CHANCE = _G.SPELL_HIT_CHANCE or "Hit Chance"
local SPELL_CRIT_CHANCE = _G.SPELL_CRIT_CHANCE or "Spell Crit Chance"
local SPELL_PENETRATION = _G.SPELL_PENETRATION or _G.SPELL_PENETRATION_LABEL or "Penetration"
local STAT_FORMAT = _G.STAT_FORMAT or "%s"
local PAPERDOLLFRAME_TOOLTIP_FORMAT = _G.PAPERDOLLFRAME_TOOLTIP_FORMAT or "%s"
local HIGHLIGHT_FONT_COLOR_CODE = _G.HIGHLIGHT_FONT_COLOR_CODE or ""
local FONT_COLOR_CODE_CLOSE = _G.FONT_COLOR_CODE_CLOSE or ""

-- Localize common globals
local format = string.format
local max = math.max

local UnitClass = UnitClass
local GetNumTalentTabs = GetNumTalentTabs
local GetNumTalents = GetNumTalents
local GetTalentInfo = GetTalentInfo
local GetSpellPenetration = GetSpellPenetration
local UnitAura = UnitAura
local CreateFrame = CreateFrame

-- Returns flat % from the Mage talent Runic Precision (2% per rank, 6% at 3/3).
local function BCS_GetRunicPrecisionBonus()
    local _, classToken = UnitClass("player")
    if classToken ~= "MAGE" then return 0 end
    if GetNumTalentTabs and GetTalentInfo then
        local perRank = 1
        for tab = 1, GetNumTalentTabs() do
            for i = 1, GetNumTalents(tab) do
                local name, _, _, _, rank = GetTalentInfo(tab, i)
                if name == "Runic Precision" then
                    return (rank or 0) * perRank
                end
            end
        end
    end
    -- Fallback: passive known as spell id 12840 on this server for rank 3
    if (IsPlayerSpell and IsPlayerSpell(12840)) or (IsSpellKnown and IsSpellKnown(12840)) then
        return 6
    end
    return 0
end


-- === Spell Penetration (Classic ruleset friendly) ===
-- On many Classic-ruleset servers running the 3.3.5 client, spell penetration isn't tracked
-- as a real PaperDoll stat. Instead it comes from passive auras and/or "Equip:" tooltip lines
-- like: "Decreases the magical resistances of your spell targets by X.".
-- We compute it ourselves and only fall back to GetSpellPenetration() if we find nothing.

local function BCS_GetSpellPenScanTooltip()
    if not CreateFrame then return nil end
    if not _G.BCS_SpellPenScanTooltip then
        CreateFrame("GameTooltip", "BCS_SpellPenScanTooltip", UIParent, "GameTooltipTemplate")
        _G.BCS_SpellPenScanTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    end
    return _G.BCS_SpellPenScanTooltip
end

-- Parse "spell penetration" style lines from a tooltip.
-- Must catch both Classic-style "Equip: Decreases the magical resistances... by X"
-- and enchant/stat lines like ".../Spell Penetration +11".
local function BCS_ParseSpellPenFromTooltip(tip)
    if not tip or not tip.NumLines then return 0 end
    local total = 0
    for i = 1, tip:NumLines() do
        local line = _G["BCS_SpellPenScanTooltipTextLeft" .. i]
        local txt = line and line:GetText()
        if txt and txt ~= "" then
            -- 1) Classic aura/equip text variants
            local v =
                txt:match("Decreases the magical resistances of your spell targets by%s+([%-]?%d+)")
                or txt:match("Decreases the magical resistances of your spell target by%s+([%-]?%d+)")
                or txt:match("Decreases the magical resistances of spell targets by%s+([%-]?%d+)")
                or txt:match("Decreases the magical resistance[s]? of your spell targets by%s+([%-]?%d+)")
                or txt:match("Reduces the target's magical resistances? against your spells by%s+([%-]?%d+)")
            if v then
                total = total + (tonumber(v) or 0)
            end

            -- 2) Enchant / stat lines (e.g. "+Healing.../Spell Penetration +11")
            -- Match the number that appears after "Spell Penetration" on the line.
            local v2 =
                txt:match("Spell%s+Penetration:?%s*%+?%s*([%-]?%d+)")
                or txt:match("/Spell%s+Penetration:?%s*%+?%s*([%-]?%d+)")
            if v2 then
                total = total + (tonumber(v2) or 0)
            end

            -- 3) Last-resort: some servers just use "Penetration +X" on enchants
            -- Avoid double-counting if the line already matched "Spell Penetration" above.
            local v3 = (not v2) and txt:match("Penetration:?%s*%+?%s*([%-]?%d+)") or nil
            if v3 then
                total = total + (tonumber(v3) or 0)
            end
        end
    end
    return total
end

local function BCS_GetSpellPenetrationFromItems()
    local tip = BCS_GetSpellPenScanTooltip()
    if not tip then return 0 end

    local total = 0
    for slot = 1, 19 do
        tip:ClearLines()
        local ok = false

        if tip.SetInventoryItem then
            ok = tip:SetInventoryItem("player", slot) and true or false
        end

        if (not ok) and GetInventoryItemLink and tip.SetHyperlink then
            local link = GetInventoryItemLink("player", slot)
            if link and link ~= "" then
                tip:ClearLines()
                tip:SetHyperlink(link)
                ok = true
            end
        end

        if ok then
            total = total + (BCS_ParseSpellPenFromTooltip(tip) or 0)
        end
    end

    return total
end

function PaperDollFrame_SetSpellPenetration(statFrame)
    if not statFrame then return end

    local label = _G[statFrame:GetName().."Label"]
    local text  = _G[statFrame:GetName().."StatText"]

    if label then
        label:SetText(format(STAT_FORMAT, SPELL_PENETRATION))
    end

    -- For Classic rulesets: treat "spell pen" as an item-derived value and compute
    -- it purely from equipped item tooltips (includes enchants).
    local pen = BCS_GetSpellPenetrationFromItems() or 0

    local display = format("%d", pen)
    if text then text:SetText(display) end

    statFrame.tooltip = HIGHLIGHT_FONT_COLOR_CODE
        .. format(PAPERDOLLFRAME_TOOLTIP_FORMAT, SPELL_PENETRATION) .. " " .. display
        .. FONT_COLOR_CODE_CLOSE
    statFrame.tooltip2 = "Reduces the target's magical resistances against your spells by this amount."
end

-- === Movement Speed (Base Stats only) ===
local BCS_BASE_RUN_SPEED = 7 -- yards/second baseline for 100% run

function PaperDollFrame_SetMovementSpeed(statFrame)
    if not statFrame then return end
    local label = _G[statFrame:GetName().."Label"]
    local text  = _G[statFrame:GetName().."StatText"]

    -- Capture all returns in one call (older clients may return fewer values)
    local a,b,c,d = 0,0,0,0
    if GetUnitSpeed then a,b,c,d = GetUnitSpeed("player") end
    local cur, run, flight, swim = a or 0, b or 0, c or 0, d or 0
    if run == 0 then run = cur end

    local base = (BCS_BASE_RUN_SPEED and BCS_BASE_RUN_SPEED > 0) and BCS_BASE_RUN_SPEED or 7
    local best = max(run or 0, flight or 0, swim or 0, cur or 0)
    local pct  = (best > 0 and (best / base) * 100) or 0

    -- Cache last non-zero so mount idle doesn't show 0%
    if pct == 0 and statFrame.__lastSpeedPct and statFrame:IsShown() then
        pct = statFrame.__lastSpeedPct
    elseif pct > 0 then
        statFrame.__lastSpeedPct = pct
    end

    local display = format("%.0f%%", pct)
    if label then label:SetText(format(STAT_FORMAT, "Speed")) end
    if text then text:SetText(display) end

    local tip = HIGHLIGHT_FONT_COLOR_CODE..format(PAPERDOLLFRAME_TOOLTIP_FORMAT, "Speed").." "..display..FONT_COLOR_CODE_CLOSE
    statFrame.tooltip = tip
end

-- === Custom Hit Stats ===

function PaperDollFrame_SetSpellHitChance(statFrame)
    _G[statFrame:GetName().."Label"]:SetText(format(STAT_FORMAT, SPELL_HIT_CHANCE));
    local text = _G[statFrame:GetName().."StatText"];

    -- Total spell hit from items + talents (parsed by BCS)
    local total = BCS:GetSpellHitRating() or 0;

    local display = format("%.2f%%", total);
    text:SetText(display);
    statFrame.tooltip = HIGHLIGHT_FONT_COLOR_CODE
        .. format(PAPERDOLLFRAME_TOOLTIP_FORMAT, SPELL_HIT_CHANCE) .. " " .. display
        .. FONT_COLOR_CODE_CLOSE;
end


function PaperDollFrame_SetMeleeHitChance(statFrame)
	_G[statFrame:GetName().."Label"]:SetText(format(STAT_FORMAT, MELEE_HIT_CHANCE));
	local text = _G[statFrame:GetName().."StatText"];
	local hitChance = BCS:GetHitRating() or 0;
	hitChance = format("%.2f%%", hitChance);
	text:SetText(hitChance);
	statFrame.tooltip = HIGHLIGHT_FONT_COLOR_CODE..format(PAPERDOLLFRAME_TOOLTIP_FORMAT, MELEE_HIT_CHANCE).." "..hitChance..FONT_COLOR_CODE_CLOSE;
end

function PaperDollFrame_SetRangedHitChance(statFrame)
	_G[statFrame:GetName().."Label"]:SetText(format(STAT_FORMAT, MELEE_HIT_CHANCE));
	local text = _G[statFrame:GetName().."StatText"];
	local hitChance = BCS:GetRangedHitRating() or 0;
	hitChance = format("%.2f%%", hitChance);
	text:SetText(hitChance);
	statFrame.tooltip = HIGHLIGHT_FONT_COLOR_CODE..format(PAPERDOLLFRAME_TOOLTIP_FORMAT, MELEE_HIT_CHANCE).." "..hitChance..FONT_COLOR_CODE_CLOSE;
end


-- === Server-matched Primary Stat Tooltip Breakdown ===
-- Your server modifies primary stat contributions. The default client tooltip breakdown
-- (PaperDollFrame_SetStat) will be wrong. We override statFrame.tooltip2 for base stats
-- using the formulas in your server source (TrinityCore-style).
--
-- NOTE: This only changes the *tooltip breakdown lines* on hover. The actual displayed AP/Block/etc
-- values still come from server unit fields.
local function CP_GetClassIdAndToken()
    local _, classToken = UnitClass("player")
    classToken = classToken and string.upper(classToken) or ""
    local classIdByToken = {
        WARRIOR = 1,
        PALADIN = 2,
        HUNTER = 3,
        ROGUE = 4,
        PRIEST = 5,
        DEATHKNIGHT = 6,
        SHAMAN = 7,
        MAGE = 8,
        WARLOCK = 9,
        DRUID = 11,
    }
    return classIdByToken[classToken] or 0, classToken
end

local function CP_Server_APFromStr(effectiveStr, classToken)
    -- Mirrors Player::UpdateAttackPowerAndDamage(false) stat contribution terms.
    if classToken == "WARRIOR" or classToken == "PALADIN" or classToken == "DEATHKNIGHT" or classToken == "SHAMAN" or classToken == "DRUID" then
        return max(0, effectiveStr * 2 - 20)
    end
    -- Rogue/Hunter/Mage/Priest/Warlock: STR contributes 1 AP per STR over 10
    return max(0, effectiveStr - 10)
end

local function CP_Server_APFromAgi(effectiveAgi, classToken)
    -- Mirrors Player::UpdateAttackPowerAndDamage(false) agi terms (melee AP).
    if classToken == "ROGUE" or classToken == "HUNTER" then
        return max(0, effectiveAgi - 10)
    end
    -- Druids get AP from AGI in Cat (feral) in server code, but the character pane base stat tooltip
    -- is used in all forms; we keep it conservative and show 0 unless you request form-specific.
    return 0
end

local function CP_Server_BlockValueFromStr(effectiveStr)
    -- Mirrors Player::GetShieldBlockValue(): + STR/20.0f
    return math.floor((effectiveStr / 20.0) + 1e-6)
end

local function CP_Server_MeleeCritFromAgiPct(effectiveAgi, classToken)
    -- Mirrors Player::GetMeleeCritFromAgility()
    if classToken == "ROGUE" then
        return effectiveAgi / 29.0
    elseif classToken == "HUNTER" then
        return effectiveAgi / 53.0
    else
        return effectiveAgi / 20.0
    end
end

local function CP_Server_HealthFromStam(effectiveStam)
    -- Mirrors Player::GetHealthBonusFromStamina()
    local baseStam = math.min(20, effectiveStam)
    local moreStam = effectiveStam - baseStam
    return baseStam + (moreStam * 10.0)
end

local function CP_Server_ManaFromInt(effectiveInt)
    -- Mirrors Player::GetManaBonusFromIntellect()
    local baseInt = math.min(20, effectiveInt)
    local moreInt = effectiveInt - baseInt
    return baseInt + (moreInt * 15.0)
end

local function CP_Server_SpellCritFromIntPct(effectiveInt, classId, level)
    -- Mirrors Player::GetSpellCritFromIntellect()
    local critData = {
        -- [classId] = { base, rate0, rate1 }
        [2]  = { 3.70, 14.77, 0.65 }, -- paladin
        [5]  = { 2.97, 10.03, 0.82 }, -- priest
        [7]  = { 3.54, 11.51, 0.80 }, -- shaman
        [8]  = { 3.70, 14.77, 0.65 }, -- mage
        [9]  = { 3.18, 11.30, 0.82 }, -- warlock
        [11] = { 3.33, 12.41, 0.79 }, -- druid
        -- others are 0/0/10 in your server file; treat as 0 contribution here
    }
    local row = critData[classId]
    if not row then return 0 end
    local base, rate0, rate1 = row[1], row[2], row[3]
    local denom = (rate0 or 0) + (rate1 or 0) * (level or 1)
    if denom <= 0 then return 0 end
    return base + (effectiveInt / denom)
end

local function CP_OverridePrimaryStatTooltip(statFrame, statIndex)
    if not statFrame or not statIndex then return end

    local _, effective = UnitStat("player", statIndex)
    effective = effective or 0
    local classId, classToken = CP_GetClassIdAndToken()
    local level = UnitLevel and UnitLevel("player") or 1

    local lines = {}

    if statIndex == 1 then
        local ap = CP_Server_APFromStr(effective, classToken)
        table.insert(lines, format("Increases Attack Power by %d.", ap))

        if classToken == "WARRIOR" or classToken == "SHAMAN" or classToken == "PALADIN" then
            local bv = CP_Server_BlockValueFromStr(effective)
            table.insert(lines, format("Increases Block Value by %d.", bv))
        end

    elseif statIndex == 2 then
        local ap = CP_Server_APFromAgi(effective, classToken)
        local crit = CP_Server_MeleeCritFromAgiPct(effective, classToken)
        local armor = effective * 2

        if ap > 0 then
            table.insert(lines, format("Increases Attack Power by %d.", ap))
        end
        table.insert(lines, format("Increases Crit Chance by %.2f%%.", crit))
        table.insert(lines, format("Increases Armor by %d.", armor))

    elseif statIndex == 3 then
        local hp = CP_Server_HealthFromStam(effective)
        if GetUnitMaxHealthModifier then
            hp = hp * (GetUnitMaxHealthModifier("player") or 1)
        end
        table.insert(lines, format("Increases Health by %d.", math.floor(hp + 0.5)))

    elseif statIndex == 4 then
        if UnitHasMana and UnitHasMana("player") then
            local mana = CP_Server_ManaFromInt(effective)
            table.insert(lines, format("Increases Mana by %d.", math.floor(mana + 0.5)))

            local spellCrit = CP_Server_SpellCritFromIntPct(effective, classId, level)
            if spellCrit and spellCrit > 0 then
                table.insert(lines, format("Increases Spell Crit Chance by %.2f%%.", spellCrit))
            end
        else
            -- no mana -> keep whatever client set (usually nil)
            return
        end
    elseif statIndex == 5 then
        -- Spirit varies a lot across rulesets; keep the client default (regen APIs mirror DBCs).
        return
    end

    if #lines > 0 then
        statFrame.tooltip2 = table.concat(lines, "\n")
    end
end

-- === PaperDoll stats layout override ===
-- Adds a 6th stat slot only for Base Stats to display Speed.
function UpdatePaperdollStats(prefix, index)
	local stat1 = _G[prefix..1];
	local stat2 = _G[prefix..2];
	local stat3 = _G[prefix..3];
	local stat4 = _G[prefix..4];
	local stat5 = _G[prefix..5];
	local stat6 = _G[prefix..6];

	-- reset any OnEnter scripts that may have been changed
	stat1:SetScript("OnEnter", PaperDollStatTooltip);
	stat2:SetScript("OnEnter", PaperDollStatTooltip);
	stat4:SetScript("OnEnter", PaperDollStatTooltip);

	stat6:Show();

	if ( index == "PLAYERSTAT_BASE_STATS" ) then
		PaperDollFrame_SetStat(stat1, 1);
		PaperDollFrame_SetStat(stat2, 2);
		PaperDollFrame_SetStat(stat3, 3);
		PaperDollFrame_SetStat(stat4, 4);
		PaperDollFrame_SetStat(stat5, 5);

        -- Override base stat tooltip breakdowns to match server formulas
        CP_OverridePrimaryStatTooltip(stat1, 1);
        CP_OverridePrimaryStatTooltip(stat2, 2);
        CP_OverridePrimaryStatTooltip(stat3, 3);
        CP_OverridePrimaryStatTooltip(stat4, 4);
        CP_OverridePrimaryStatTooltip(stat5, 5);

        -- Movement Speed shown only on Base Stats (stat6)
        stat6:Show();
        PaperDollFrame_SetMovementSpeed(stat6);

        -- Refresh when speed-affecting changes happen
        if stat6.UnregisterAllEvents then stat6:UnregisterAllEvents() end
        if stat6.RegisterEvent then
            stat6:RegisterEvent("PLAYER_ENTERING_WORLD");
            stat6:RegisterEvent("UNIT_AURA");
            stat6:RegisterEvent("PLAYER_AURAS_CHANGED");
            stat6:RegisterEvent("UNIT_SPEED");
        end
        stat6:SetScript("OnEvent", function(self, event, unit)
            if (event == "UNIT_AURA" or event == "UNIT_SPEED") and unit and unit ~= "player" then return end
            PaperDollFrame_SetMovementSpeed(self);
        end);
        stat6:SetScript("OnUpdate", function(self, elapsed)
            self.__acc = (self.__acc or 0) + elapsed;
            if self.__acc > 0.25 then self.__acc = 0; PaperDollFrame_SetMovementSpeed(self); end
        end);

	elseif ( index == "PLAYERSTAT_MELEE_COMBAT" ) then
		PaperDollFrame_SetDamage(stat1);
		stat1:SetScript("OnEnter", CharacterDamageFrame_OnEnter);
		PaperDollFrame_SetAttackSpeed(stat2);
		PaperDollFrame_SetAttackPower(stat3);
		PaperDollFrame_SetMeleeHitChance(stat4);
		stat4.tooltip2 = "You need 5.0% hit to be hit capped for PvP.";
		PaperDollFrame_SetMeleeCritChance(stat5);

        -- Clear/hide Base Stats extra slot
        if stat6.UnregisterAllEvents then stat6:UnregisterAllEvents() end
        stat6:SetScript("OnEvent", nil);
        stat6:SetScript("OnUpdate", nil);
        _G[stat6:GetName().."Label"]:SetText("");
        _G[stat6:GetName().."StatText"]:SetText("");
        stat6:Hide();

	elseif ( index == "PLAYERSTAT_RANGED_COMBAT" ) then
		PaperDollFrame_SetRangedDamage(stat1);
		stat1:SetScript("OnEnter", CharacterRangedDamageFrame_OnEnter);
		PaperDollFrame_SetRangedAttackSpeed(stat2);
		PaperDollFrame_SetRangedAttackPower(stat3);
		PaperDollFrame_SetRangedHitChance(stat4);
		stat4.tooltip2 = "You need 5.0% hit to be hit capped for PvP. 9.0% for rogues with Heightened Senses.";
		PaperDollFrame_SetRangedCritChance(stat5);

        if stat6.UnregisterAllEvents then stat6:UnregisterAllEvents() end
        stat6:SetScript("OnEvent", nil);
        stat6:SetScript("OnUpdate", nil);
        _G[stat6:GetName().."Label"]:SetText("");
        _G[stat6:GetName().."StatText"]:SetText("");
        stat6:Hide();

	elseif ( index == "PLAYERSTAT_SPELL_COMBAT" ) then
		PaperDollFrame_SetSpellBonusDamage(stat1);
		stat1:SetScript("OnEnter", CharacterSpellBonusDamage_OnEnter);
		PaperDollFrame_SetSpellBonusHealing(stat2);
		PaperDollFrame_SetSpellHitChance(stat3);
		stat3.tooltip2 = "You need 3.0% hit to be hit capped for PvP. 7.0% for rogues with Heightened Senses. For spells, there is always an unavoidable 1% chance to miss.";
		PaperDollFrame_SetSpellCritChance(stat4);

		-- Use a single combined tooltip (no school-by-school breakdown)
		stat4:SetScript("OnEnter", PaperDollStatTooltip);
		stat4:SetScript("OnLeave", GameTooltip_Hide);
		do
			local critText = "";
			local st = _G[stat4:GetName().."StatText"];
			if st and st.GetText then critText = st:GetText() or "" end
			stat4.tooltip = HIGHLIGHT_FONT_COLOR_CODE
				.. format(PAPERDOLLFRAME_TOOLTIP_FORMAT, SPELL_CRIT_CHANCE) .. " " .. critText
				.. FONT_COLOR_CODE_CLOSE;
			stat4.tooltip2 = nil;
		end
		PaperDollFrame_SetManaRegen(stat5);


		-- Spell Penetration at the bottom (Classic ruleset: computed from items/auras)
		stat6:Show();
		PaperDollFrame_SetSpellPenetration(stat6);

		-- Refresh when gear/buffs change
		if stat6.UnregisterAllEvents then stat6:UnregisterAllEvents() end
		if stat6.RegisterEvent then
			stat6:RegisterEvent("PLAYER_ENTERING_WORLD");
			stat6:RegisterEvent("PLAYER_EQUIPMENT_CHANGED");
			stat6:RegisterEvent("UNIT_AURA");
			stat6:RegisterEvent("PLAYER_AURAS_CHANGED");
			stat6:RegisterEvent("UNIT_STATS");
		end
		stat6:SetScript("OnEvent", function(self, event, unit)
			if (event == "UNIT_AURA" or event == "UNIT_STATS") and unit and unit ~= "player" then return end
			PaperDollFrame_SetSpellPenetration(self);
		end);
		stat6:SetScript("OnUpdate", function(self, elapsed)
			self.__acc = (self.__acc or 0) + elapsed;
			if self.__acc > 0.50 then self.__acc = 0; PaperDollFrame_SetSpellPenetration(self); end
		end);

	elseif ( index == "PLAYERSTAT_DEFENSES" ) then
		PaperDollFrame_SetArmor(stat1);
		PaperDollFrame_SetDefense(stat2);
		PaperDollFrame_SetDodge(stat3);
		PaperDollFrame_SetParry(stat4);
		PaperDollFrame_SetBlock(stat5);

        -- Clear/hide Base Stats extra slot
        if stat6.UnregisterAllEvents then stat6:UnregisterAllEvents() end
        stat6:SetScript("OnEvent", nil);
        stat6:SetScript("OnUpdate", nil);
        _G[stat6:GetName().."Label"]:SetText("");
        _G[stat6:GetName().."StatText"]:SetText("");
        stat6:Hide();
	end
end

-- Stub kept for compatibility with older BCS-derived code paths.
function ComputePetBonus(stat, value)
	return 0;
end

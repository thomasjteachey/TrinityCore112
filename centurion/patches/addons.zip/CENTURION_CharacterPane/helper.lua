BCS = BCS or {}
BCSConfig = BCSConfig or {}

local BCS_Tooltip = _G["BetterCharacterStatsTooltip"]
    or CreateFrame("GameTooltip", "BetterCharacterStatsTooltip", nil, "GameTooltipTemplate")
local BCS_Prefix  = "BetterCharacterStatsTooltip"
BCS_Tooltip:SetOwner(WorldFrame, "ANCHOR_NONE")

local strfind  = strfind or string.find
local tonumber = tonumber
local strlower = string.lower

------------------------------------------------------------
-- Talent group helper (dual spec safety)
------------------------------------------------------------
local function BCS_GetActiveTalentGroupSafe()
    if GetActiveTalentGroup then
        local g = GetActiveTalentGroup()
        if g and g > 0 then
            return g
        end
    end
    return 1
end

local function BCS_GetTalentRankSafe(tab, talent, group)
    if not GetTalentInfo then return nil end

    if group then
        local ok, a, b, c, d, e, f, g, h = pcall(GetTalentInfo, tab, talent, nil, false, group)
        if ok then
            return e
        end
    end

    local _, _, _, _, rank = GetTalentInfo(tab, talent)
    return rank
end

local function BCS_SetTalentTooltipSafe(tab, talent, group)
    if not BCS_Tooltip or not BCS_Tooltip.SetTalent then return 0 end

    BCS_Tooltip:ClearLines()

    if group then
        local ok = pcall(BCS_Tooltip.SetTalent, BCS_Tooltip, tab, talent, false, false, group)
        if ok and BCS_Tooltip:NumLines() > 0 then
            return BCS_Tooltip:NumLines()
        end

        BCS_Tooltip:ClearLines()
        ok = pcall(BCS_Tooltip.SetTalent, BCS_Tooltip, tab, talent, false, group)
        if ok and BCS_Tooltip:NumLines() > 0 then
            return BCS_Tooltip:NumLines()
        end
    end

    BCS_Tooltip:ClearLines()
    local ok = pcall(BCS_Tooltip.SetTalent, BCS_Tooltip, tab, talent)
    if ok then
        return BCS_Tooltip:NumLines()
    end

    return 0
end

------------------------------------------------------------
-- OPTIONAL: hidden head-enchant hit hacks (disabled by default)
-- If your server uses hidden effects that do NOT appear in tooltip,
-- you can enable by adding mappings below.
--
-- Example:
--   HEAD_ENCHANT_MELEE_HIT_BONUS[2586] = 1
--   HEAD_ENCHANT_SPELL_HIT_BONUS[2588] = 1
--
-- This is intentionally empty to avoid false positives on custom servers.
------------------------------------------------------------
local HEAD_ENCHANT_MELEE_HIT_BONUS = {}
local HEAD_ENCHANT_SPELL_HIT_BONUS = {}

local function BCS_GetHeadEnchantId()
    local headIndex = 1
    local itemLink = GetInventoryItemLink("player", headIndex)
    if not itemLink then return nil end

    local _, enchantId = itemLink:match("item:(%d+):(%d*)")
    if not enchantId or enchantId == "" then
        return nil
    end

    return tonumber(enchantId)
end

------------------------------------------------------------
-- MELEE / GENERIC HIT
------------------------------------------------------------
function BCS:GetHitRating()
    local hit = 0
    local MAX_INVENTORY_SLOTS = 19

    -- Set-tracking state
    local sets = {}
    local currentSet = ""

    -- Item tooltip parsing
    for slot = 0, MAX_INVENTORY_SLOTS do
        BCS_Tooltip:ClearLines()
        local hasItem = BCS_Tooltip:SetInventoryItem("player", slot)
        if hasItem then
            local MAX_LINES = BCS_Tooltip:NumLines()

            for line = 1, MAX_LINES do
                local left = _G[BCS_Prefix .. "TextLeft" .. line]
                if left and left:GetText() then
                    local text = left:GetText()

                    -- direct item hit %
                    local _, _, value = strfind(text, "Equip: Improves your chance to hit by (%d)%%%.")
                    if value then
                        hit = hit + tonumber(value)
                    end

                    -- set progress line "x/y"
                    local _, _, setMin, setMax = strfind(text, "((%d)/(%d))")
                    if setMin and setMax then
                        currentSet = text
                        if not sets[currentSet] or sets[currentSet] == 0 then
                            sets[currentSet] = 1
                        end
                    end

                    -- set bonus: hit
                    local x, _, setValue = strfind(text, "Set: Improves your chance to hit by (%d)%%%.")
                    if setValue and x and x <= 1 and sets[currentSet] == 1 then
                        hit = hit + tonumber(setValue)
                        sets[currentSet] = 2
                    end
                end
            end
        end
    end

    -- OPTIONAL hidden head enchant support (disabled by default)
    do
        local enchantId = BCS_GetHeadEnchantId()
        if enchantId and HEAD_ENCHANT_MELEE_HIT_BONUS[enchantId] then
            hit = hit + HEAD_ENCHANT_MELEE_HIT_BONUS[enchantId]
        end
    end

        -- talents
    local MAX_TABS = GetNumTalentTabs()
    for tab = 1, MAX_TABS do
        local MAX_TALENTS = GetNumTalents(tab)
        for talent = 1, MAX_TALENTS do
            BCS_Tooltip:ClearLines()
            BCS_Tooltip:SetTalent(tab, talent)
            local MAX_LINES = BCS_Tooltip:NumLines()
            local name, _, _, _, rank, maxRank = GetTalentInfo(tab, talent)

            if rank and rank > 0 then
                for line = 1, MAX_LINES do
                    local left = getglobal(BCS_Prefix .. "TextLeft" .. line)
                    if left and left:GetText() then
                        local text = left:GetText()

                        -- Broad, safe matches for hit talents (incl. Surefooted)
                        local _, _, v

                        -- "Increases your chance to hit by X%."
                        _, _, v = strfind(text, "Increases your chance to hit by (%d+)%%")
                        if v then
                            hit = hit + tonumber(v)
                            break
                        end

                        -- "Increases your chance to hit with melee and ranged attacks by X%."
                        _, _, v = strfind(text, "Increases your chance to hit with melee and ranged attacks by (%d+)%%")
                        if v then
                            hit = hit + tonumber(v)
                            break
                        end

                        -- "Increases your chance to hit with melee weapons by X%."
                        _, _, v = strfind(text, "Increases your chance to hit with melee weapons by (%d+)%%")
                        if v then
                            hit = hit + tonumber(v)
                            break
                        end

                        -- "Increases hit chance by X%."
                        _, _, v = strfind(text, "Increases hit chance by (%d+)%%")
                        if v then
                            hit = hit + tonumber(v)
                            break
                        end

                        -- "Increases your chance to hit with melee attacks and spells by X%."
                        _, _, v = strfind(text, "Increases your chance to hit with melee attacks and spells by (%d+)%%")
                        if v then
                            hit = hit + tonumber(v)
                            break
                        end
                    end
                end
            end
        end
    end


    return hit
end

------------------------------------------------------------
-- RANGED HIT (melee/generic hit + Biznicks scope)
------------------------------------------------------------
function BCS:GetHitFromBiznicksAccurascope()
    local hitFromScope = 0
    local rangedIndex = 18
    local itemLink = GetInventoryItemLink("player", rangedIndex)
    if itemLink then
        local _, enchantId = itemLink:match("item:(%d+):(%d*)")
        enchantId = enchantId and enchantId ~= "" and tonumber(enchantId) or nil
        if enchantId == 2523 then
            hitFromScope = 3
        end
    end
    return hitFromScope
end

function BCS:GetRangedHitRating()
    return (BCS:GetHitRating() or 0) + (BCS:GetHitFromBiznicksAccurascope() or 0)
end

------------------------------------------------------------
-- SPELL HIT
------------------------------------------------------------
function BCS:GetSpellHitRating()
    local hit = 0
    local MAX_INVENTORY_SLOTS = 19

    local sets = {}
    local currentSet = ""

    for slot = 0, MAX_INVENTORY_SLOTS do
        BCS_Tooltip:ClearLines()
        local hasItem = BCS_Tooltip:SetInventoryItem("player", slot)
        if hasItem then
            local numLines = BCS_Tooltip:NumLines()

            for line = 1, numLines do
                local left  = _G[BCS_Prefix .. "TextLeft"  .. line]
                local right = _G[BCS_Prefix .. "TextRight" .. line]

                if left and left:GetText() then
                    local text = left:GetText()

                    local _, _, value = strfind(text, "Equip: Improves your chance to hit with spells by (%d)%%%.")
                    if value then
                        hit = hit + tonumber(value)
                    end

                    local _, _, setMin, setMax = strfind(text, "((%d)/(%d))")
                    if setMin and setMax and (not sets[text] or sets[text] == 0) then
                        currentSet = text
                        sets[currentSet] = 1
                    end

                    local x, _, setValue = strfind(text, "Set: Improves your chance to hit with spells by (%d)%%%.")
                    if setValue and x and x <= 1 and sets[currentSet] == 1 then
                        hit = hit + tonumber(setValue)
                        sets[currentSet] = 2
                    end
                end

                if right and right:GetText() then
                    local text = right:GetText()

                    local _, _, value = strfind(text, "Equip: Improves your chance to hit with spells by (%d)%%%.")
                    if value then
                        hit = hit + tonumber(value)
                    end

                    local _, _, setMin, setMax = strfind(text, "((%d)/(%d))")
                    if setMin and setMax and (not sets[text] or sets[text] == 0) then
                        currentSet = text
                        sets[currentSet] = 1
                    end

                    local x, _, setValue = strfind(text, "Set: Improves your chance to hit with spells by (%d)%%%.")
                    if setValue and x and x <= 1 and sets[currentSet] == 1 then
                        hit = hit + tonumber(setValue)
                        sets[currentSet] = 2
                    end
                end
            end
        end
    end

    -- OPTIONAL hidden head enchant support (disabled by default)
    do
        local enchantId = BCS_GetHeadEnchantId()
        if enchantId and HEAD_ENCHANT_SPELL_HIT_BONUS[enchantId] then
            hit = hit + HEAD_ENCHANT_SPELL_HIT_BONUS[enchantId]
        end
    end

    -- Talents (active spec only)
    local group = BCS_GetActiveTalentGroupSafe()
    if GetNumTalentTabs and GetNumTalents and GetTalentInfo then
        for tab = 1, GetNumTalentTabs() do
            for talent = 1, GetNumTalents(tab) do
                local MAX_LINES = BCS_SetTalentTooltipSafe(tab, talent, group)
                local rank = BCS_GetTalentRankSafe(tab, talent, group)

                if rank and rank > 0 then
                    for line = 1, MAX_LINES do
                        local left = _G[BCS_Prefix .. "TextLeft" .. line]
                        if left and left:GetText() then
                            local text = left:GetText()

                            local _, _, v1 = strfind(text, "Increases your chance to hit with melee attacks and spells by (%d+)%%")
                            if v1 then
                                hit = hit + tonumber(v1)
                                break
                            end

                            local _, _, v2 = strfind(text, "Increases your chance to hit with spells by (%d+)%%")
                            if v2 then
                                hit = hit + tonumber(v2)
                                break
                            end

                            -- Do NOT treat generic "chance to hit" talent text as spell hit.
                            -- Only explicit spell-hit or melee+spells wording should count here.
                        end
                    end
                end
            end
        end
    end

    return hit
end

------------------------------------------------------------
-- SPELL CRIT
------------------------------------------------------------
function BCS:GetSpellCritChance()
    local spellCrit = 0
    local MAX_INVENTORY_SLOTS = 19

    local function AddSpellCritFromText(text)
        local _, _, v1 = strfind(text, "Equip: Improves your chance to get a critical strike with spells by (%d)%%%.")
        if v1 then return tonumber(v1) end

        local _, _, v2 = strfind(text, "Equip: Increases your chance to get a critical strike with spells by (%d)%%%.")
        if v2 then return tonumber(v2) end

        return 0
    end

    for slot = 0, MAX_INVENTORY_SLOTS do
        BCS_Tooltip:ClearLines()
        local hasItem = BCS_Tooltip:SetInventoryItem("player", slot)
        if hasItem then
            local numLines = BCS_Tooltip:NumLines()
            for line = 1, numLines do
                local left = _G[BCS_Prefix .. "TextLeft" .. line]
                if left and left:GetText() then
                    spellCrit = spellCrit + AddSpellCritFromText(left:GetText())
                end
            end
        end
    end

    -- set bonuses for spell crit
    local sets = {}
    local currentSet = ""

    for slot = 0, MAX_INVENTORY_SLOTS do
        BCS_Tooltip:ClearLines()
        local hasItem = BCS_Tooltip:SetInventoryItem("player", slot)
        if hasItem then
            local numLines = BCS_Tooltip:NumLines()
            for line = 1, numLines do
                local left  = _G[BCS_Prefix .. "TextLeft"  .. line]
                local right = _G[BCS_Prefix .. "TextRight" .. line]

                local function ProcessSide(sideText)
                    if not sideText then return end

                    local _, _, setMin, setMax = strfind(sideText, "((%d)/(%d))")
                    if setMin and setMax and (not sets[sideText] or sets[sideText] == 0) then
                        currentSet = sideText
                        sets[currentSet] = 1
                    end

                    local _, _, setValue1 = strfind(sideText, "Set: Improves your chance to get a critical strike with spells by (%d)%%%.")
                    local _, _, setValue2 = strfind(sideText, "Set: Increases your chance to get a critical strike with spells by (%d)%%%.")
                    local setValue = setValue1 or setValue2

                    -- only apply once per set header
                    local x = 1 -- emulate original "starts at beginning" intent
                    if setValue and x and x <= 1 and sets[currentSet] == 1 then
                        spellCrit = spellCrit + tonumber(setValue)
                        sets[currentSet] = 2
                    end
                end

                if left and left:GetText() then
                    ProcessSide(left:GetText())
                end
                if right and right:GetText() then
                    ProcessSide(right:GetText())
                end
            end
        end
    end

    return spellCrit
end

------------------------------------------------------------
-- MANA REGEN (SPIRIT)
------------------------------------------------------------
local function GetRegenMPPerSpirit()
    local addvalue = 0
    local _, Spirit = UnitStat("player", 5)
    local _, class = UnitClass("player")

    if class == "DRUID" then
        addvalue = (Spirit / 5 + 15)
    elseif class == "HUNTER" then
        addvalue = (Spirit / 5 + 15)
    elseif class == "MAGE" then
        addvalue = (Spirit / 4 + 12.5)
    elseif class == "PALADIN" then
        addvalue = (Spirit / 5 + 15)
    elseif class == "PRIEST" then
        addvalue = (Spirit / 4 + 12.5)
    elseif class == "SHAMAN" then
        addvalue = (Spirit / 5 + 17)
    elseif class == "WARLOCK" then
        addvalue = (Spirit / 5 + 15)
    else
        addvalue = (Spirit / 5 + 15)
    end

    return (addvalue / 2)
end

function BCS:GetManaRegen()
    local power_regen = GetRegenMPPerSpirit()

    local base    = power_regen
    local casting = power_regen / 100

    return base, casting
end

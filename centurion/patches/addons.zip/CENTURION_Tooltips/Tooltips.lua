-- ComparePlus.lua
-- Tail under ShoppingTooltip1/2, using LINK-BASED parsing so deltas are correct.
FERAL_DRUID_ITEM_AP = ""
------------------------------------------------------------
-- 1) hidden scanner we control
------------------------------------------------------------
local CP_Scanner = CreateFrame("GameTooltip", "ComparePlusScannerTooltip", UIParent, "GameTooltipTemplate")
CP_Scanner:SetOwner(UIParent, "ANCHOR_NONE")

------------------------------------------------------------
-- 2) parse stats from a scanner tooltip (colors stripped)
------------------------------------------------------------
local function CP_ParseScanner()
  local s = {
    critPct=0, hitPct=0,
    spellCritPct=0, spellHitPct=0,
    blockPct=0, parryPct=0, dodgePct=0,
  }

  local name = CP_Scanner:GetName()
  for i = 1, CP_Scanner:NumLines() do
    local f = _G[name.."TextLeft"..i]
    local t = f and f:GetText()
    if t then
      t = t:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("^%s+","")
      local L = t:lower()

      -- melee/ranged crit
      local v =
        L:match("improves your chance to get a critical strike by (%d+)%%") or
        L:match("increases your chance to get a critical strike by (%d+)%%") or
        (not L:find("spell") and L:match("critical strike by (%d+)%%"))
      if v and not L:find("spell") then s.critPct = s.critPct + tonumber(v) end

      -- melee/ranged hit
      local hv =
        L:match("improves your chance to hit by (%d+)%%") or
        L:match("increases your chance to hit by (%d+)%%") or
        (not L:find("spell") and L:match("chance to hit by (%d+)%%"))
      if hv and not L:find("spell") then s.hitPct = s.hitPct + tonumber(hv) end

      -- spell crit
      local scv =
        L:match("improves your chance to get a critical strike with spells by (%d+)%%") or
        L:match("improves spell critical strike chance by (%d+)%%") or
        L:match("critical.-spells by (%d+)%%") or
        L:match("spell[s]? critical strike by (%d+)%%")
      if scv then s.spellCritPct = s.spellCritPct + tonumber(scv) end

      -- spell hit
      local shv =
        L:match("improves your chance to hit with spells by (%d+)%%") or
        L:match("increases your chance to hit with spells by (%d+)%%") or
        L:match("hit with spells by (%d+)%%") or
        L:match("spell[s]? hit by (%d+)%%")
      if shv then s.spellHitPct = s.spellHitPct + tonumber(shv) end

      -- block
      local bv =
        L:match("increases your chance to block.-by (%d+)%%") or
        L:match("improves your chance to block.-by (%d+)%%") or
        L:match("chance to block.-(%d+)%%") or
        L:match("block an attack by (%d+)%%")
      if bv then s.blockPct = s.blockPct + tonumber(bv) end

      -- parry
      local pv =
        L:match("increases your chance to parry an attack by (%d+)%%") or
        L:match("improves your chance to parry an attack by (%d+)%%") or
        L:match("chance to parry.-(%d+)%%") or
        L:match("parry an attack by (%d+)%%")
      if pv then s.parryPct = s.parryPct + tonumber(pv) end

      -- dodge
      local dv =
        L:match("increases your chance to dodge an attack by (%d+)%%") or
        L:match("improves your chance to dodge an attack by (%d+)%%") or
        L:match("chance to dodge.-(%d+)%%") or
        L:match("dodge an attack by (%d+)%%")
      if dv then s.dodgePct = s.dodgePct + tonumber(dv) end
    end
  end

  return s
end

local function CP_ParseLink(link)
  if not link then
    return {critPct=0,hitPct=0,spellCritPct=0,spellHitPct=0,blockPct=0,parryPct=0,dodgePct=0}
  end
  CP_Scanner:ClearLines()
  CP_Scanner:SetOwner(UIParent, "ANCHOR_NONE")
  CP_Scanner:SetHyperlink(link)
  return CP_ParseScanner()
end

------------------------------------------------------------
-- 3) equipLoc -> slot IDs (we need this for weapons/rings/etc)
------------------------------------------------------------
local CP_EquipSlots = {
  INVTYPE_HEAD       = {1},
  INVTYPE_NECK       = {2},
  INVTYPE_SHOULDER   = {3},
  INVTYPE_BODY       = {4},
  INVTYPE_CHEST      = {5},
  INVTYPE_ROBE       = {5},
  INVTYPE_WAIST      = {6},
  INVTYPE_LEGS       = {7},
  INVTYPE_FEET       = {8},
  INVTYPE_WRIST      = {9},
  INVTYPE_HAND       = {10},
  INVTYPE_FINGER     = {11,12},
  INVTYPE_TRINKET    = {13,14},
  INVTYPE_CLOAK      = {15},
  INVTYPE_WEAPON     = {16,17},        -- 1H → both, to match two compares
  INVTYPE_2HWEAPON   = {16,17},        -- 2H shows both compares too
  INVTYPE_WEAPONMAINHAND = {16},
  INVTYPE_WEAPONOFFHAND  = {17},
  INVTYPE_SHIELD     = {17},
  INVTYPE_RANGED     = {18},
  INVTYPE_RANGEDRIGHT= {18},
  INVTYPE_THROWN     = {18},
  INVTYPE_RELIC      = {18},
  INVTYPE_TABARD     = {19},
}

------------------------------------------------------------
-- 4) current hover snapshot (link-based, so it’s stable)
------------------------------------------------------------
local CP_Current = {
  newStats = nil,   -- stats of hovered item
  slots    = nil,   -- {slot1, slot2?}
  eqStats  = {},    -- eqStats[1], eqStats[2]
}

------------------------------------------------------------
-- 5) tail creator (child of the compare tooltip → no extra flicker)
------------------------------------------------------------
local function CP_GetTail(parent, name)
  if not parent[name] then
    local f = CreateFrame("Frame", name, parent)
    f:SetFrameStrata(parent:GetFrameStrata())
    f:SetFrameLevel(parent:GetFrameLevel() + 1)
    f:SetBackdrop(GameTooltip:GetBackdrop())
    f:SetBackdropColor(GameTooltip:GetBackdropColor())
    f:SetBackdropBorderColor(GameTooltip:GetBackdropBorderColor())
    f:SetPoint("TOPLEFT", parent, "BOTTOMLEFT", 0, -2)
    f:Hide()
    f.lines = {}
    for i = 1, 7 do
      local fs = f:CreateFontString(nil, "OVERLAY", "GameTooltipText")
      fs:SetPoint("TOPLEFT", f, "TOPLEFT", 5, -5 - (i-1)*12)
      fs:SetJustifyH("LEFT")
      fs:Hide()
      f.lines[i] = fs
    end
    parent[name] = f
  end
  return parent[name]
end

local function HideFeralAPLine(tip)
    if not tip or not tip:IsShown() then return end

    local name = tip:GetName()
    if not name then return end

    local numLines = tip:NumLines()
    for i = 1, numLines do
        local left = _G[name.."TextLeft"..i]
        if left then
            local text = left:GetText()
            if text and text ~= "" and text:lower():find("attack power in forms") then
                -- Blank the line out
                left:SetText("")

                -- Just in case there is a right-side fontstring on the same line
                local right = _G[name.."TextRight"..i]
                if right then
                    right:SetText("")
                end
            end
        end
    end
end

------------------------------------------------------------
-- 6) draw for a specific slot (1 → ShoppingTooltip1, 2 → ShoppingTooltip2)
------------------------------------------------------------
local function CP_DrawForSlot(idx)
  local tip = (idx == 1) and ShoppingTooltip1 or ShoppingTooltip2
  if not tip or not tip:IsShown() then return end
  if not CP_Current.newStats then return end

  -- Reset our "already drew" guard when the compare tooltip switches items without hiding.
  local _, curLink = tip:GetItem()
  if tip.CP_LastLink ~= curLink then
    tip.CP_HasExtraLines = nil
    tip.CP_LastLink = curLink
  end

  -- If we've already appended our lines for this showing, don't do it again.
  if tip.CP_HasExtraLines then
    return
  end
  tip.CP_HasExtraLines = true

  -- strip the "Attack Power in Forms" line from this compare tooltip
  HideFeralAPLine(tip)

  local ns = CP_Current.newStats

  -- Always match the equipped item that THIS compare tooltip is showing.
  local _, shownLink = tip:GetItem()

  local eq
  if shownLink then
    eq = CP_ParseLink(shownLink)
  else
    -- fallback only if the compare tooltip didn't return an item
    eq = CP_Current.eqStats[idx] or {critPct=0,hitPct=0,spellCritPct=0,spellHitPct=0,blockPct=0,parryPct=0,dodgePct=0}
  end

  -- build deltas
  local deltas = {}
  local function add(label, diff)
    if diff ~= 0 then
      deltas[#deltas+1] = {label=label, delta=diff}
    end
  end

  add("Crit",       ns.critPct      - eq.critPct)
  add("Hit",        ns.hitPct       - eq.hitPct)
  add("Spell Crit", ns.spellCritPct - eq.spellCritPct)
  add("Spell Hit",  ns.spellHitPct  - eq.spellHitPct)
  add("Block",      ns.blockPct     - eq.blockPct)
  add("Parry",      ns.parryPct     - eq.parryPct)
  add("Dodge",      ns.dodgePct     - eq.dodgePct)

  if #deltas == 0 then return end

  -- spacer line so it breathes under the stock block
  tip:AddLine(" ")

  for i = 1, #deltas do
    local d    = deltas[i]
    local col  = d.delta > 0 and "|cff00ff00" or "|cffff2020"
    local sign = d.delta > 0 and "+" or "-"
    local amt  = math.floor(math.abs(d.delta) + 0.5)
    tip:AddLine(string.format("%s%s%d|r |cffffffff%s|r", col, sign, amt, d.label))
  end

  tip:Show()  -- ensure it recalculates height
end



------------------------------------------------------------
-- 7) when we hover an item: scan it AND the actual equipped items
------------------------------------------------------------
GameTooltip:HookScript("OnTooltipSetItem", function(tip)
  local _, link = tip:GetItem()
  if not link then
    CP_Current.newStats = nil
    CP_Current.slots    = nil
    CP_Current.eqStats  = {}
    return
  end

  -- scan hovered/new from LINK (not from visible tooltip)
  local ns = CP_ParseLink(link)

  local _, _, _, _, _, _, _, _, equipLoc = GetItemInfo(link)
  local slots = CP_EquipSlots[equipLoc]

  CP_Current.newStats = ns
  CP_Current.slots    = slots
  CP_Current.eqStats  = {}

  if slots then
    for i, slotID in ipairs(slots) do
      local eqLink = GetInventoryItemLink("player", slotID)
      CP_Current.eqStats[i] = CP_ParseLink(eqLink)
    end
  end

  -- bag/char path: if compare tooltips are ALREADY shown, paint now
  if ShoppingTooltip1 and ShoppingTooltip1:IsShown() then CP_DrawForSlot(1) end
  if ShoppingTooltip2 and ShoppingTooltip2:IsShown() then CP_DrawForSlot(2) end
end)

GameTooltip:HookScript("OnHide", function()
  CP_Current.newStats = nil
  CP_Current.slots    = nil
  CP_Current.eqStats  = {}
end)


------------------------------------------------------------
-- 8) vendor/normal compare path
------------------------------------------------------------
hooksecurefunc("GameTooltip_ShowCompareItem", function()
  CP_DrawForSlot(1)
  CP_DrawForSlot(2)
end)

-- also react if the compare tooltip gets shown by some other path
if ShoppingTooltip1 then
  ShoppingTooltip1:HookScript("OnHide", function(self)
    self.CP_HasExtraLines = nil
  end)
end
if ShoppingTooltip2 then
  ShoppingTooltip2:HookScript("OnHide", function(self)
    self.CP_HasExtraLines = nil
  end)
end


-- Make artifact-quality item names red, and green lines pink

-- Make artifact-quality item names red,
-- green lines #ffadce, and white lines very light pink.

local function Centurion_RecolorArtifactItem(tip)
    if not tip or not tip:IsShown() then return end

    local _, link = tip:GetItem()
    if not link then return end

    -- artifact only
    local _, _, quality = GetItemInfo(link)
    if not quality or quality ~= 6 then
        return
    end

    local name = tip:GetName()
    if not name then return end

    ------------------------------------------------
    -- 1) NAME LINE → RED
    ------------------------------------------------
    local fsName = _G[name.."TextLeft1"]
    if fsName then
        local text = fsName:GetText()
        if text and text ~= "" then
            text = text:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
            fsName:SetText("|cffff0000"..text.."|r")  -- pure red
        end
    end

    ------------------------------------------------
    -- 2) OTHER LINES
    --    - green-ish → #ffadce
    --    - white-ish → very light pink
    ------------------------------------------------
    local numLines = tip:NumLines()
    for i = 2, numLines do
        local fs = _G[name.."TextLeft"..i]
        if fs then
            local r, g, b = fs:GetTextColor()
            if r and g and b then
                local text = fs:GetText()
                if text and text ~= "" then
                    text = text:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")

                    -- GREEN-ISH (Equip: bonuses etc.) → #ffadce
                    if r < 0.3 and g > 0.7 and b < 0.3 then
                        fs:SetText("|cffffadce"..text.."|r")  -- <= your pink
                    end
                end
            end
        end
    end
end

local function Centurion_SetArtifactQualityColor()
    local r, g, b = 1, 0, 0   -- pure red

    if ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[6] then
        local c = ITEM_QUALITY_COLORS[6]
        c.r, c.g, c.b = r, g, b
        c.hex = "|cffff0000"
    end

    -- some UIs / older clients also use ITEM_RARITY_COLORS
    if ITEM_RARITY_COLORS and ITEM_RARITY_COLORS[6] then
        local c = ITEM_RARITY_COLORS[6]
        c.r, c.g, c.b = r, g, b
        c.hex = "|cffff0000"
    end
end

local function HookTooltip(tip)
    if tip and not tip.CenturionArtifactHooked then
        tip:HookScript("OnTooltipSetItem", Centurion_RecolorArtifactItem)
        tip.CenturionArtifactHooked = true
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
    HookTooltip(GameTooltip)
    HookTooltip(ShoppingTooltip1)
    HookTooltip(ShoppingTooltip2)
    HookTooltip(ItemRefTooltip)
    HookTooltip(ItemRefShoppingTooltip1)
    HookTooltip(ItemRefShoppingTooltip2)
    Centurion_SetArtifactQualityColor()
end)

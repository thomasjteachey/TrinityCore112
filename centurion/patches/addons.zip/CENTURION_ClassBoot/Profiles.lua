-- Profiles.lua (bundled with the addon; players don’t touch SavedVariables)
-- Paste exported profiles inside profiles = { } below.
-- Example (remove it when you add real ones):
-- ["example"] = {
--   class="DRUID", created=1730580000,
--   cvars={ multiBarBottomLeft="1", multiBarBottomRight="1", multiBarRight="1", multiBarLeft="1" },
--   binds={ ["MULTIACTIONBAR1BUTTON1"]={"Q"} },
--   bars={ {slot=13,type="macro",name="Prowl",body="#showtooltip Prowl\n/cast Prowl"} }
-- }

CLASSBOOT_BUNDLED = CLASSBOOT_BUNDLED or {
  profiles =
  {
		["elgrom_BM"] = {
			["created"] = 1762119001,
			["bars"] = {
				{
					["type"] = "spell",
					["spellID"] = 75,
					["slot"] = 1,
				}, -- [1]
				{
					["type"] = "spell",
					["spellID"] = 5116,
					["slot"] = 2,
				}, -- [2]
				{
					["type"] = "spell",
					["spellID"] = 3045,
					["slot"] = 3,
				}, -- [3]
				{
					["type"] = "spell",
					["spellID"] = 53434,
					["slot"] = 4,
				}, -- [4]
				{
					["type"] = "spell",
					["spellID"] = 34026,
					["slot"] = 5,
				}, -- [5]
				{
					["type"] = "spell",
					["spellID"] = 781,
					["slot"] = 6,
				}, -- [6]
				{
					["type"] = "spell",
					["spellID"] = 19503,
					["slot"] = 7,
				}, -- [7]
				{
					["type"] = "spell",
					["spellID"] = 34477,
					["slot"] = 8,
				}, -- [8]
				{
					["type"] = "spell",
					["spellID"] = 53338,
					["slot"] = 9,
				}, -- [9]
				{
					["type"] = "spell",
					["spellID"] = 53209,
					["slot"] = 10,
				}, -- [10]
				{
					["type"] = "spell",
					["spellID"] = 14311,
					["slot"] = 11,
				}, -- [11]
				{
					["type"] = "spell",
					["spellID"] = 19263,
					["slot"] = 12,
				}, -- [12]
				{
					["type"] = "spell",
					["spellID"] = 2643,
					["slot"] = 13,
				}, -- [13]
				{
					["type"] = "spell",
					["spellID"] = 60192,
					["slot"] = 14,
				}, -- [14]
				{
					["type"] = "spell",
					["spellID"] = 19574,
					["slot"] = 15,
				}, -- [15]
				{
					["type"] = "spell",
					["spellID"] = 3034,
					["slot"] = 16,
				}, -- [16]
				{
					["type"] = "spell",
					["spellID"] = 14318,
					["slot"] = 17,
				}, -- [17]
				{
					["type"] = "spell",
					["spellID"] = 19185,
					["slot"] = 18,
				}, -- [18]
				{
					["type"] = "spell",
					["spellID"] = 34074,
					["slot"] = 19,
				}, -- [19]
				{
					["type"] = "spell",
					["spellID"] = 19271,
					["slot"] = 20,
				}, -- [20]
				{
					["type"] = "spell",
					["spellID"] = 1494,
					["slot"] = 21,
				}, -- [21]
				{
					["type"] = "spell",
					["spellID"] = 2974,
					["slot"] = 22,
				}, -- [22]
				{
					["type"] = "spell",
					["spellID"] = 5384,
					["slot"] = 23,
				}, -- [23]
				{
					["type"] = "spell",
					["spellID"] = 6991,
					["slot"] = 24,
				}, -- [24]
				{
					["type"] = "spell",
					["spellID"] = 13809,
					["slot"] = 25,
				}, -- [25]
				{
					["type"] = "spell",
					["spellID"] = 19801,
					["slot"] = 26,
				}, -- [26]
				{
					["type"] = "spell",
					["spellID"] = 13159,
					["slot"] = 27,
				}, -- [27]
				{
					["type"] = "spell",
					["spellID"] = 5118,
					["slot"] = 28,
				}, -- [28]
				{
					["type"] = "spell",
					["spellID"] = 34078,
					["slot"] = 29,
				}, -- [29]
				{
					["type"] = "spell",
					["spellID"] = 883,
					["slot"] = 30,
				}, -- [30]
				{
					["type"] = "spell",
					["spellID"] = 81300,
					["slot"] = 59,
				}, -- [31]
				{
					["companionID"] = 4,
					["type"] = "companion",
					["kind"] = "MOUNT",
					["slot"] = 60,
				} -- [32]
			}
		}
  }
}

-- ClassBoot (3.3.5 / private-core friendly)
-- NOW:
--  - scans 1..120 action slots (so addon bars on 61+ get saved)
--  - profile SAVE:
--        * saves character macros (name+icon+body)
--        * does NOT save global macro bodies; just saves a reference so we can re-place it
--  - profile LOAD:
--        * deletes ALL character macros first
--        * recreates character macros from profile
--        * re-places global macros without touching global macro storage
--  - still class-gated
--  - still forces character-specific keybindings
--  - still saves empties, so clearing works
--
-- /classboot save <name>
-- /classboot load <name>
-- /classboot list
-- /classboot delete <name>
-- /classboot export <name>
-- /classboot dump <name>
-- /classboot selftest
-- /classboot msave|mload|mlist|mdelete|mexport|mglobals
-- /classboot debug

local ADDON = ...
local SV
local DEBUG = false

------------------------------------------------------------
-- SavedVariables resilience (private-core load order fix)
------------------------------------------------------------
local function EnsureSV()
  if type(CLASSBOOT_SV) ~= "table" then
    CLASSBOOT_SV = {}
  end

  -- If we previously bound SV to a pre-SV-load table, merge forward and rebind.
  if SV ~= CLASSBOOT_SV then
    if type(SV) == "table" and next(SV) then
      for k,v in pairs(SV) do
        if CLASSBOOT_SV[k] == nil then
          CLASSBOOT_SV[k] = v
        end
      end
    end
    SV = CLASSBOOT_SV
  end

  SV.profiles  = SV.profiles  or {}
  SV.macrosets = SV.macrosets or {}
  SV.opts      = SV.opts      or {}
  if SV.opts.includeGlobalMacros == nil then SV.opts.includeGlobalMacros = false end
end

EnsureSV()

------------------------------------------------------------
-- utils / logging
------------------------------------------------------------
local tostringall = tostringall or function(...)
  local t = {}
  for i = 1, select("#", ...) do t[i] = tostring(select(i, ...)) end
  return unpack(t)
end
local function dmsg(...)
  if DEBUG and DEFAULT_CHAT_FRAME then
    DEFAULT_CHAT_FRAME:AddMessage("|cff55ff88[CB]|r "..table.concat({tostringall(...)}, " "))
  end
end
local function println(...)
  if DEFAULT_CHAT_FRAME then
    DEFAULT_CHAT_FRAME:AddMessage("|cff55ff88[CB]|r "..table.concat({tostringall(...)}, " "))
  else
    print("[CB]", ...)
  end
end

------------------------------------------------------------
-- bundled container (Profiles.lua may fill these)
------------------------------------------------------------
CLASSBOOT_BUNDLED = CLASSBOOT_BUNDLED or {}
if type(CLASSBOOT_BUNDLED) ~= "table" then CLASSBOOT_BUNDLED = {} end
CLASSBOOT_BUNDLED.profiles = CLASSBOOT_BUNDLED.profiles or {}
CLASSBOOT_BUNDLED.macros   = CLASSBOOT_BUNDLED.macros   or {}

------------------------------------------------------------
-- API detection
------------------------------------------------------------
local HAS_GetSpellBookItemInfo  = type(GetSpellBookItemInfo)  == "function"
local HAS_GetSpellBookItemName  = type(GetSpellBookItemName)  == "function"
local HAS_GetSpellName          = type(GetSpellName)          == "function"
local HAS_PickupSpellBookItem   = type(PickupSpellBookItem)   == "function"
local HAS_PickupSpell           = type(PickupSpell)           == "function"
local HAS_GetNumSpellTabs       = type(GetNumSpellTabs)       == "function"
local HAS_GetSpellTabInfo       = type(GetSpellTabInfo)       == "function"

------------------------------------------------------------
-- staples
------------------------------------------------------------
local SLOT_FIRST, SLOT_LAST = 1, 120
local BOOKTYPE_SPELL = BOOKTYPE_SPELL or "spell"

local function ensureCharacterBindingSet()
  if SetCurrentBindingSet and GetCurrentBindingSet then
    if GetCurrentBindingSet() ~= 2 then SetCurrentBindingSet(2) end
  elseif SetCurrentBindingSet then
    SetCurrentBindingSet(2)
  end
  if SaveBindings then SaveBindings(2) end
end

------------------------------------------------------------
-- slot → command (1..60 only)
------------------------------------------------------------
local function commandForSlot(slot)
  if slot>=1  and slot<=12 then return ("ACTIONBUTTON%d"):format(slot) end
  if slot>=13 and slot<=24 then return ("MULTIACTIONBAR1BUTTON%d"):format(slot-12) end
  if slot>=25 and slot<=36 then return ("MULTIACTIONBAR2BUTTON%d"):format(slot-24) end
  if slot>=37 and slot<=48 then return ("MULTIACTIONBAR3BUTTON%d"):format(slot-36) end
  if slot>=49 and slot<=60 then return ("MULTIACTIONBAR4BUTTON%d"):format(slot-48) end
  return nil
end

------------------------------------------------------------
-- bar CVars
------------------------------------------------------------
local BAR_CVARS = { "multiBarBottomLeft", "multiBarBottomRight", "multiBarRight", "multiBarLeft" }
local function captureBarCVars()
  local t = {}
  for _,c in ipairs(BAR_CVARS) do t[c] = GetCVar(c) end
  return t
end
local function applyBarCVars(tbl)
  if not tbl then return end
  for _,c in ipairs(BAR_CVARS) do
    if tbl[c] then SetCVar(c, tbl[c]) end
  end
  if MultiActionBar_Update then MultiActionBar_Update() end
end

------------------------------------------------------------
-- keybinding helpers
------------------------------------------------------------
local function getKeysFor(command)
  local k1,k2 = GetBindingKey(command)
  local keys = {}
  if k1 then keys[#keys+1]=k1 end
  if k2 then keys[#keys+1]=k2 end
  return keys
end
local function setKeysFor(command, keys)
  local c1,c2 = GetBindingKey(command)
  if c1 then SetBinding(c1) end
  if c2 then SetBinding(c2) end
  if keys then for _,k in ipairs(keys) do SetBinding(k, command) end end
end

------------------------------------------------------------
-- unlock bars
------------------------------------------------------------
local function withUnlockedActionBars(fn)
  local keys = {"lockActionBars", "LOCK_ACTIONBAR"}
  local prev = {}
  for _,k in ipairs(keys) do
    local v = GetCVar and GetCVar(k)
    prev[k] = v
    if v and v ~= "0" then SetCVar(k, "0") end
  end
  local ok,err = pcall(fn)
  for _,k in ipairs(keys) do
    local v = prev[k]
    if v and v ~= "0" then SetCVar(k, v) end
  end
  if not ok then println("ERROR during placement:", tostring(err)) end
  return ok
end

------------------------------------------------------------
-- macro helpers
------------------------------------------------------------
local MACRO_NAME_MAX = 16
local function _trim(s) s=(s or ""):gsub("^%s+",""):gsub("%s+$",""); return s end
local function _shorten(n) return (#n>MACRO_NAME_MAX) and n:sub(1,MACRO_NAME_MAX) or n end
local function _getCounts() local g,c=GetNumMacros(); return g or 0, c or 0 end

local function pathToIconIndex(tex)
  if type(tex)=="number" and tex>0 then return tex end
  if not tex or tex=="" then return 1 end
  if not GetNumMacroIcons or not GetMacroIconInfo then return 1 end
  CLASSBOOT_ICON_CACHE = CLASSBOOT_ICON_CACHE or {}
  local key = string.lower(tex)
  if CLASSBOOT_ICON_CACHE[key] then return CLASSBOOT_ICON_CACHE[key] end
  local n = GetNumMacroIcons() or 0
  for i=1,n do
    local p = GetMacroIconInfo(i)
    if p and string.lower(p) == key then
      CLASSBOOT_ICON_CACHE[key] = i
      return i
    end
  end
  return 1
end
local function asIconIndex(icon)
  if type(icon)=="number" and icon>0 then return icon end
  if type(icon)=="string" then return pathToIconIndex(icon) end
  local n=tonumber(icon); if n and n>0 then return n end
  return 1
end

local function _findGlobalMacroByName(name)
  if not name or name=="" then return 0 end
  local g,c=_getCounts()
  for i=1,g do local n=GetMacroInfo(i); if n==name then return i end end
  return 0
end
local function _findCharMacroByName(name)
  if not name or name=="" then return 0 end
  local g,c=_getCounts()
  for i=g+1,g+c do local n=GetMacroInfo(i); if n==name then return i end end
  return 0
end

local function ensureGlobalMacro(name, body, icon)
  name=_shorten(_trim(name or "")); if name=="" then return nil end
  local g,c=_getCounts()
  if g>=36 then println("No global macro space left; skipping '"..name.."'."); return nil end
  local idx=_findGlobalMacroByName(name)
  local iconIdx=asIconIndex(icon)
  if idx~=0 then
    EditMacro(idx, name, iconIdx, body or "", 0, 0)
    return idx
  end
  return CreateMacro(name, iconIdx, body or "", 0)
end

local function ensureCharMacro(name, body, icon)
  name=_shorten(_trim(name or "")); if name=="" then return nil end
  local g,c=_getCounts()
  if c>=18 then println("No character macro space left; skipping '"..name.."'."); return nil end
  local idx=_findCharMacroByName(name)
  local iconIdx=asIconIndex(icon)
  if idx~=0 then EditMacro(idx, name, iconIdx, body or "", 1, 1); return idx end
  return CreateMacro(name, iconIdx, body or "", 1)
end

------------------------------------------------------------
-- spellbook helpers
------------------------------------------------------------
local function spellbookItemIsSpell(slot)
  if HAS_GetSpellBookItemInfo then
    return (GetSpellBookItemInfo(slot, BOOKTYPE_SPELL) == "SPELL")
  else
    if HAS_GetSpellBookItemName then
      return GetSpellBookItemName(slot, BOOKTYPE_SPELL) ~= nil
    elseif HAS_GetSpellName then
      return GetSpellName(slot, BOOKTYPE_SPELL) ~= nil
    end
  end
end
local function getSpellbookName(slot)
  if HAS_GetSpellBookItemName then return GetSpellBookItemName(slot, BOOKTYPE_SPELL)
  elseif HAS_GetSpellName then return GetSpellName(slot, BOOKTYPE_SPELL) end
end
local function pickupSpellbookSlot(slot)
  if HAS_PickupSpellBookItem then PickupSpellBookItem(slot, BOOKTYPE_SPELL); return true
  elseif HAS_PickupSpell then PickupSpell(slot, BOOKTYPE_SPELL); return true end
  return false
end
local function _findSpellBookSlotByName(wantedName)
  if not wantedName or wantedName=="" then return nil end
  if not (HAS_GetNumSpellTabs and HAS_GetSpellTabInfo) then return nil end
  local tabs=GetNumSpellTabs()
  local best
  for t=1,tabs do
    local _,_,offset,num = GetSpellTabInfo(t)
    for i=1,num do
      local slot = offset + i
      if spellbookItemIsSpell(slot) then
        local nm = getSpellbookName(slot)
        if nm == wantedName then best = slot end
      end
    end
  end
  return best
end

------------------------------------------------------------
-- slot ops
------------------------------------------------------------
local function clearSlot(slot)
  if HasAction and not HasAction(slot) then return end
  if ClearAction then ClearAction(slot) else PickupAction(slot); ClearCursor() end
end
local function cursorKind() return GetCursorInfo() end

------------------------------------------------------------
-- probe (for weird GetActionInfo)
------------------------------------------------------------
local function probeSlot(slot)
  ClearCursor()
  PickupAction(slot)
  local cType,c1,c2,c3 = GetCursorInfo()
  PlaceAction(slot)
  ClearCursor()
  return cType,c1,c2,c3
end

------------------------------------------------------------
-- placements
------------------------------------------------------------
local function pickupSpellFromBook(spellID)
  ClearCursor()
  local name = GetSpellInfo(spellID)
  if not name then return nil,nil end
  local bookSlot=_findSpellBookSlotByName(name)
  if not bookSlot then return name,nil end
  if not pickupSpellbookSlot(bookSlot) or cursorKind() ~= "spell" then ClearCursor(); return name,nil end
  return name, bookSlot
end
local function pickupItemSafe(itemID)
  ClearCursor(); if not itemID then return false end
  PickupItem(itemID); return cursorKind()=="item"
end
local function pickupMacroSafeByIndex(idx)
  ClearCursor(); if not idx or idx==0 then return false end
  PickupMacro(idx); return cursorKind()=="macro"
end

local function verifyActionSpell(slot, wantedName)
  local t,a,b,c = GetActionInfo(slot)
  if t~="spell" then return false end
  local actual = GetSpellInfo(c or a)
  if (actual=="Auto Attack" and wantedName=="Attack") or (actual=="Attack" and wantedName=="Auto Attack") then
    return true
  end
  return actual==wantedName
end
local function verifyActionItem(slot, itemID)
  local t,id = GetActionInfo(slot)
  return t=="item" and id==itemID
end
local function verifyActionMacro(slot, name, body)
  local t,idx = GetActionInfo(slot)
  if t~="macro" or not idx then return false end
  local n,_,b = GetMacroInfo(idx)
  return (n==name) and ((b or "")==(body or ""))
end

local function placeSpell(slot, spellID)
  local name,bookSlot = pickupSpellFromBook(spellID)
  if not name or not bookSlot then return false end
  PlaceAction(slot); ClearCursor()
  return verifyActionSpell(slot, name)
end
local function placeItem(slot, itemID)
  if not pickupItemSafe(itemID) then return false end
  PlaceAction(slot); ClearCursor()
  return verifyActionItem(slot, itemID)
end
local function placeCharMacro(slot, name, body, icon)
  local idx = ensureCharMacro(name, body, icon or 1)
  if not idx then return false end
  if not pickupMacroSafeByIndex(idx) then return false end
  PlaceAction(slot); ClearCursor()
  return verifyActionMacro(slot, name, body)
end
local function placeGlobalMacro(slot, index, name)
  local useIdx = index
  if not useIdx or useIdx==0 then
    if name and name~="" then useIdx = _findGlobalMacroByName(name) end
  end
  if not useIdx or useIdx==0 then
    dmsg("placeGlobalMacro: global macro "..tostring(name).." not found; skip")
    return false
  end
  if not pickupMacroSafeByIndex(useIdx) then return false end
  PlaceAction(slot); ClearCursor()
  return true
end
local function placeCompanion(slot, kind, id)
  if not (PickupCompanion and kind and id) then return false end
  ClearCursor(); PickupCompanion(kind, id)
  if not cursorKind() then return false end
  PlaceAction(slot); ClearCursor()
  local t=select(1,GetActionInfo(slot))
  return t=="companion"
end

------------------------------------------------------------
-- profile store
------------------------------------------------------------
local function getProfile(name)
  EnsureSV()
  return (SV and SV.profiles and SV.profiles[name]) or (CLASSBOOT_BUNDLED.profiles and CLASSBOOT_BUNDLED.profiles[name])
end
local function isBundledProfile(name)
  return CLASSBOOT_BUNDLED.profiles and CLASSBOOT_BUNDLED.profiles[name] ~= nil
end

------------------------------------------------------------
-- saving
------------------------------------------------------------
local function saveProfile(name)
  EnsureSV()
  if not name or name=="" then println("Usage: /classboot save <name>"); return end
  ensureCharacterBindingSet()
  local _,class = UnitClass("player")
  local prof = { class=class, created=time(), cvars=captureBarCVars(), binds={}, bars={} }

  -- binds 1..60
  for slot=1,60 do
    local cmd=commandForSlot(slot)
    if cmd then
      local keys=getKeysFor(cmd)
      if #keys>0 then prof.binds[cmd]=keys end
    end
  end

  local g,_ = _getCounts()

  local function scanBars()
    for slot=SLOT_FIRST,SLOT_LAST do
      local t,id,subType,spellID = GetActionInfo(slot)
      local saved=false

      if t=="spell" and (spellID or id) then
        table.insert(prof.bars, {slot=slot, type="spell", spellID=spellID or id})
        saved=true
      elseif t=="item" and id then
        table.insert(prof.bars, {slot=slot, type="item", itemID=id})
        saved=true
      elseif t=="macro" then
        local mIdx = (type(id)=="number" and id>0) and id or nil
        if not mIdx and type(subType)=="number" and subType>0 then mIdx=subType end
        if not mIdx then
          local cType,c1 = probeSlot(slot)
          if cType=="macro" and c1 and c1>0 then mIdx=c1 end
        end
        if mIdx and mIdx>0 then
          local mname, miconTex, mbody = GetMacroInfo(mIdx)
          if mIdx <= g then
            table.insert(prof.bars, { slot=slot, type="macro_global", index=mIdx, name=mname or "" })
          else
            table.insert(prof.bars, {
              slot=slot, type="macro",
              name=mname or "", body=mbody or "",
              icon=asIconIndex(miconTex), iconTex=miconTex,
              scope="char"
            })
          end
          saved=true
        end
      elseif t=="companion" and id then
        table.insert(prof.bars, {slot=slot, type="companion", kind=subType, companionID=id})
        saved=true
      end

      if not saved then
        local cType,c1,c2,c3 = probeSlot(slot)
        if cType=="spell" and c1 then
          table.insert(prof.bars, {slot=slot, type="spell", spellID=c1})
        elseif cType=="item" and c1 then
          table.insert(prof.bars, {slot=slot, type="item", itemID=c1})
        elseif cType=="macro" and c1 then
          local mname, miconTex, mbody = GetMacroInfo(c1)
          if c1 <= g then
            table.insert(prof.bars, {slot=slot, type="macro_global", index=c1, name=mname or ""})
          else
            table.insert(prof.bars, {
              slot=slot, type="macro",
              name=mname or "", body=mbody or "",
              icon=asIconIndex(miconTex), iconTex=miconTex,
              scope="char"
            })
          end
        elseif cType=="companion" and c1 then
          table.insert(prof.bars, {slot=slot, type="companion", kind=c2, companionID=c1})
        else
          table.insert(prof.bars, {slot=slot, type="empty"})
        end
      end
    end
  end

  withUnlockedActionBars(scanBars)

  SV.profiles[name] = prof
  local bindCount=0 for _ in pairs(prof.binds) do bindCount=bindCount+1 end
  println(("Saved profile |cffffff88%s|r (class=%s, bars=%d, binds=%d)."):format(name, class or "?", #(prof.bars or {}), bindCount))
end

------------------------------------------------------------
-- apply profile
------------------------------------------------------------
local function wipeCharacterMacros()
  local g,c=_getCounts()
  for i=g+c, g+1, -1 do DeleteMacro(i) end
end

local function _applyProfile(prof, name)
  applyBarCVars(prof.cvars)
  ensureCharacterBindingSet()
  for cmd,keys in pairs(prof.binds or {}) do setKeysFor(cmd, keys) end
  SaveBindings(2)

  local function doBars()
    wipeCharacterMacros()

    local cEmpty,cSpell,cItem,cMacro,cComp,cGlob,fail = 0,0,0,0,0,0,0

    for _,e in ipairs(prof.bars or {}) do
      if e.type=="empty" and e.slot and e.slot>=SLOT_FIRST and e.slot<=SLOT_LAST then
        clearSlot(e.slot); cEmpty=cEmpty+1
      end
    end

    for _,e in ipairs(prof.bars or {}) do
      local ok=true
      if e.type=="spell" then
        ok = placeSpell(e.slot, e.spellID); if ok then cSpell=cSpell+1 end
      elseif e.type=="item" then
        ok = placeItem(e.slot, e.itemID); if ok then cItem=cItem+1 end
      elseif e.type=="macro" then
        ok = placeCharMacro(e.slot, e.name, e.body, e.icon or 1); if ok then cMacro=cMacro+1 end
      elseif e.type=="macro_global" then
        ok = placeGlobalMacro(e.slot, e.index, e.name); if ok then cGlob=cGlob+1 end
      elseif e.type=="companion" then
        ok = placeCompanion(e.slot, e.kind, e.companionID); if ok then cComp=cComp+1 end
      end
      if not ok and e.type~="empty" then fail=fail+1 end
    end

    println(("Placed: spells=%d, items=%d, macros=%d, globalMacros=%d, companions=%d. Cleared=%d. Skipped=%d.")
      :format(cSpell,cItem,cMacro,cGlob,cComp,cEmpty,fail))
  end

  if InCombatLockdown() then
    println("In combat; will apply after combat.")
    local f=CreateFrame("Frame"); f:RegisterEvent("PLAYER_REGEN_ENABLED")
    f:SetScript("OnEvent", function()
      f:UnregisterEvent("PLAYER_REGEN_ENABLED")
      withUnlockedActionBars(doBars)
    end)
  else
    withUnlockedActionBars(doBars)
  end

  println(("Loaded profile |cffffff88%s|r%s."):format(name, isBundledProfile(name) and " (bundled)" or ""))
end

local function loadProfile(name)
  EnsureSV()
  if not name or name=="" then println("Usage: /classboot load <name>"); return end
  local prof = getProfile(name); if not prof then println("Profile not found:", name); return end
  local _,playerClass = UnitClass("player")
  if not prof.class or prof.class=="" then println(("Profile |cffffff88%s|r has no class; re-save it."):format(name)); return end
  if prof.class ~= playerClass then
    println(("Profile |cffffff88%s|r is for |cffff6666%s|r, you are |cffff6666%s|r. Aborting."):format(name, prof.class, playerClass))
    return
  end
  local bcount=0 for _ in pairs(prof.binds or {}) do bcount=bcount+1 end
  println(("Applying profile |cffffff88%s|r (bars=%d, binds=%d)…"):format(name, #(prof.bars or {}), bcount))
  _applyProfile(prof, name)
end

------------------------------------------------------------
-- list / delete
------------------------------------------------------------
local function listProfiles()
  EnsureSV()
  local _,playerClass = UnitClass("player")
  local seen={}
  local function cbCount(t) local c=0 for _ in pairs(t or {}) do c=c+1 end return c end
  local function compatTag(cls)
    if not cls or cls=="" then return " |cffffaa00[no-class]|r" end
    if cls==playerClass then return " |cff88ff88["..cls.." ok]|r" end
    return " |cffff6666["..cls.." only]|r"
  end
  local function show(src,tag)
    for k,v in pairs(src or {}) do
      if not seen[k] then
        seen[k]=true
        println(("• |cffffff88%s|r (bars=%d, binds=%d)%s%s"):format(
          k, #(v.bars or {}), cbCount(v.binds), compatTag(v.class),
          tag and (" |cffaaaaaa["..tag.."]|r") or ""
        ))
      end
    end
  end
  show(SV and SV.profiles, "saved")
  show(CLASSBOOT_BUNDLED.profiles, "bundled")
  if not next(seen) then println("No profiles.") end
end

local function deleteProfile(name)
  EnsureSV()
  if not name or name=="" then println("Usage: /classboot delete <name>"); return end
  if CLASSBOOT_BUNDLED.profiles and CLASSBOOT_BUNDLED.profiles[name] then println("Cannot delete bundled profile:", name); return end
  if SV and SV.profiles and SV.profiles[name] then SV.profiles[name]=nil; println("Deleted profile", name) else println("Profile not found:", name) end
end

------------------------------------------------------------
-- macro set commands
------------------------------------------------------------
local function includeGlobals() EnsureSV(); return SV and SV.opts and SV.opts.includeGlobalMacros end
local function setIncludeGlobals(v) EnsureSV(); SV.opts = SV.opts or {}; SV.opts.includeGlobalMacros = not not v end

local function captureMacros(wGlobals)
  local set={global={}, char={}}
  local g,c=_getCounts()
  if wGlobals then
    for i=1,g do
      local n,ic,bd = GetMacroInfo(i)
      if n then table.insert(set.global, {name=n, body=bd or "", icon=asIconIndex(ic), iconTex=ic}) end
    end
  end
  for i=g+1,g+c do
    local n,ic,bd = GetMacroInfo(i)
    if n then table.insert(set.char, {name=n, body=bd or "", icon=asIconIndex(ic), iconTex=ic}) end
  end
  return set
end
local function macroSetCounts(set) return #(set and set.global or {}), #(set and set.char or {}) end
local function wipeCharacterMacros_only() wipeCharacterMacros() end
local function wipeAllMacros()
  local g,c=_getCounts()
  for i=g+c,1,-1 do DeleteMacro(i) end
end
local function getMacroSet(name)
  EnsureSV()
  return (SV and SV.macrosets and SV.macrosets[name]) or (CLASSBOOT_BUNDLED.macros and CLASSBOOT_BUNDLED.macros[name])
end
local function isBundledMacroSet(name) return CLASSBOOT_BUNDLED.macros and CLASSBOOT_BUNDLED.macros[name] ~= nil end

local function saveMacroSet(name)
  EnsureSV()
  if not name or name=="" then println("Usage: /classboot msave <name>"); return end
  local set = captureMacros(includeGlobals()); SV.macrosets[name] = set
  local gg,cc = macroSetCounts(set)
  println(("Saved macro set |cffffff88%s|r (global=%d, char=%d). %s"):format(
    name, gg, cc,
    includeGlobals() and "|cff88ff88[includes globals]|r" or "|cffffaa00[globals excluded]|r"
  ))
end
local function loadMacroSet(name)
  EnsureSV()
  if not name or name=="" then println("Usage: /classboot mload <name>"); return end
  local set = getMacroSet(name); if not set then println("Macro set not found:", name); return end
  local wantGlobals = includeGlobals()
  local needG,needC = macroSetCounts(set); if not wantGlobals then needG=0 end
  if needG>36 or needC>18 then println(("Macro set too big (global %d/36, char %d/18)."):format(needG,needC)); return end
  if wantGlobals then wipeAllMacros() else wipeCharacterMacros_only() end
  if wantGlobals then for _,m in ipairs(set.global or {}) do ensureGlobalMacro(m.name, m.body, m.icon) end end
  for _,m in ipairs(set.char or {}) do ensureCharMacro(m.name, m.body, m.icon) end
  println(("Loaded macro set |cffffff88%s|r%s (wiped: %s)."):format(
    name, isBundledMacroSet(name) and " (bundled)" or "", wantGlobals and "global+char" or "char only"
  ))
end
local function listMacroSets()
  EnsureSV()
  local seen={}
  println("Macro set mode: "..(includeGlobals() and "|cff88ff88globals=ON|r" or "|cffffaa00globals=OFF|r"))
  local function show(src,tag)
    for k,v in pairs(src or {}) do
      if not seen[k] then
        seen[k]=true
        local gg,cc=macroSetCounts(v)
        println(("• |cffffff88%s|r  global=%d, char=%d%s"):format(k,gg,cc, tag and (" |cffaaaaaa["..tag.."]|r") or ""))
      end
    end
  end
  show(SV and SV.macrosets, "saved")
  show(CLASSBOOT_BUNDLED.macros, "bundled")
  if not next(seen) then println("No macro sets.") end
end
local function deleteMacroSet(name)
  EnsureSV()
  if not name or name=="" then println("Usage: /classboot mdelete <name>"); return end
  if isBundledMacroSet(name) then println("Cannot delete bundled macro set:", name); return end
  if SV and SV.macrosets and SV.macrosets[name] then SV.macrosets[name]=nil; println("Deleted macro set", name) else println("Macro set not found:", name) end
end

------------------------------------------------------------
-- export / dump
------------------------------------------------------------
local function escs(s) return (s:gsub("\\","\\\\"):gsub("\n","\\n"):gsub("\r","\\r"):gsub("\"","\\\"")) end
local function isarray(t) local n=0 for k,_ in pairs(t) do if type(k)~="number" then return false end n=n+1 end return n==#t end
local function dump(o)
  local ty=type(o)
  if ty=="nil" then return "nil"
  elseif ty=="number" or ty=="boolean" then return tostring(o)
  elseif ty=="string" then return "\"" .. escs(o) .. "\""
  elseif ty=="table" then
    if isarray(o) then local parts={} for i=1,#o do parts[#parts+1]=dump(o[i]) end; return "{"..table.concat(parts,",").."}"
    else local parts={} for k,v in pairs(o) do parts[#parts+1]="["..dump(k).."]="..dump(v) end; return "{"..table.concat(parts,",").."}" end
  end
  return "nil"
end
local function exportProfile(name)
  if not name or name=="" then println("Usage: /classboot export <name>"); return end
  local prof=getProfile(name); if not prof then println("Profile not found:", name); return end
  local snippet='["'..name..'"]='..dump(prof)
  println("---- ClassBoot profile export begin ----")
  local i,step=1,240; while i<=#snippet do println(string.sub(snippet,i,i+step-1)); i=i+step end
  println("---- ClassBoot profile export end ----")
end
local function exportMacroSet(name)
  if not name or name=="" then println("Usage: /classboot mexport <name>"); return end
  local set=getMacroSet(name); if not set then println("Macro set not found:", name); return end
  local snippet='["'..name..'"]='..dump(set)
  println("---- ClassBoot macro set export begin ----")
  local i,step=1,240; while i<=#snippet do println(string.sub(snippet,i,i+step-1)); i=i+step end
  println("---- ClassBoot macro set export end ----")
end
local function dumpProfile(name)
  local p=getProfile(name); if not p then println("dump: profile not found:", name); return end
  println(("dump %s: class=%s bars=%d"):format(name, tostring(p.class), #(p.bars or {})))
  for i=1, math.min(30, #(p.bars or {})) do
    local e=p.bars[i]
    println(("[%02d] slot=%s type=%s spell=%s item=%s name=%s scope=%s idx=%s"):format(
      i, tostring(e.slot), tostring(e.type), tostring(e.spellID), tostring(e.itemID),
      tostring(e.name), tostring(e.scope), tostring(e.index)
    ))
  end
end

------------------------------------------------------------
-- selftest
------------------------------------------------------------
local function selftest()
  println(("Selftest: APIs => BookInfo=%s, BookName=%s, SpellName=%s, PickupBook=%s/%s")
    :format(HAS_GetSpellBookItemInfo and "Y" or "N",
            HAS_GetSpellBookItemName and "Y" or "N",
            HAS_GetSpellName and "Y" or "N",
            HAS_PickupSpellBookItem and "Y" or "N",
            HAS_PickupSpell and "Y" or "N"))
  if not (HAS_GetNumSpellTabs and HAS_GetSpellTabInfo) then println("Selftest: no tab APIs; abort."); return end
  println("Selftest: scanning spellbook…")
  local tabs=GetNumSpellTabs()
  for t=1,tabs do
    local _,_,offset,num = GetSpellTabInfo(t)
    for i=1,num do
      local slot = offset + i
      if spellbookItemIsSpell(slot) then
        local name = getSpellbookName(slot) or (HAS_GetSpellName and GetSpellName(slot, BOOKTYPE_SPELL)) or "?"
        println(("Selftest: using bookSlot %d name %s"):format(slot, name))
        ClearCursor(); pickupSpellbookSlot(slot); PlaceAction(120); ClearCursor()
        local T,A,B,C = GetActionInfo(120)
        local placed = (T=="spell") and GetSpellInfo(C or A) or ("<"..tostring(T)..">")
        println(("Selftest placed '%s' into slot 120; button now = %s"):format(name, tostring(placed)))
        println("Selftest verify => "..(verifyActionSpell(120, name) and "OK" or "FAIL"))
        return
      end
    end
  end
  println("Selftest: no SPELL entries found.")
end

------------------------------------------------------------
-- init & slash
------------------------------------------------------------
local fr=CreateFrame("Frame")
fr:RegisterEvent("ADDON_LOADED")
fr:RegisterEvent("VARIABLES_LOADED")
fr:RegisterEvent("PLAYER_LOGIN")
fr:SetScript("OnEvent", function(_,ev,arg1)
  if ev=="ADDON_LOADED" and arg1==ADDON then
    -- may fire before SV is injected on some cores
    EnsureSV()
    ensureCharacterBindingSet()
    dmsg("ClassBoot loaded; scanning 1..120; profile load wipes char macros.")
  elseif ev=="VARIABLES_LOADED" or ev=="PLAYER_LOGIN" then
    -- on many cores, this is when SV is actually ready
    EnsureSV()
    dmsg("SavedVariables ready; savedProfiles="..tostring(SV and SV.profiles and (next(SV.profiles) and "Y" or "N") or "N"))
  end
end)

SLASH_CLASSBOOT1 = "/classboot"
SlashCmdList.CLASSBOOT = function(msg)
  EnsureSV()
  msg=(msg or ""):gsub("^%s+",""):gsub("%s+$","")
  local a,b = msg:match("^(%S+)%s*(.-)$")
  local cmd = a and a:lower() or ""
  if cmd=="" then
    println("Commands: save, load, list, delete, export, dump, selftest")
    println("          msave, mload, mlist, mdelete, mexport, mglobals on|off|status")
    println("          debug")
    return
  end
  if     cmd=="save"     then saveProfile(b)
  elseif cmd=="load"     then loadProfile(b)
  elseif cmd=="list"     then listProfiles()
  elseif cmd=="delete"   then deleteProfile(b)
  elseif cmd=="export"   then exportProfile(b)
  elseif cmd=="dump"     then dumpProfile(b)
  elseif cmd=="selftest" then selftest()
  elseif cmd=="msave"    then saveMacroSet(b)
  elseif cmd=="mload"    then loadMacroSet(b)
  elseif cmd=="mlist"    then listMacroSets()
  elseif cmd=="mdelete"  then deleteMacroSet(b)
  elseif cmd=="mexport"  then exportMacroSet(b)
  elseif cmd=="mglobals" then
    local v=(b or ""):lower()
    if v=="on" or v=="true" then setIncludeGlobals(true);  println("Macro sets will now INCLUDE GLOBAL macros.")
    elseif v=="off" or v=="false" then setIncludeGlobals(false); println("Macro sets will now EXCLUDE GLOBAL macros.")
    else println("mglobals is "..(includeGlobals() and "ON" or "OFF")) end
  elseif cmd=="debug"    then DEBUG = not DEBUG; println("Debug:", DEBUG and "ON" or "OFF")
  else
    println("Unknown cmd:", cmd)
  end
end

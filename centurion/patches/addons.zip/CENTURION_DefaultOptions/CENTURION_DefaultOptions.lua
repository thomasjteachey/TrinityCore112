-- CENTURION_DefaultOptions.lua (WotLK 3.3.5 / 12340)
-- One-time account-wide defaults + per-character enable for:
--  - Equipment Manager
--  - "Review talent changes" (previewTalents)
-- Correctly waits for SavedVariables at ADDON_LOADED.

local ADDON_NAME = ...
-- DO NOT take a local SV reference yet; SavedVariables may not be loaded at file parse.
-- We'll bind 'SV' after ADDON_LOADED for this addon.
local SV       -- will be set in ADDON_LOADED
local DEBUG = false  -- toggle with /cent debug (prints are minimal)

local function dmsg(...)
  if not DEBUG or not DEFAULT_CHAT_FRAME then return end
  local t = {}
  for i = 1, select("#", ...) do
    t[i] = tostring(select(i, ...))
  end
  DEFAULT_CHAT_FRAME:AddMessage("|cff00ff88[CENT]|r " .. table.concat(t, " "))
end

-- Timings for two-pass apply (helps late UI init)
local APPLY_DELAY_1, APPLY_DELAY_2 = 0.30, 1.20

-- Desired defaults (account-wide first run)
local DEFAULTS = {
  cvars = {
    -- QoL
    autoLootDefault         = "1",
    statusText              = "1",
    showTutorials           = "0",
    scriptErrors            = "0",

    -- Camera
    cameraDistanceMax       = "50",
    cameraDistanceMaxFactor = "4",
    cameraSmoothStyle       = "0",  -- Never follow

    -- Nameplates
    nameplateShowEnemies    = "1",
    nameplateShowFriends    = "0",

    -- Action bars (mirrors SetActionBarToggles)
    multiBarBottomLeft      = "1",
    multiBarBottomRight     = "1",
    multiBarRight           = "1",
    multiBarRightTwo        = "1",

    -- Features (these are ALSO reinforced per-character below)
    previewTalents          = "1",
    equipmentManager        = "1",
  },
  actionbars = { bottomLeft = true, bottomRight = true, right = true, rightTwo = true },
}

-- Helpers
local function after(delay, fn)
  local t, f = 0, CreateFrame("Frame")
  f:SetScript("OnUpdate", function(_, e)
    t = t + e
    if t >= delay then
      f:SetScript("OnUpdate", nil)
      fn()
    end
  end)
end

local function safeSetCVar(name, value)
  pcall(SetCVar, name, value)
end

local function applyCVars()
  for k, v in pairs(DEFAULTS.cvars) do
    safeSetCVar(k, v)
  end
  if LoadAddOn then
    pcall(LoadAddOn, "Blizzard_EquipmentManager")
  end
end

local function applyActionBars()
  local bl = DEFAULTS.actionbars.bottomLeft and 1 or 0
  local br = DEFAULTS.actionbars.bottomRight and 1 or 0
  local r1 = DEFAULTS.actionbars.right      and 1 or 0
  local r2 = DEFAULTS.actionbars.rightTwo   and 1 or 0

  if SetActionBarToggles and not InCombatLockdown() then
    pcall(SetActionBarToggles, bl, br, r1, r2)
  end
  -- Mirror via CVars so UIs catch state even if API was blocked
  safeSetCVar("multiBarBottomLeft",  bl)
  safeSetCVar("multiBarBottomRight", br)
  safeSetCVar("multiBarRight",       r1)
  safeSetCVar("multiBarRightTwo",    r2)
end

local function applyDefaults()
  applyCVars()
  applyActionBars()
end

------------------------------------------------------------
-- Per-character first-login defaults for:
--  * previewTalents ("Review talent changes")
--  * equipmentManager (Equipment Manager)
------------------------------------------------------------

local function getCharKey()
  local name = UnitName("player")
  local realm = GetRealmName()
  if not name or not realm then
    return nil
  end
  return name .. "-" .. realm
end

local function applyPerCharacterDefaults()
  if not SV then
    _G.CENTURION_DefaultOptions = _G.CENTURION_DefaultOptions or {}
    SV = _G.CENTURION_DefaultOptions
  end

  SV.perChar = SV.perChar or {}
  local charKey = getCharKey()
  if not charKey then
    dmsg("Per-char: missing charKey; skipping.")
    return
  end

  local pc = SV.perChar[charKey]
  if pc and pc.eqmTalentInit then
    -- This character has already had equipmentManager + previewTalents forced on once.
    dmsg("Per-char already initialized for", charKey)
    return
  end

  dmsg("Per-char first login init for", charKey, "– enabling EM + talent preview")

  -- Force these ON for this character’s first login.
  safeSetCVar("previewTalents", "1")
  safeSetCVar("equipmentManager", "1")

  -- Make sure the Equipment Manager UI is available.
  if LoadAddOn then
    pcall(LoadAddOn, "Blizzard_EquipmentManager")
  end

  SV.perChar[charKey] = {
    eqmTalentInit = true,
    version       = "1.0-perchar",
    firstApplied  = date("%Y-%m-%d %H:%M:%S"),
  }
end

------------------------------------------------------------
-- Event wiring
------------------------------------------------------------

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_ENTERING_WORLD")

local ranThisLogin = false  -- for account-wide first-run block

f:SetScript("OnEvent", function(_, event, arg1, ...)
  if event == "ADDON_LOADED" then
    if arg1 ~= ADDON_NAME then return end
    -- SavedVariables are now loaded for this addon: bind the real table.
    _G.CENTURION_DefaultOptions = _G.CENTURION_DefaultOptions or {}
    SV = _G.CENTURION_DefaultOptions
    dmsg("ADDON_LOADED:", ADDON_NAME, "SV.init=", tostring(SV.initialized))
    return
  end

  -- PLAYER_ENTERING_WORLD — only act if we've seen our ADDON_LOADED
  if not SV then
    -- Shouldn’t happen, but guard anyway.
    _G.CENTURION_DefaultOptions = _G.CENTURION_DefaultOptions or {}
    SV = _G.CENTURION_DefaultOptions
  end

  -- NEW: always run per-character logic, every PEW (it’s self-guarded).
  applyPerCharacterDefaults()

  -- Account-wide "first run" logic stays as before.
  if ranThisLogin then return end
  ranThisLogin = true

  dmsg("PEW: SV.init=", tostring(SV.initialized))
  if SV.initialized then
    dmsg("Already initialized (account-wide); skipping defaults.")
    return
  end

  -- True first run for this account: mark immediately, then apply twice
  SV.initialized  = true
  SV.version      = "1.7-perchar"
  SV.firstApplied = date("%Y-%m-%d %H:%M:%S")
  dmsg("First run (account-wide); applying twice…")

  after(APPLY_DELAY_1, function()
    applyDefaults()
    after(APPLY_DELAY_2, function()
      applyDefaults()
      dmsg("First run complete.")
      -- No auto-ReloadUI; SV persists on normal logout or /reload.
    end)
  end)
end)

------------------------------------------------------------
-- Minimal slash (manual control; prints only when used)
------------------------------------------------------------

SLASH_CENTURIONDEFAULTS1 = "/cent"
SlashCmdList.CENTURIONDEFAULTS = function(msg)
  msg = (msg or ""):lower()
  if not SV then
    _G.CENTURION_DefaultOptions = _G.CENTURION_DefaultOptions or {}
    SV = _G.CENTURION_DefaultOptions
  end

  if msg == "apply" then
    applyDefaults()
    SV.initialized = true
    print("|cff00ff88CENT|r applied and initialized (manual).")
  elseif msg == "reset" then
    SV.initialized = nil
    print("|cff00ff88CENT|r reset (account). Will apply on next login.")
  elseif msg == "status" then
    local charKey = getCharKey() or "unknown"
    local perChar = SV.perChar and SV.perChar[charKey] or nil
    print("|cff00ff88CENT|r init=", tostring(SV.initialized),
          " version=", tostring(SV.version),
          " when=", tostring(SV.firstApplied))
    if perChar then
      print("|cff00ff88CENT|r char(", charKey, ") eqmTalentInit=",
            tostring(perChar.eqmTalentInit),
            " when=", tostring(perChar.firstApplied))
    else
      print("|cff00ff88CENT|r char(", charKey, ") has no per-char init yet.")
    end
  elseif msg == "debug" then
    DEBUG = not DEBUG
    print("|cff00ff88CENT|r debug=", tostring(DEBUG))
  else
    print("|cff00ff88CENT|r /cent apply | /cent reset | /cent status | /cent debug")
  end
end

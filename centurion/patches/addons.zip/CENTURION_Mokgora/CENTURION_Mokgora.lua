-- CENTURION_Mokgora: the duel to the death.
--
-- Mok'gora is an ordinary duel with one rule removed - the blow that would
-- normally stop at one health is allowed to land. Anything goes. The whole
-- ruleset lives on the server (game/Miscellaneous/Mokgora.cpp); this is the
-- face of it: the slash commands, the warning box the challenged player has to
-- answer, and the reminders during the fight that running will not help.
--
-- The addon is not required. Every request it sends has a spoken ".mokgora ..."
-- equivalent and the server writes every answer to the chat frame as well, so a
-- client without it can still fight one - it simply reads the warning as text
-- rather than as a box it has to click.
--
--   sends     CCGAMEREQ  MOKGORA:CHALLENGE[:<name>] | ACCEPT | DECLINE
--                        MOKGORA:WITHDRAW | RULES
--   receives  CCGAME     MOKGORA:RULES:<on>:<range>:<secs>:<ring>:<cowarddays>
--                        MOKGORA:OFFER:<who>:<level>:<class>:<seconds>
--                        MOKGORA:SENT:<who>:<seconds>
--                        MOKGORA:CLOSE:<reason>
--                        MOKGORA:INCOMING:<who>
--                        MOKGORA:BEGIN:<who>
--                        MOKGORA:END:<winner>:<loser>:<how>

local REQUEST_PREFIX = "CCGAME" .. "REQ";
local ANSWER_PREFIX = "CCGAME";

local CLASS_TOKENS = {
	[1] = "WARRIOR", [2] = "PALADIN", [3] = "HUNTER", [4] = "ROGUE",
	[5] = "PRIEST",  [6] = "DEATHKNIGHT", [7] = "SHAMAN", [8] = "MAGE",
	[9] = "WARLOCK", [11] = "DRUID",
};

-- Everything the server has told us about how this realm plays it. Until the
-- RULES line arrives the box words itself for the gentler ruleset, which is the
-- safe way round: it never promises an ending the realm is not going to deliver.
local rules = {
	enabled = false,
	challengeRange = 10,
	bounds = 150,
	seconds = 30,
	cowardDays = 3,
};

-- What you have to type. Blizzard's HARDCORE_DUEL_CONFIRMATION, verbatim -
-- compared case-insensitively, exactly as their EditBoxOnTextChanged does.
local CONFIRMATION = "I AGREE";

-- The offer currently on screen, and the name of whoever we are about to duel.
local offer = nil;
local fightingWith = nil;

-- Who the next duel request is expected from, and when we stopped believing
-- it. The expiry matters: without it, a Mok'gora that fell through would leave
-- a name here that silently accepts an ordinary duel from that person hours
-- later, which is the one mistake this addon must never make.
local expectingDuelWith = nil;
local expectingUntil = 0;

local function ExpectDuelFrom(name)
	expectingDuelWith = name;
	expectingUntil = GetTime() + 15;
end

local function ForgetExpectedDuel()
	expectingDuelWith = nil;
	expectingUntil = 0;
end

local function IsExpectedDuel(name)
	return expectingDuelWith ~= nil
		and name == expectingDuelWith
		and GetTime() <= expectingUntil;
end

local function Send(payload)
	local me = UnitName("player");
	if ( SendAddonMessage and me ) then
		SendAddonMessage(REQUEST_PREFIX, "MOKGORA:" .. payload, "WHISPER", me);
	end
end

local function Print(text)
	if ( DEFAULT_CHAT_FRAME ) then
		DEFAULT_CHAT_FRAME:AddMessage("|cffff2020[Mok'gora]|r " .. text);
	end
end

local function ColouredName(name, classId)
	local token = CLASS_TOKENS[classId or 0];
	local colour = token and RAID_CLASS_COLORS and RAID_CLASS_COLORS[token];
	if ( not colour ) then
		return name;
	end
	return string.format("|cff%02x%02x%02x%s|r",
		math.floor(colour.r * 255), math.floor(colour.g * 255),
		math.floor(colour.b * 255), name);
end

local function ClassName(classId)
	local token = CLASS_TOKENS[classId or 0];
	if ( token and LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[token] ) then
		return LOCALIZED_CLASS_NAMES_MALE[token];
	end
	return "";
end

-- ---------------------------------------------------------------------------
-- the warning box
-- ---------------------------------------------------------------------------
--
-- Built by hand rather than as a StaticPopup. A StaticPopup's text is one small
-- centred paragraph, and this has to be read rather than dismissed: the person
-- clicking Accept is agreeing to lose the character they are looking at.

local box = CreateFrame("Frame", "CenturionMokgoraBox", UIParent);
box:SetWidth(440);
box:SetHeight(400);
box:SetPoint("CENTER", UIParent, "CENTER", 0, 60);
box:SetFrameStrata("FULLSCREEN_DIALOG");
box:SetToplevel(true);
box:EnableMouse(true);
box:SetMovable(true);
box:RegisterForDrag("LeftButton");
box:SetScript("OnDragStart", box.StartMoving);
box:SetScript("OnDragStop", box.StopMovingOrSizing);
box:SetBackdrop({
	bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
	edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
	tile = true, tileSize = 32, edgeSize = 32,
	insets = { left = 11, right = 12, top = 12, bottom = 11 },
});
box:Hide();

local title = box:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
title:SetPoint("TOP", box, "TOP", 0, -20);
title:SetText("|cffff2020M O K ' G O R A|r");

local skull = box:CreateTexture(nil, "ARTWORK");
skull:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull");
skull:SetWidth(32);
skull:SetHeight(32);
skull:SetPoint("RIGHT", title, "LEFT", -10, 0);

local skullRight = box:CreateTexture(nil, "ARTWORK");
skullRight:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull");
skullRight:SetWidth(32);
skullRight:SetHeight(32);
skullRight:SetPoint("LEFT", title, "RIGHT", 10, 0);

local who = box:CreateFontString(nil, "ARTWORK", "GameFontHighlightLarge");
who:SetPoint("TOP", title, "BOTTOM", 0, -14);
who:SetWidth(390);

local body = box:CreateFontString(nil, "ARTWORK", "GameFontHighlight");
body:SetPoint("TOP", who, "BOTTOM", 0, -12);
body:SetWidth(390);
body:SetJustifyH("CENTER");

local stakes = box:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
stakes:SetPoint("TOP", body, "BOTTOM", 0, -14);
stakes:SetWidth(390);
stakes:SetJustifyH("CENTER");

-- The gate. Blizzard does not let you click your way into a Duel to the Death:
-- Accept is disabled until you have TYPED the confirmation word, which is the
-- whole point - a mis-click cannot cost you a character, only a deliberate
-- sentence can. Compared case-insensitively, as their own handler does.
--
-- Everything from here down hangs off the text above it rather than off the
-- bottom of the frame. Anchoring the two halves at opposite ends is what put
-- the edit box on top of the line telling you what to type.
local confirm = CreateFrame("EditBox", "CenturionMokgoraConfirm", box, "InputBoxTemplate");
confirm:SetWidth(170);
confirm:SetHeight(20);
confirm:SetPoint("TOP", stakes, "BOTTOM", 0, -12);
confirm:SetAutoFocus(false);
confirm:SetMaxLetters(24);

local clock = box:CreateFontString(nil, "ARTWORK", "GameFontDisableLarge");
clock:SetPoint("TOP", confirm, "BOTTOM", 0, -8);

local accept = CreateFrame("Button", nil, box, "UIPanelButtonTemplate");
accept:SetWidth(150);
accept:SetHeight(24);
accept:SetPoint("TOPRIGHT", clock, "BOTTOM", -8, -10);
accept:SetText("Accept");

local refuse = CreateFrame("Button", nil, box, "UIPanelButtonTemplate");
refuse:SetWidth(150);
refuse:SetHeight(24);
refuse:SetPoint("TOPLEFT", clock, "BOTTOM", 8, -10);
refuse:SetText("Refuse");

local function HideBox()
	offer = nil;
	box:Hide();
end

accept:SetScript("OnClick", function()
	if ( not offer ) then
		return;
	end

	local mode, name = offer.mode, offer.name;

	if ( mode == "challenge" ) then
		-- Our own challenge, confirmed. Only now does the server hear about it.
		HideBox();
		Send("CHALLENGE:" .. name);
		return;
	end

	-- Remembered before the box goes away: the duel request the server is
	-- about to send has to be answered without asking the player again.
	ExpectDuelFrom(name);
	HideBox();
	Send("ACCEPT");
end);

refuse:SetScript("OnClick", function()
	local mode = offer and offer.mode;
	HideBox();
	-- Backing out of your OWN challenge tells the server nothing, because it
	-- was never told: the challenge is only sent once this box is satisfied.
	if ( mode == "offer" ) then
		Send("DECLINE");
	end
end);

-- Escape refuses. Anything that closes this box without an answer has to be an
-- answer, and for a challenge somebody made of YOU, "no" is the only safe one
-- to assume.
tinsert(UISpecialFrames, "CenturionMokgoraBox");
box:SetScript("OnHide", function()
	if ( offer and offer.mode == "offer" ) then
		offer = nil;
		Send("DECLINE");
	end
	offer = nil;
end);

box:SetScript("OnUpdate", function(self, elapsed)
	if ( not offer or offer.mode ~= "offer" ) then
		return;
	end

	local left = offer.expires - GetTime();
	if ( left <= 0 ) then
		-- The server expires it too and will send CLOSE; this only stops the
		-- clock reading a negative number in between.
		clock:SetText("|cffff2020...|r");
		return;
	end

	clock:SetText(string.format("%d", math.ceil(left)));
end);

-- Accept lives or dies by what is in the box, checked as it is typed.
confirm:SetScript("OnTextChanged", function(self)
	if ( strupper(self:GetText()) == CONFIRMATION ) then
		accept:Enable();
	else
		accept:Disable();
	end
end);

confirm:SetScript("OnEscapePressed", function(self)
	self:ClearFocus();
	box:Hide();
end);

local function ShowOffer(name, level, classId, seconds)
	offer = {
		mode = "offer",
		name = name,
		total = seconds,
		expires = GetTime() + seconds,
	};

	who:SetText(string.format("%s   |cffffffff(level %d %s)|r",
		ColouredName(name, classId), level, ClassName(classId)));

	body:SetText("has challenged you to a duel to the death.\n\n"
		.. "Your opponent will be able to kill you, and death is permanent "
		.. "for a Hardcore character.\n\n"
		.. "There is no concession. Fleeing - leaving the " .. rules.bounds
		.. " yard ring, or logging out - brands you Coward! for "
		.. rules.cowardDays .. " days.");

	stakes:SetText("|cffff2020Type \"I Agree\" to accept the challenge.|r");

	confirm:SetText("");
	accept:Disable();
	box:Show();
	confirm:SetFocus();

	if ( PlaySound ) then
		PlaySound("RaidWarning");
	end
	if ( UIErrorsFrame ) then
		UIErrorsFrame:AddMessage("MOK'GORA - " .. name .. " wants your life", 1.0, 0.1, 0.1, 1.0, 6);
	end
end

-- The challenger's own gate, Blizzard's DUEL_TO_THE_DEATH_CHALLENGE_CONFIRM.
--
-- Nothing reaches the server until this is satisfied: issuing the challenge is
-- as deliberate an act as accepting one, and it is the challenger who is
-- staking a character on a fight they picked. Same box, same typed word.
local function ShowChallengeConfirm(name)
	if ( not name or name == "" ) then
		Print("Target the one you mean to challenge, or name them: /mokgora <name>.");
		return;
	end

	offer = {
		mode = "challenge",
		name = name,
		total = rules.seconds,
		expires = GetTime() + rules.seconds,
	};

	-- Blank: the body sentence already names them, and repeating it as a big
	-- header directly above read as a stutter.
	who:SetText("");

	body:SetText("Are you sure you want to challenge " .. name
		.. " to a duel to the death?\n\n"
		.. "Your opponent will be able to kill you, and death is permanent "
		.. "for a Hardcore character.\n\n"
		.. "There is no concession. Fleeing - leaving the " .. rules.bounds
		.. " yard ring, or logging out - brands you Coward! for "
		.. rules.cowardDays .. " days.");

	stakes:SetText("|cffff2020Type \"I Agree\" to issue the challenge.|r");

	-- No clock on your own challenge: nothing has been sent, so nothing is
	-- running out. The offer box is the only one with a real deadline.
	clock:SetText("");

	confirm:SetText("");
	accept:Disable();
	box:Show();
	confirm:SetFocus();
end

-- ---------------------------------------------------------------------------
-- during the fight
-- ---------------------------------------------------------------------------

local banner = CreateFrame("Frame", "CenturionMokgoraBanner", UIParent);
banner:SetWidth(300);
banner:SetHeight(40);
banner:SetPoint("TOP", UIParent, "TOP", 0, -140);
banner:Hide();

local bannerText = banner:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
bannerText:SetAllPoints(banner);
bannerText:SetJustifyH("CENTER");

local function ShowBanner(opponent)
	fightingWith = opponent;
	bannerText:SetText("|cffff2020MOK'GORA|r\n|cffffffff" .. opponent .. "|r");
	banner:Show();
end

local function HideBanner()
	fightingWith = nil;
	banner:Hide();
end

-- ---------------------------------------------------------------------------
-- slash commands
-- ---------------------------------------------------------------------------

SLASH_CENTURIONMOKGORA1 = "/mokgora";
SLASH_CENTURIONMOKGORA2 = "/makgora";
SLASH_CENTURIONMOKGORA3 = "/mak";

SlashCmdList["CENTURIONMOKGORA"] = function(text)
	local argument = string.lower(string.gsub(text or "", "^%s*(.-)%s*$", "%1"));

	if ( argument == "accept" or argument == "yes" ) then
		-- Typed rather than clicked, so the box never set this up.
		if ( offer ) then
			ExpectDuelFrom(offer.name);
		end
		Send("ACCEPT");
		HideBox();
		return;
	end
	if ( argument == "decline" or argument == "refuse" or argument == "no" ) then
		Send("DECLINE");
		HideBox();
		return;
	end
	if ( argument == "withdraw" or argument == "cancel" ) then
		Send("WITHDRAW");
		return;
	end
	if ( argument == "help" or argument == "?" ) then
		Print("/mokgora <name> - challenge someone to a duel to the death.");
		Print("/mokgora with a target and no name challenges your target.");
		Print("/mokgora accept | decline | withdraw");
		Print("The loser dies. Fleeing brands you Coward! for "
			.. rules.cowardDays .. " days instead. There is no forfeit.");
		return;
	end

	-- Anything else is a name, and nothing at all means "whoever I am looking
	-- at". The name is sent as it was typed: the server matches it, and
	-- lower-casing it here would break a match the server does properly.
	local name = string.gsub(text or "", "^%s*(.-)%s*$", "%1");
	if ( name == "" and UnitExists("target") and UnitIsPlayer("target") ) then
		name = UnitName("target");
	end

	-- Confirmed first, sent second.
	ShowChallengeConfirm(name);
end

-- ---------------------------------------------------------------------------
-- the right-click menu
-- ---------------------------------------------------------------------------
--
-- "Duel to the Death", sitting directly under "Duel" on any unit menu that
-- offers a duel at all - which is exactly the set that should offer this, and
-- is why the entry is placed by finding DUEL rather than by naming menus. The
-- SELF and NPC menus have no DUEL, so they quietly get nothing.

if ( UnitPopupButtons and UnitPopupMenus ) then
	UnitPopupButtons["CENTURION_MAKGORA"] = { text = "Duel to the Death", dist = 0 };

	for _, entries in pairs(UnitPopupMenus) do
		for index = 1, table.getn(entries) do
			if ( entries[index] == "DUEL" ) then
				table.insert(entries, index + 1, "CENTURION_MAKGORA");
				break;
			end
		end
	end

	-- hooksecurefunc rather than a replacement: UnitPopup_OnClick is Blizzard's
	-- and other addons hook it too. Ours runs after theirs and only looks at
	-- its own token.
	hooksecurefunc("UnitPopup_OnClick", function(self)
		if ( self.value ~= "CENTURION_MAKGORA" ) then
			return;
		end

		local dropdown = UIDROPDOWNMENU_INIT_MENU;
		if ( not dropdown ) then
			return;
		end

		-- The menu knows its subject either as a unit token (portrait, party
		-- frame) or as a bare name (chat, who-list, guild roster).
		local name = dropdown.name;
		if ( dropdown.unit and UnitExists(dropdown.unit) ) then
			name = UnitName(dropdown.unit);
		end

		ShowChallengeConfirm(name);
	end);
end

-- ---------------------------------------------------------------------------
-- wiring
-- ---------------------------------------------------------------------------

local driver = CreateFrame("Frame");
driver:RegisterEvent("CHAT_MSG_ADDON");
driver:RegisterEvent("PLAYER_ENTERING_WORLD");
driver:RegisterEvent("DUEL_REQUESTED");
driver:RegisterEvent("DUEL_FINISHED");
driver:RegisterEvent("DUEL_OUTOFBOUNDS");
driver:RegisterEvent("DUEL_INBOUNDS");

local function HandleAnswer(verb, payload)
	if ( verb == "RULES" ) then
		-- Field by field rather than one anchored pattern: a server that grows
		-- another field should not silently stop being understood, which is
		-- what an "exactly five numbers" match would do.
		local fields = {};
		for value in string.gmatch(payload, "[^:]+") do
			table.insert(fields, value);
		end
		if ( table.getn(fields) >= 4 ) then
			rules.enabled = fields[1] == "1";
			rules.challengeRange = tonumber(fields[2]) or 10;
			rules.seconds = tonumber(fields[3]) or 30;
			rules.bounds = tonumber(fields[4]) or 150;
			rules.cowardDays = tonumber(fields[5]) or 3;
		end
		return;
	end

	if ( verb == "OFFER" ) then
		local name, level, classId, seconds =
			string.match(payload, "^([^:]+):(%d+):(%d+):(%d+)$");
		if ( name ) then
			ShowOffer(name, tonumber(level) or 1, tonumber(classId) or 0, tonumber(seconds) or 30);
		end
		return;
	end

	if ( verb == "SENT" ) then
		local name, seconds = string.match(payload, "^([^:]+):(%d+)$");
		if ( name ) then
			Print("You have challenged " .. name .. ". " .. seconds .. " seconds to answer.");
		end
		return;
	end

	if ( verb == "CLOSE" ) then
		HideBox();
		return;
	end

	if ( verb == "INCOMING" ) then
		-- The duel request that IS this Mok'gora is about to arrive. Both
		-- sides get told, because the challenger's client is sent the same
		-- request packet and would otherwise be asked to confirm a duel it
		-- started itself.
		ExpectDuelFrom(payload);
		return;
	end

	if ( verb == "BEGIN" ) then
		ShowBanner(payload);
		return;
	end

	if ( verb == "END" ) then
		HideBanner();
		ForgetExpectedDuel();
		return;
	end

end

driver:SetScript("OnEvent", function(self, event, arg1, arg2, arg3, arg4)
	if ( event == "PLAYER_ENTERING_WORLD" ) then
		-- A request sent into a loading screen is dropped, so ask once the
		-- world is actually there. The answer words the box - and it is the
		-- ONLY thing asked for here. This used to ask for the win/loss tally
		-- too, which meant the realm read your record back to you on every
		-- loading screen, forever. Nothing is requested on a zone change but
		-- the rules, and nothing is printed.
		Send("RULES");
		return;
	end

	if ( event == "DUEL_REQUESTED" ) then
		-- arg1 is the challenger's name. If this is the Mok'gora we just
		-- agreed to, answer it: the player has already read a far plainer
		-- question than the one the stock popup asks.
		if ( IsExpectedDuel(arg1) ) then
			ForgetExpectedDuel();
			if ( StaticPopup_Hide ) then
				StaticPopup_Hide("DUEL_REQUESTED");
			end
			if ( AcceptDuel ) then
				AcceptDuel();
			end
		end
		return;
	end

	if ( event == "DUEL_FINISHED" ) then
		HideBanner();
		ForgetExpectedDuel();
		return;
	end

	if ( event == "DUEL_OUTOFBOUNDS" ) then
		if ( fightingWith and UIErrorsFrame ) then
			UIErrorsFrame:AddMessage("RETURN TO THE MOK'GORA OR DIE", 1.0, 0.1, 0.1, 1.0, 10);
		end
		return;
	end

	if ( event == "DUEL_INBOUNDS" ) then
		if ( fightingWith and UIErrorsFrame ) then
			UIErrorsFrame:AddMessage("Back in the Mok'gora.", 1.0, 0.8, 0.1, 1.0, 4);
		end
		return;
	end

	if ( event ~= "CHAT_MSG_ADDON" or type(arg2) ~= "string" ) then
		return;
	end

	-- The realm's own channel, whispered to ourselves. Anything arriving from
	-- anywhere else is not the server talking.
	if ( arg1 ~= ANSWER_PREFIX or arg3 ~= "WHISPER" or arg4 ~= UnitName("player") ) then
		return;
	end

	local verb, payload = string.match(arg2, "^MOKGORA:([A-Z]+):?(.*)$");
	if ( verb ) then
		HandleAnswer(verb, payload or "");
	end
end);

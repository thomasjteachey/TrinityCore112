-- DiminishStandalone.lua
-- 3.3.5a, aura + combat-log DR
-- DR is 15s
-- Per-GUID DR (remembered), but icons only show on your current TARGET frame
-- When you retarget someone who actually has DR running, we repaint with the correct remaining cooldown
-- Your 32px-below anchoring
-- FIX: if a new DR event happens while an icon is already up, we hard-refresh that icon (cooldown back to 15s, border updated)

local function chat(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff8800[Diminish]|r " .. msg)
    end
end

------------------------------------------------------------
-- spellID -> DR category
------------------------------------------------------------
local TRACKED = {
    -- incap / poly / sap / gouge
    [118]   = "incapacitate",
    [12824] = "incapacitate",
    [12825] = "incapacitate",
    [12826] = "incapacitate",
    [28271] = "incapacitate",
    [28272] = "incapacitate",
    [20066] = "incapacitate",
    [6770]  = "incapacitate",
    [2070]  = "incapacitate",
    [11297] = "incapacitate",
    [1776]  = "incapacitate",
    [11286] = "incapacitate",
    [13327] = "incapacitate",
    [60210] = "incapacitate",

    -- sleeps / wyvern
    [2637]  = "sleep",
    [18657] = "sleep",
    [18658] = "sleep",
    [19386] = "sleep",
    [24132] = "sleep",
    [24133] = "sleep",
    [27068] = "sleep",

    -- disorients / cyclone / blind / dragon's breath
    [33786] = "disorient",
    [2094]  = "disorient",  -- Blind
    [31661] = "disorient",
    [33041] = "disorient",
    [33042] = "disorient",
    [33043] = "disorient",

    -- fears
    [5782]  = "fear",
    [6213]  = "fear",
    [6215]  = "fear",
    [8122]  = "fear",
    [8124]  = "fear",
    [10888] = "fear",
    [10890] = "fear",
    [5484]  = "fear",
    [17928] = "fear",
    [6358]  = "fear",
    [1513]  = "fear",
    [14326] = "fear",
    [14327] = "fear",
    [5246]  = "fear",

    -- stuns
    [5211]  = "stun",
    [6798]  = "stun",
    [8983]  = "stun",
    [9005]  = "stun",
    [9823]  = "stun",
    [9827]  = "stun",
    [27006] = "stun",
    [1833]  = "stun",
    [12809] = "stun",
    [20253] = "stun",
    [20614] = "stun",
    [25273] = "stun",
    [25274] = "stun",
    [7922]  = "stun",
    [20549] = "stun",
    [853]   = "stun",
    [5588]  = "stun",
    [5589]  = "stun",
    [10308] = "stun",
    [24394] = "stun",
    [82423] = "stun",  -- your custom “like Bash”

    -- kidney separate
    [408]   = "kidney_shot",
    [8643]  = "kidney_shot",

    -- roots
    [339]   = "root",
    [1062]  = "root",
    [5195]  = "root",
    [5196]  = "root",
    [9852]  = "root",
    [9853]  = "root",
    [26989] = "root",
    [122]   = "root",
    [865]   = "root",
    [6131]  = "root",
    [10230] = "root",
    [27088] = "root",
    [33395] = "root",
    [19185] = "root",
    [19306] = "root",
    [81430] = "root",        -- your custom root
    [81851] = "random_root", -- uncontrolled root

    -- freezing trap
    [3355]  = "freezing_trap",
    [14308] = "freezing_trap",
    [14309] = "freezing_trap",

    -- scatter
    [19503] = "scatter_shot",

    -- death coil
    [6789]  = "death_coil",
    [17925] = "death_coil",
    [17926] = "death_coil",
    [27223] = "death_coil",

    -- Wrath disarms + customs
    [676]   = "disarm",
    [51722] = "disarm",
    [64044] = "disarm",
    [64058] = "disarm",
    [53537] = "disarm",
    [53543] = "disarm",
    [53544] = "disarm",
    [53545] = "disarm",
    [53546] = "disarm",
    [81492] = "disarm",
    [81493] = "disarm",

    -- Wrath silences + custom
    [15487] = "silence",
    [18469] = "silence",
    [55021] = "silence",
    [19647] = "silence",
    [24259] = "silence",
    [34490] = "silence",
    [47476] = "silence",
    [1330]  = "silence",
    [18425] = "silence",
    [18498] = "silence",
    [81302] = "silence",
}

------------------------------------------------------------
-- config / DB
------------------------------------------------------------
local DR_RESET      = 15   -- 15s DR window
local POLL_INTERVAL = 0.20
local DR_COLORS = {
    [1] = {0, 1, 0, 1},
    [2] = {1, 1, 0, 1},
    [3] = {1, 0, 0, 1},
}

DiminishStandaloneDB = DiminishStandaloneDB or {}
local defaults = {
    iconSize = 24,
    spacing  = 2,
    greyOut  = true,
}

local function copyDefaults(src, dst)
    if type(dst) ~= "table" then dst = {} end
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = copyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
    return dst
end

------------------------------------------------------------
-- frame + state
------------------------------------------------------------
local f = CreateFrame("Frame", "DiminishStandaloneFrame", UIParent)

-- ONLY track target
f.units = { "target" }

f.containers  = {}
f.drState     = {}  -- guid -> category -> {step, reset}
f.drIcons     = {}  -- guid -> category -> texture
f.activeAuras = {}  -- guid -> spellID -> info
f.activeIcons = {}  -- guid -> category -> iconFrame
f.guidToUnit  = {}  -- guid -> unit (only 'target' used now)
f.unitGuids   = {}  -- unit -> guid

------------------------------------------------------------
-- anchoring (target only)
------------------------------------------------------------
local function getAnchorForUnit(unit)
    if unit == "target" then
        return TargetFrame
    end
    return UIParent
end

local function clearContainerForUnit(unit)
    local c = f.containers[unit]
    if c then
        for _, icon in pairs(c.icons) do
            icon:Hide()
        end
    end
end

local function createContainer(unit)
    local parent = getAnchorForUnit(unit) or UIParent
    local c = CreateFrame("Frame", nil, parent)

    -- IMPORTANT: put the container behind other targetframe elements
    c:SetFrameStrata("BACKGROUND")
    c:SetFrameLevel(1)

    c:SetSize(1, 1)
    c:SetPoint("TOPLEFT", parent, "BOTTOMLEFT", 0, -32) -- your anchor
    c.icons = {}
    f.containers[unit] = c
    return c
end

local function reposition(container)
    local last
    for _, icon in pairs(container.icons) do
        if icon:IsShown() then
            icon:ClearAllPoints()
            if not last then
                icon:SetPoint("LEFT", container, "LEFT", 0, 0)
            else
                icon:SetPoint("LEFT", last, "RIGHT", DiminishStandaloneDB.spacing, 0)
            end
            last = icon
        end
    end
end

------------------------------------------------------------
-- icon creation
------------------------------------------------------------
local function getIcon(unit, category)
    local c = f.containers[unit] or createContainer(unit)
    if c.icons[category] then
        return c.icons[category], c
    end

    local icon = CreateFrame("Frame", nil, c)

    -- also force icons themselves to background strata,
    -- so they never sit on top of debuffs / cast bars.
    icon:SetFrameStrata("BACKGROUND")
    icon:SetFrameLevel(c:GetFrameLevel() + 1)

    icon:SetSize(DiminishStandaloneDB.iconSize, DiminishStandaloneDB.iconSize)

    icon.tex = icon:CreateTexture(nil, "ARTWORK")
    icon.tex:SetAllPoints()

    icon.cd = CreateFrame("Cooldown", nil, icon, "CooldownFrameTemplate")
    icon.cd:SetAllPoints()

    icon.border = icon:CreateTexture(nil, "OVERLAY")
    icon.border:SetAllPoints(icon)
    icon.border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    icon.border:SetTexCoord(0.2, 0.8, 0.2, 0.8)
    icon.border:SetVertexColor(0, 1, 0, 1)

    icon:Hide()
    c.icons[category] = icon
    return icon, c
end

------------------------------------------------------------
-- show existing DR for a guid on a specific unit
-- called when we RETARGET someone
------------------------------------------------------------
local function showDRForGUIDOnUnit(guid, unit)
    local drs = f.drState[guid]
    if not drs then return end
    local now = GetTime()

    for category, data in pairs(drs) do
        local remaining = data.reset - now
        if remaining > 0 then
            -- if it's already shown on this unit, don't repaint
            if not (f.activeIcons[guid] and f.activeIcons[guid][category] and f.activeIcons[guid][category]:IsShown()) then
                local icon, container = getIcon(unit, category)
                local texture = (f.drIcons[guid] and f.drIcons[guid][category]) or "Interface\\Icons\\INV_Misc_QuestionMark"

                icon.tex:SetTexture(texture)
                if icon.tex.SetDesaturated then
                    icon.tex:SetDesaturated(DiminishStandaloneDB.greyOut)
                end
                icon.tex:SetVertexColor(1, 1, 1, 1)

                -- correct progress: start in the past
                local elapsed = DR_RESET - remaining
                if elapsed < 0 then elapsed = 0 end
                icon.cd:SetCooldown(now - elapsed, DR_RESET)

                local col = DR_COLORS[data.step] or DR_COLORS[3]
                icon.border:SetVertexColor(col[1], col[2], col[3], col[4])

                icon:Show()
                reposition(container)

                f.activeIcons[guid] = f.activeIcons[guid] or {}
                f.activeIcons[guid][category] = icon
            end
        end
    end
end

------------------------------------------------------------
-- DR start / expire
-- IMPORTANT: if an icon for this guid/category is already visible, we refresh THAT icon instead of doing nothing
------------------------------------------------------------
local function startDRForGUID(guid, category, iconTexture, spellID)
    local now = GetTime()
    f.drState[guid] = f.drState[guid] or {}

    local catState = f.drState[guid][category]
    local step = 1
    if catState and catState.reset > now then
        step = catState.step + 1
    end
    f.drState[guid][category] = {
        step  = step,
        reset = now + DR_RESET,
    }

    -- remember icon
    f.drIcons[guid] = f.drIcons[guid] or {}
    f.drIcons[guid][category] = iconTexture or (spellID and GetSpellTexture(spellID)) or f.drIcons[guid][category] or "Interface\\Icons\\INV_Misc_QuestionMark"

    -- if we already have an icon visible for this guid/category, REFRESH it right now
    local activeIcon = f.activeIcons[guid] and f.activeIcons[guid][category]
    if activeIcon and activeIcon:IsShown() then
        -- update texture (in case this DR came from a different spell in same category)
        activeIcon.tex:SetTexture(f.drIcons[guid][category])
        if activeIcon.tex.SetDesaturated then
            activeIcon.tex:SetDesaturated(DiminishStandaloneDB.greyOut)
        end
        activeIcon.tex:SetVertexColor(1, 1, 1, 1)

        -- reset cooldown to full 15s
        activeIcon.cd:SetCooldown(now, DR_RESET)

        -- update border color for new step
        local col = DR_COLORS[step] or DR_COLORS[3]
        activeIcon.border:SetVertexColor(col[1], col[2], col[3], col[4])
        return
    end

    -- else: if guid is currently our TARGET, show now
    local unit = f.guidToUnit[guid]
    if unit == "target" and UnitExists("target") and UnitGUID("target") == guid then
        showDRForGUIDOnUnit(guid, "target")
    end
end

local function clearExpiredDR()
    local now = GetTime()
    for guid, cats in pairs(f.drState) do
        for cat, data in pairs(cats) do
            if now >= data.reset then
                if f.activeIcons[guid] and f.activeIcons[guid][cat] then
                    f.activeIcons[guid][cat]:Hide()
                    f.activeIcons[guid][cat] = nil
                end
                cats[cat] = nil
            end
        end
        if not next(cats) then
            f.drState[guid] = nil
            f.drIcons[guid] = nil
            f.activeIcons[guid] = nil
        end
    end
end

------------------------------------------------------------
-- scan a unit (aura-based) – TARGET ONLY
------------------------------------------------------------
local function scanUnit(unit)
    if unit ~= "target" then
        return
    end

    if not UnitExists(unit) then
        clearContainerForUnit(unit)
        f.unitGuids[unit] = nil
        return
    end

    local guid = UnitGUID(unit)
    if not guid then return end

    local prevGuid = f.unitGuids[unit]
    if prevGuid and prevGuid ~= guid then
        -- different mob in this frame -> hide icons
        clearContainerForUnit(unit)
    end

    f.unitGuids[unit] = guid
    f.guidToUnit[guid] = unit

    -- repaint DR for this unit, if we have it
    showDRForGUIDOnUnit(guid, unit)

    local seen = {}
    local i = 1
    while true do
        local name, _, icon, _, _, _, _, _, _, _, spellID = UnitDebuff(unit, i)
        if not name then break end
        local category = TRACKED[spellID]
        if category then
            seen[spellID] = true
            f.activeAuras[guid] = f.activeAuras[guid] or {}
            f.activeAuras[guid][spellID] = {
                category = category,
                icon     = icon,
                spellID  = spellID,
            }
            -- update remembered icon
            f.drIcons[guid] = f.drIcons[guid] or {}
            f.drIcons[guid][category] = icon or f.drIcons[guid][category]
        end
        i = i + 1
    end

    -- detect ended auras
    local ga = f.activeAuras[guid]
    if ga then
        for spellID, info in pairs(ga) do
            if not seen[spellID] then
                startDRForGUID(guid, info.category, info.icon, info.spellID)
                ga[spellID] = nil
            end
        end
        if not next(ga) then
            f.activeAuras[guid] = nil
        end
    end
end

------------------------------------------------------------
-- combat log (3.3.5 style)
------------------------------------------------------------
local function handleCombatLog(timestamp, subevent, hideCaster,
                               srcGUID, srcName, srcFlags,
                               destGUID, destName, destFlags,
                               spellID, spellName, spellSchool)
    if not spellID or not destGUID then return end
    local category = TRACKED[spellID]
    if not category then return end

    if subevent == "SPELL_AURA_APPLIED" or subevent == "SPELL_AURA_REFRESH" then
        f.activeAuras[destGUID] = f.activeAuras[destGUID] or {}
        f.activeAuras[destGUID][spellID] = {
            category = category,
            icon     = GetSpellTexture(spellID),
            spellID  = spellID,
        }
        -- remember icon
        f.drIcons[destGUID] = f.drIcons[destGUID] or {}
        f.drIcons[destGUID][category] = GetSpellTexture(spellID) or f.drIcons[destGUID][category]
    elseif subevent == "SPELL_AURA_REMOVED" then
        local info = f.activeAuras[destGUID] and f.activeAuras[destGUID][spellID]
        local icon = info and info.icon or GetSpellTexture(spellID)
        startDRForGUID(destGUID, category, icon, spellID)
        if f.activeAuras[destGUID] then
            f.activeAuras[destGUID][spellID] = nil
            if not next(f.activeAuras[destGUID]) then
                f.activeAuras[destGUID] = nil
            end
        end
    end
end

------------------------------------------------------------
-- OnUpdate
------------------------------------------------------------
local pollElapsed = 0
f:SetScript("OnUpdate", function(self, elapsed)
    pollElapsed = pollElapsed + elapsed
    if pollElapsed >= POLL_INTERVAL then
        -- only scan target
        scanUnit("target")
        pollElapsed = 0
    end

    clearExpiredDR()
end)

------------------------------------------------------------
-- events
------------------------------------------------------------
f:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        DiminishStandaloneDB = copyDefaults(defaults, DiminishStandaloneDB)
    elseif event == "UNIT_AURA" then
        local unit = ...
        if unit == "target" then
            scanUnit("target")
        end
    elseif event == "PLAYER_TARGET_CHANGED" then
        -- ALWAYS clear the target frame first
        clearContainerForUnit("target")
        f.unitGuids["target"] = nil

        if UnitExists("target") then
            local guid = UnitGUID("target")
            f.unitGuids["target"] = guid
            f.guidToUnit[guid] = "target"
            -- only repaint if THIS guid actually has DR
            showDRForGUIDOnUnit(guid, "target")
        end
    elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
        -- 3.3.5a style: args come directly from "..."
        handleCombatLog(...)
    end
end)

f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("UNIT_AURA")
f:RegisterEvent("PLAYER_TARGET_CHANGED")
f:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

------------------------------------------------------------
-- slash
------------------------------------------------------------
SLASH_DIMINISH1 = "/diminish"
SlashCmdList["DIMINISH"] = function()
    local unit = "target"
    if not UnitExists(unit) then
        chat("target something first.")
        return
    end
    local guid = UnitGUID(unit)
    startDRForGUID(guid, "incapacitate", GetSpellTexture(118), 118)
    chat("test DR icon shown on target.")
end

SLASH_DIMGREY1 = "/dimgrey"
SlashCmdList["DIMGREY"] = function()
    DiminishStandaloneDB.greyOut = not DiminishStandaloneDB.greyOut
    chat("grey-out is now: " .. tostring(DiminishStandaloneDB.greyOut))
end

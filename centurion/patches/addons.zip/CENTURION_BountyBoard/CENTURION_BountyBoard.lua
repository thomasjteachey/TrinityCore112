-- CENTURION_BountyBoard: the board in every contested-zone inn.
--
-- Every inn in a contested zone has a wanted board. Clicking it opens this: the
-- contested zones down the left, the notices for the chosen one pinned on the
-- right, and any notice opened into a full poster - what the bot is, what it
-- has killed, and every piece of gear its death would leave in the cache.
--
-- It is the GM Bot Stats window cut down to what a death pays out. Where a bot
-- stands, how aggressive it is and what coin it carries stay with the GMs; the
-- server never sends them here (scripts/Custom/custom_bounty_board.cpp).
--
--   receives  CCGAME     BBOP:<zoneId>                       a board was clicked
--                        BBZL:<zoneId>,<count>,<name>;...    zones with notices
--                        BBZE:<zones>                        end of the zone list
--                        BBRS:<zoneId>|<notice>;...          one zone's notices
--                        BBRE:<zoneId>|<count>               end of them
--                        BBPI:<guid>|<spoil>;...             one bot's spoils
--                        BBPT:<guid>|<t1>,<t2>,<t3>|           the talent split
--                        BBPE:<guid>|<1 still here, 0 gone>
--                        BBCL:far                            walked away
--   sends     CCGAMEREQ  BOUNTY:OPEN:<zoneId> | ZONE:<zoneId> | BOT:<guid>
--
-- Notices can be filtered by class and by a level range, so a player can hunt
-- for the gear they want; the filter is remembered per character. "Every
-- contested zone" heads the zone list and reads all of them at once - asked for
-- one zone at a time, a few a second, inside the server's request budget.
--
-- The board click itself still opens an ordinary gossip menu - that is what a
-- client without this addon reads the notices through - so the menu is closed
-- here the moment the board takes over.

local REQUEST_PREFIX = "CCGAME" .. "REQ"

local FW, FH = 768, 500
local NOTICES_PER_PAGE = 9

local INK   = { 40 / 255, 24 / 255, 6 / 255 }
local BLOOD = { 110 / 255, 12 / 255, 8 / 255 }

local CLASS_TOKEN = {
	[1] = "WARRIOR", [2] = "PALADIN", [3] = "HUNTER", [4] = "ROGUE",
	[5] = "PRIEST",  [6] = "DEATHKNIGHT", [7] = "SHAMAN", [8] = "MAGE",
	[9] = "WARLOCK", [11] = "DRUID",
}

local RACE_NAME = {
	[1] = "Human", [2] = "Orc", [3] = "Dwarf", [4] = "Night Elf", [5] = "Undead",
	[6] = "Tauren", [7] = "Gnome", [8] = "Troll", [10] = "Blood Elf", [11] = "Draenei",
}

-- TalentTab.dbc, in the server's 0/1/2 order. The client can only ask
-- GetTalentTabInfo about its own class, so the names and icons of everybody
-- else's trees are kept here.
local TREES = {
	[1] = { { "Arms", "Ability_Rogue_Eviscerate" }, { "Fury", "Ability_Warrior_InnerRage" }, { "Protection", "INV_Shield_06" } },
	[2] = { { "Holy", "Spell_Holy_HolyBolt" }, { "Protection", "Spell_Holy_DevotionAura" }, { "Retribution", "Spell_Holy_AuraOfLight" } },
	[3] = { { "Beast Mastery", "Ability_Hunter_BeastTaming" }, { "Marksmanship", "Ability_Marksmanship" }, { "Survival", "Ability_Hunter_SwiftStrike" } },
	[4] = { { "Assassination", "Ability_Rogue_Eviscerate" }, { "Combat", "Ability_BackStab" }, { "Subtlety", "Ability_Stealth" } },
	[5] = { { "Discipline", "Spell_Holy_WordFortitude" }, { "Holy", "Spell_Holy_GuardianSpirit" }, { "Shadow", "Spell_Shadow_ShadowWordPain" } },
	[6] = { { "Blood", "Spell_Deathknight_BloodPresence" }, { "Frost", "Spell_Deathknight_FrostPresence" }, { "Unholy", "Spell_Deathknight_UnholyPresence" } },
	[7] = { { "Elemental", "Spell_Nature_Lightning" }, { "Enhancement", "Spell_Nature_LightningShield" }, { "Restoration", "Spell_Nature_MagicImmunity" } },
	[8] = { { "Arcane", "Spell_Holy_MagicalSentry" }, { "Fire", "Spell_Fire_FireBolt02" }, { "Frost", "Spell_Frost_FrostBolt02" } },
	[9] = { { "Affliction", "Spell_Shadow_DeathCoil" }, { "Demonology", "Spell_Shadow_Metamorphosis" }, { "Destruction", "Spell_Shadow_RainOfFire" } },
	[11] = { { "Balance", "Spell_Nature_StarFall" }, { "Feral", "Ability_Racial_BearForm" }, { "Restoration", "Spell_Nature_HealingTouch" } },
}

------------------------------------------------------------------
-- state
------------------------------------------------------------------
local zones = {}            -- [zoneId] = { name, count }
local zoneOrder = {}        -- the list as drawn: the board's own zone first
local incomingZones = {}

local notices = {}          -- [zoneId] = { notice, ... }, once complete
local incomingNotices = {}  -- [zoneId] = notices still arriving

local posters = {}          -- [guid] = { state, items, points }

local boardZone, shownZone, shownPoster

-- The zone list's first row: every contested zone at once.
local ALL_ZONES = 0
local allZones = { name = "Every contested zone", count = 0 }

-- The filter, saved per character. nil class means every class; a level bound
-- of nil means no bound on that side.
CENTURION_BountyBoardFilter = CENTURION_BountyBoardFilter or {}
local function Filter() return CENTURION_BountyBoardFilter end

-- When each zone's notices last arrived, so the every-zone view only asks again
-- for what has gone stale.
local fetchedAt = {}
local fetchQueue = {}
local page = 1
local zoneScroll = 0

-- The board's gossip menu, due any moment after BBOP. Kept short so a gossip
-- window opened later on somebody else is never swallowed.
local expectGossipUntil = 0

local function Request(payload)
	local me = UnitName("player")
	if SendAddonMessage and me then
		SendAddonMessage(REQUEST_PREFIX, "BOUNTY:" .. payload, "WHISPER", me)
	end
end

local function TreeOf(points)
	local best = 1
	for i = 2, 3 do
		if (points[i] or 0) > (points[best] or 0) then
			best = i
		end
	end
	return best
end

local function SpecName(class, points)
	local trees = TREES[class]
	return trees and trees[TreeOf(points)][1] or ""
end

local function ClassName(class)
	local token = CLASS_TOKEN[class]
	return token and LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[token] or ""
end

local function SetInk(fs, colour)
	fs:SetTextColor(colour[1], colour[2], colour[3])
end

------------------------------------------------------------------
-- items
------------------------------------------------------------------
-- An off-screen tooltip that warms the item cache. GetItemInfo only answers
-- from the cache, and 3.3.5 has no event for when an answer lands, so every
-- item on a board is asked for the moment it arrives; by the time anybody
-- hovers it the tooltip has something to show.
local scanTip = CreateFrame("GameTooltip", "CENTURION_BountyBoardScanTooltip", UIParent, "GameTooltipTemplate")
scanTip:SetOwner(UIParent, "ANCHOR_NONE")

local function Warm(itemString)
	if itemString and not GetItemInfo(itemString) then
		scanTip:SetOwner(UIParent, "ANCHOR_NONE")
		scanTip:SetHyperlink(itemString)
	end
end

local function FullLink(itemString, quality)
	local _, link = GetItemInfo(itemString)
	if link then
		return link
	end
	-- The client names an uncached item when it draws the line, so a
	-- hand-built link still reads properly in chat.
	local colour = ITEM_QUALITY_COLORS[quality or 1]
	return (colour and colour.hex or "|cffffffff") .. "|H" .. itemString .. "|h[item]|h|r"
end

local function ItemClick(itemString, quality)
	if not itemString then
		return
	end
	if IsModifiedClick("CHATLINK") then
		if ChatEdit_InsertLink then
			ChatEdit_InsertLink(FullLink(itemString, quality))
		end
	elseif IsModifiedClick("DRESSUP") then
		if DressUpItemLink then
			DressUpItemLink(FullLink(itemString, quality))
		end
	end
end

-- Four hairlines in the item's quality colour. UI-ActionButton-Border is a
-- soft glow drawn far wider than the icon, and at icon size it collapses into
-- a coloured blob.
local function AddEdges(button, icon)
	button.edge = {}
	for e = 1, 4 do
		local t = button:CreateTexture(nil, "OVERLAY")
		t:SetTexture("Interface\\Buttons\\WHITE8X8")
		button.edge[e] = t
	end
	button.edge[1]:SetPoint("TOPLEFT", icon, "TOPLEFT")
	button.edge[1]:SetPoint("TOPRIGHT", icon, "TOPRIGHT")
	button.edge[1]:SetHeight(1)
	button.edge[2]:SetPoint("BOTTOMLEFT", icon, "BOTTOMLEFT")
	button.edge[2]:SetPoint("BOTTOMRIGHT", icon, "BOTTOMRIGHT")
	button.edge[2]:SetHeight(1)
	button.edge[3]:SetPoint("TOPLEFT", icon, "TOPLEFT")
	button.edge[3]:SetPoint("BOTTOMLEFT", icon, "BOTTOMLEFT")
	button.edge[3]:SetWidth(1)
	button.edge[4]:SetPoint("TOPRIGHT", icon, "TOPRIGHT")
	button.edge[4]:SetPoint("BOTTOMRIGHT", icon, "BOTTOMRIGHT")
	button.edge[4]:SetWidth(1)
end

local function SetEdgeQuality(button, quality)
	local colour = ITEM_QUALITY_COLORS[quality or 1]
	for e = 1, 4 do
		if colour and (quality or 0) >= 2 then
			button.edge[e]:SetVertexColor(colour.r, colour.g, colour.b)
			button.edge[e]:Show()
		else
			button.edge[e]:Hide()
		end
	end
end

local function MakeItemButton(parent, size)
	local b = CreateFrame("Button", nil, parent)
	b:SetWidth(size)
	b:SetHeight(size)
	b.icon = b:CreateTexture(nil, "ARTWORK")
	b.icon:SetAllPoints(b)
	b.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
	AddEdges(b, b.icon)
	b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
	b:RegisterForClicks("LeftButtonUp")
	b:SetScript("OnEnter", function(self)
		if self.itemString then
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:SetHyperlink(self.itemString)
			GameTooltip:Show()
		end
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	b:SetScript("OnClick", function(self)
		ItemClick(self.itemString, self.quality)
	end)
	b:Hide()
	return b
end

local function ShowItem(b, id, quality, itemString)
	b.itemString = itemString or ("item:" .. id)
	b.quality = quality
	b.icon:SetTexture(GetItemIcon(id) or "Interface\\Icons\\INV_Misc_QuestionMark")
	SetEdgeQuality(b, quality)
	b:Show()
end

------------------------------------------------------------------
-- fonts
------------------------------------------------------------------
local function MakeFont(name, file, size, colour, shadow)
	local f = CreateFont(name)
	f:SetFont(file, size)
	f:SetTextColor(colour[1], colour[2], colour[3])
	if shadow then
		f:SetShadowColor(shadow[1], shadow[2], shadow[3], 1)
		f:SetShadowOffset(1, -1)
	else
		f:SetShadowOffset(0, 0)
	end
	return f
end

local MORPHEUS = "Fonts\\MORPHEUS.ttf"
local FRIZ = "Fonts\\FRIZQT__.TTF"
local PAPER_SHADOW = { 200 / 255, 160 / 255, 90 / 255 }
local QUEST_SHADOW = { 0.49, 0.35, 0.05 }   -- QuestFont_Shadow_Huge

local fontWanted   = MakeFont("CenturionBountyFontWanted", MORPHEUS, 18, BLOOD, PAPER_SHADOW)
local fontWantedXL = MakeFont("CenturionBountyFontWantedXL", MORPHEUS, 34, BLOOD, PAPER_SHADOW)
local fontName     = MakeFont("CenturionBountyFontName", MORPHEUS, 15, { 0, 0, 0 })
local fontNameSmall = MakeFont("CenturionBountyFontNameSmall", MORPHEUS, 13, { 0, 0, 0 })
local fontNameXL   = MakeFont("CenturionBountyFontNameXL", MORPHEUS, 22, { 0, 0, 0 })
local fontHeading  = MakeFont("CenturionBountyFontHeading", MORPHEUS, 15, { 0, 0, 0 }, QUEST_SHADOW)
local fontInk      = MakeFont("CenturionBountyFontInk", FRIZ, 10, INK)
local fontInkSmall = MakeFont("CenturionBountyFontInkSmall", FRIZ, 9, INK)

-- A label that must stay on one line. In 3.3.5 a FontString given a width
-- wraps instead of clipping, and a wrapped label spills out of the bar or the
-- notice it sits on - "Eastern Plaguelands" did, and "Beast Mastery Hunter".
-- So these carry no width at all: the text is set, and the font stepped down
-- through the ones given until it fits. The last one stands either way.
local function FitText(fs, text, width, ...)
	fs:SetText(text)
	for i = 1, select("#", ...) do
		fs:SetFontObject((select(i, ...)))
		if fs:GetStringWidth() <= width then
			return true
		end
	end
	return false
end
local fontInkMed   = MakeFont("CenturionBountyFontInkMed", FRIZ, 11, INK)
local fontInkLarge = MakeFont("CenturionBountyFontInkLarge", FRIZ, 12, INK)

------------------------------------------------------------------
-- the frame: the achievement frame's wood, header and category list
------------------------------------------------------------------
local board = CreateFrame("Frame", "CenturionBountyBoard", UIParent)
board:SetWidth(FW)
board:SetHeight(FH)
board:SetPoint("CENTER", UIParent, "CENTER", 0, -20)
board:SetFrameStrata("MEDIUM")
board:SetToplevel(true)
board:EnableMouse(true)
board:SetBackdrop({
	bgFile   = "Interface\\TutorialFrame\\TutorialFrameBackground",
	edgeFile = "Interface\\AchievementFrame\\UI-Achievement-WoodBorder",
	tile = true, tileSize = 32, edgeSize = 64,
	insets = { left = 16, right = 16, top = 16, bottom = 16 },
})
board:Hide()
tinsert(UISpecialFrames, "CenturionBountyBoard")

local function Corner(point, x, y, l, r, t, b)
	local tex = board:CreateTexture(nil, "BORDER")
	tex:SetTexture("Interface\\AchievementFrame\\UI-Achievement-WoodBorder-Corner")
	tex:SetWidth(64)
	tex:SetHeight(64)
	tex:SetPoint(point, board, point, x, y)
	tex:SetTexCoord(l, r, t, b)
end
Corner("TOPLEFT", 4, -2, 0, 1, 0, 1)
Corner("TOPRIGHT", -4, -2, 1, 0, 0, 1)
Corner("BOTTOMLEFT", 4, 3, 0, 1, 1, 0)
Corner("BOTTOMRIGHT", -4, 3, 1, 0, 1, 0)

-- The carved header: AchievementFrameHeader's pieces at its own offsets, with
-- the points plate widened to hold a zone name.
local HEADER = "Interface\\AchievementFrame\\UI-Achievement-Header"
local headerLeft = board:CreateTexture(nil, "ARTWORK")
headerLeft:SetTexture(HEADER)
headerLeft:SetWidth(512)
headerLeft:SetHeight(106)
headerLeft:SetPoint("BOTTOMLEFT", board, "TOPLEFT", 26, -39)
headerLeft:SetTexCoord(0, 1, 0, 0.4140625)

local headerRight = board:CreateTexture(nil, "ARTWORK")
headerRight:SetTexture(HEADER)
headerRight:SetWidth(215)
headerRight:SetHeight(100)
headerRight:SetPoint("BOTTOMLEFT", headerLeft, "BOTTOMRIGHT", 0, -6)
headerRight:SetTexCoord(0, 0.419921875, 0.4140625, 0.8046875)

local plate = board:CreateTexture(nil, "OVERLAY")
plate:SetTexture(HEADER)
plate:SetWidth(193)
plate:SetHeight(39)
plate:SetPoint("BOTTOM", board, "TOPLEFT", 26 + 363 + 20, -39 + 16)
plate:SetTexCoord(0.419921875, 0.6796875, 0.4140625, 0.56640625)

-- The plate's art fills rows 4-35 of its 39, with a dark band between the
-- rims at 14-24: one line fits inside it, the zone. The title sits on the
-- carved header just above the rim, clear of it.
local title = board:CreateFontString(nil, "OVERLAY", "GameFontNormal")
title:SetPoint("BOTTOM", plate, "TOP", 0, -2)
title:SetText("Bounty Board")

local plateZone = board:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
plateZone:SetPoint("CENTER", plate, "TOP", 0, -19)

local closeButton = CreateFrame("Button", nil, board, "UIPanelCloseButton")
closeButton:SetPoint("TOPRIGHT", board, "TOPRIGHT", -8, -8)
closeButton:SetFrameLevel(board:GetFrameLevel() + 5)

-- Forward declarations: the draw functions call each other and the buttons
-- built below close over them.
local DrawZones, DrawBoard, DrawPoster, ShowZone, ShowPoster

------------------------------------------------------------------
-- the zone list
------------------------------------------------------------------
local ZONE_ROWS = 18
local zoneButtons = {}

for i = 1, ZONE_ROWS do
	local b = CreateFrame("Button", nil, board)
	b:SetWidth(158)
	b:SetHeight(24)
	b:SetPoint("TOPLEFT", board, "TOPLEFT", 21, -24 - (i - 1) * 25)

	b.bg = b:CreateTexture(nil, "BACKGROUND")
	b.bg:SetTexture("Interface\\AchievementFrame\\UI-Achievement-Category-Background")
	b.bg:SetPoint("TOPLEFT", b, "TOPLEFT")
	b.bg:SetPoint("TOPRIGHT", b, "TOPRIGHT")
	b.bg:SetHeight(32)
	b.bg:SetTexCoord(0, 0.6640625, 0, 1)

	b.sel = b:CreateTexture(nil, "BORDER")
	b.sel:SetTexture("Interface\\AchievementFrame\\UI-Achievement-Category-Background")
	b.sel:SetAllPoints(b.bg)
	b.sel:SetTexCoord(0, 0.6640625, 0, 1)
	b.sel:SetBlendMode("ADD")
	b.sel:SetAlpha(0.6)
	b.sel:Hide()

	b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	b.label:SetPoint("LEFT", b, "TOPLEFT", 14, -13)
	b.label:SetJustifyH("LEFT")

	b.count = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	b.count:SetPoint("RIGHT", b, "TOPRIGHT", -14, -13)

	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetTexture("Interface\\AchievementFrame\\UI-Achievement-Category-Highlight")
	hl:SetBlendMode("ADD")
	hl:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
	hl:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -1, -7)
	hl:SetTexCoord(0, 0.6640625, 0, 1)

	b:SetScript("OnClick", function(self)
		if self.zoneId then
			PlaySound("igMainMenuOptionCheckBoxOn")
			ShowZone(self.zoneId)
		end
	end)
	b:Hide()
	zoneButtons[i] = b
end

local function ScrollZones(delta)
	if #zoneOrder <= ZONE_ROWS then
		return
	end
	zoneScroll = math.max(0, math.min(#zoneOrder - ZONE_ROWS, zoneScroll - delta))
	DrawZones()
end

board:EnableMouseWheel(true)
board:SetScript("OnMouseWheel", function(self, delta)
	ScrollZones(delta)
end)

-- There are more contested zones than rows, so the list scrolls - and says so,
-- with the scroll bar's own arrows in the gap beside it, where the achievement
-- frame keeps its category scroll bar.
local function ZoneArrow(direction, y, delta)
	local b = CreateFrame("Button", nil, board)
	b:SetWidth(24)
	b:SetHeight(24)
	b:SetPoint("TOPLEFT", board, "TOPLEFT", 186, y)
	local base = "Interface\\Buttons\\UI-ScrollBar-Scroll" .. direction .. "Button-"
	b:SetNormalTexture(base .. "Up")
	b:SetPushedTexture(base .. "Down")
	b:SetDisabledTexture(base .. "Disabled")
	b:SetHighlightTexture(base .. "Highlight", "ADD")
	b:SetScript("OnClick", function()
		PlaySound("UChatScrollButton")
		ScrollZones(delta)
	end)
	return b
end
local zonesUp = ZoneArrow("Up", -24, 1)
local zonesDown = ZoneArrow("Down", -24 - (ZONE_ROWS - 1) * 25, -1)

-- The bar between the arrows: a dark track and the stock knob, which shows
-- where in the list you are and can be dragged.
local zonesBar = CreateFrame("Slider", nil, board)
zonesBar:SetWidth(18)
zonesBar:SetPoint("TOP", zonesUp, "BOTTOM", 0, 2)
zonesBar:SetPoint("BOTTOM", zonesDown, "TOP", 0, -2)
zonesBar:SetOrientation("VERTICAL")
zonesBar:SetValueStep(1)
zonesBar:SetMinMaxValues(0, 1)
zonesBar:SetValue(0)
zonesBar:SetThumbTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
zonesBar:GetThumbTexture():SetWidth(18)
zonesBar:GetThumbTexture():SetHeight(24)

-- The track is UIPanelScrollFrameTemplate's own: the long top piece of
-- UI-Character-ScrollBar run down to its 106-high bottom cap.
local zonesTrackBottom = board:CreateTexture(nil, "ARTWORK")
zonesTrackBottom:SetTexture("Interface\\PaperDollInfoFrame\\UI-Character-ScrollBar")
zonesTrackBottom:SetTexCoord(0.515625, 1.0, 0, 0.4140625)
zonesTrackBottom:SetWidth(31)
zonesTrackBottom:SetHeight(106)
zonesTrackBottom:SetPoint("BOTTOMLEFT", zonesDown, "BOTTOMLEFT", -4, -2)

local zonesTrackTop = board:CreateTexture(nil, "ARTWORK")
zonesTrackTop:SetTexture("Interface\\PaperDollInfoFrame\\UI-Character-ScrollBar")
zonesTrackTop:SetTexCoord(0, 0.484375, 0, 1.0)
zonesTrackTop:SetWidth(31)
zonesTrackTop:SetPoint("TOPLEFT", zonesUp, "TOPLEFT", -4, 5)
zonesTrackTop:SetPoint("BOTTOM", zonesTrackBottom, "TOP")

-- Set from DrawZones as well as by the mouse, so the drag handler ignores a
-- value that already matches.
zonesBar:SetScript("OnValueChanged", function(self, value)
	local row = math.floor(value + 0.5)
	if row ~= zoneScroll then
		zoneScroll = row
		DrawZones()
	end
end)

------------------------------------------------------------------
-- the board itself
------------------------------------------------------------------
local area = CreateFrame("Frame", nil, board)
area:SetWidth(530)
area:SetHeight(461)
area:SetPoint("TOPLEFT", board, "TOPLEFT", 218, -19)

local cork = area:CreateTexture(nil, "BACKGROUND")
cork:SetTexture("Interface\\AchievementFrame\\UI-Achievement-AchievementBackground")
cork:SetAllPoints(area)
cork:SetVertexColor(0.41, 0.31, 0.19)

-- The frame's lip throwing a shadow onto the board.
local shadeTop = area:CreateTexture(nil, "BORDER")
shadeTop:SetTexture("Interface\\Buttons\\WHITE8X8")
shadeTop:SetPoint("TOPLEFT", area, "TOPLEFT")
shadeTop:SetPoint("TOPRIGHT", area, "TOPRIGHT")
shadeTop:SetHeight(10)
shadeTop:SetGradientAlpha("VERTICAL", 0, 0, 0, 0, 0, 0, 0, 0.5)

local shadeLeft = area:CreateTexture(nil, "BORDER")
shadeLeft:SetTexture("Interface\\Buttons\\WHITE8X8")
shadeLeft:SetPoint("TOPLEFT", area, "TOPLEFT")
shadeLeft:SetPoint("BOTTOMLEFT", area, "BOTTOMLEFT")
shadeLeft:SetWidth(10)
shadeLeft:SetGradientAlpha("HORIZONTAL", 0, 0, 0, 0.5, 0, 0, 0, 0)

local emptyText = area:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
emptyText:SetPoint("CENTER", area, "CENTER", 0, 20)
emptyText:SetWidth(360)

local pageText = area:CreateFontString(nil, "OVERLAY", "GameFontNormal")
pageText:SetPoint("RIGHT", area, "BOTTOMRIGHT", -98, 20)

local function PageButton(texture, xOffset, step)
	local b = CreateFrame("Button", nil, area)
	b:SetWidth(32)
	b:SetHeight(32)
	b:SetPoint("BOTTOMRIGHT", area, "BOTTOMRIGHT", xOffset, 4)
	b:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. texture .. "-Up")
	b:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. texture .. "-Down")
	b:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-" .. texture .. "-Disabled")
	b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	b:SetScript("OnClick", function()
		page = page + step
		PlaySound("igAbiliityPageTurn")
		DrawBoard()
	end)
	return b
end
local prevPage = PageButton("PrevPage", -54, -1)
local nextPage = PageButton("NextPage", -16, 1)

------------------------------------------------------------------
-- the filter bar
------------------------------------------------------------------
-- Along the foot of the board: who to show, by class and by level, so the
-- board answers "who out there is carrying what I want".
local FILTER_CLASSES = { 1, 2, 3, 4, 5, 7, 8, 9, 11 }

local filterLabel = area:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
filterLabel:SetPoint("LEFT", area, "BOTTOMLEFT", 12, 21)
filterLabel:SetText("Class")

local classDrop = CreateFrame("Frame", "CenturionBountyBoardClassDrop", area, "UIDropDownMenuTemplate")
classDrop:SetPoint("LEFT", filterLabel, "RIGHT", -12, -2)
UIDropDownMenu_SetWidth(classDrop, 92)

local levelLabel = area:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
levelLabel:SetPoint("LEFT", area, "BOTTOMLEFT", 186, 21)
levelLabel:SetText("Level")

local function LevelBox(name, anchor, x)
	local e = CreateFrame("EditBox", name, area, "InputBoxTemplate")
	e:SetWidth(24)
	e:SetHeight(20)
	e:SetPoint("LEFT", anchor, "RIGHT", x, 0)
	e:SetAutoFocus(false)
	e:SetNumeric(true)
	e:SetMaxLetters(2)
	e:SetJustifyH("CENTER")
	return e
end
local levelMin = LevelBox("CenturionBountyBoardLevelMin", levelLabel, 10)
local levelTo = area:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
levelTo:SetPoint("LEFT", levelMin, "RIGHT", 4, 0)
levelTo:SetText("to")
local levelMax = LevelBox("CenturionBountyBoardLevelMax", levelTo, 9)

local function ClassLabel(class)
	return class and ClassName(class) or "All classes"
end

local function Matches(n)
	local f = Filter()
	if f.class and n.class ~= f.class then
		return false
	end
	if f.minLevel and n.level < f.minLevel then
		return false
	end
	if f.maxLevel and n.level > f.maxLevel then
		return false
	end
	return true
end

local function IsFiltering()
	local f = Filter()
	return f.class ~= nil or f.minLevel ~= nil or f.maxLevel ~= nil
end

UIDropDownMenu_Initialize(classDrop, function()
	local function add(class)
		local info = UIDropDownMenu_CreateInfo()
		info.text = ClassLabel(class)
		info.checked = Filter().class == class
		info.func = function()
			Filter().class = class
			UIDropDownMenu_SetText(classDrop, ClassLabel(class))
			page = 1
			DrawBoard()
		end
		UIDropDownMenu_AddButton(info)
	end
	add(nil)
	for _, class in ipairs(FILTER_CLASSES) do
		add(class)
	end
end)

-- A level box applies as it is typed; an empty box is no bound.
local function ReadLevels()
	local lo, hi = tonumber(levelMin:GetText()), tonumber(levelMax:GetText())
	Filter().minLevel = (lo and lo > 0) and lo or nil
	Filter().maxLevel = (hi and hi > 0) and hi or nil
	page = 1
	DrawBoard()
end
for _, e in ipairs({ levelMin, levelMax }) do
	e:SetScript("OnTextChanged", function(self, userInput)
		if userInput ~= false then ReadLevels() end
	end)
	e:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
	e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
end

local function ShowFilter()
	local f = Filter()
	UIDropDownMenu_SetText(classDrop, ClassLabel(f.class))
	levelMin:SetText(f.minLevel and tostring(f.minLevel) or "")
	levelMax:SetText(f.maxLevel and tostring(f.maxLevel) or "")
end

------------------------------------------------------------------
-- a notice
------------------------------------------------------------------
local cards = {}

for i = 1, NOTICES_PER_PAGE do
	local c = CreateFrame("Button", nil, area)
	c:SetWidth(160)
	c:SetHeight(132)
	c:SetPoint("TOPLEFT", area, "TOPLEFT", 13 + ((i - 1) % 3) * 172, -8 - math.floor((i - 1) / 3) * 138)

	c.shadow = c:CreateTexture(nil, "BACKGROUND")
	c.shadow:SetTexture("Interface\\Buttons\\WHITE8X8")
	c.shadow:SetVertexColor(0, 0, 0, 0.43)
	c.shadow:SetPoint("TOPLEFT", c, "TOPLEFT", 4, -5)
	c.shadow:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", 4, -5)

	c.paper = c:CreateTexture(nil, "BORDER")
	c.paper:SetTexture("Interface\\AchievementFrame\\UI-Achievement-Parchment-Horizontal")
	c.paper:SetAllPoints(c)
	c.paper:SetTexCoord(0.02, 0.98, 0.04, 0.96)

	c.wanted = c:CreateFontString(nil, "OVERLAY")
	c.wanted:SetFontObject(fontWanted)
	c.wanted:SetPoint("TOP", c, "TOP", 0, -10)
	c.wanted:SetText("Wanted")

	-- A killer's notice gets the skulls.
	c.skullLeft = c:CreateTexture(nil, "OVERLAY")
	c.skullLeft:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
	c.skullLeft:SetWidth(18)
	c.skullLeft:SetHeight(18)
	c.skullLeft:SetPoint("TOPLEFT", c, "TOPLEFT", 10, -11)
	c.skullRight = c:CreateTexture(nil, "OVERLAY")
	c.skullRight:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
	c.skullRight:SetWidth(18)
	c.skullRight:SetHeight(18)
	c.skullRight:SetPoint("TOPRIGHT", c, "TOPRIGHT", -10, -11)

	c.portrait = c:CreateTexture(nil, "ARTWORK")
	c.portrait:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
	c.portrait:SetWidth(36)
	c.portrait:SetHeight(36)
	c.portrait:SetPoint("TOPLEFT", c, "TOPLEFT", 12, -38)

	c.ring = c:CreateTexture(nil, "OVERLAY")
	c.ring:SetTexture("Interface\\AchievementFrame\\UI-Achievement-IconFrame")
	c.ring:SetWidth(48)
	c.ring:SetHeight(48)
	c.ring:SetPoint("TOPLEFT", c, "TOPLEFT", 6, -32)
	c.ring:SetTexCoord(0, 0.5625, 0, 0.5625)

	c.name = c:CreateFontString(nil, "OVERLAY")
	c.name:SetFontObject(fontName)
	c.name:SetPoint("LEFT", c, "TOPLEFT", 58, -47)
	c.name:SetJustifyH("LEFT")

	c.line1 = c:CreateFontString(nil, "OVERLAY")
	c.line1:SetFontObject(fontInk)
	c.line1:SetPoint("LEFT", c, "TOPLEFT", 58, -62)
	c.line1:SetJustifyH("LEFT")

	c.line2 = c:CreateFontString(nil, "OVERLAY")
	c.line2:SetFontObject(fontInk)
	c.line2:SetPoint("LEFT", c, "TOPLEFT", 58, -75)
	c.line2:SetJustifyH("LEFT")

	-- Where the bot was sighted, shown only when the board reads every zone.
	c.zone = c:CreateFontString(nil, "OVERLAY")
	c.zone:SetFontObject(fontInkSmall)
	c.zone:SetPoint("CENTER", c, "TOP", 0, -88)

	-- The icons are part of the notice and take no mouse of their own: a notice
	-- only knows each piece's id, not its suffix or enchant, so a tooltip here
	-- would describe the wrong item. Clicking reads the notice, whose poster
	-- carries the real thing.
	c.items = {}
	for k = 1, 5 do
		local b = MakeItemButton(c, 20)
		b:SetPoint("TOPLEFT", c, "TOPLEFT", 10 + (k - 1) * 23, -97)
		b:EnableMouse(false)
		c.items[k] = b
	end

	c.empty = c:CreateFontString(nil, "OVERLAY")
	c.empty:SetFontObject(fontInkMed)
	c.empty:SetPoint("CENTER", c, "TOP", 0, -107)
	c.empty:SetText("Nothing worth taking.")

	c.more = c:CreateFontString(nil, "OVERLAY")
	c.more:SetFontObject(fontInkLarge)
	c.more:SetPoint("LEFT", c, "TOPLEFT", 10 + 5 * 23 + 3, -107)

	c.footer = c:CreateFontString(nil, "OVERLAY")
	c.footer:SetFontObject(fontInkMed)
	c.footer:SetPoint("CENTER", c, "BOTTOM", 0, 9)

	c:SetHighlightTexture("Interface\\AchievementFrame\\UI-Achievement-Parchment-Highlight", "ADD")
	c:GetHighlightTexture():SetAlpha(0.9)

	c:SetScript("OnClick", function(self)
		if self.guid then
			ShowPoster(self.guid)
		end
	end)
	c:Hide()
	cards[i] = c
end

local function FillCard(c, n)
	c.guid = n.guid
	local tc = CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[CLASS_TOKEN[n.class] or ""]
	if tc then
		c.portrait:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
		c.portrait:Show()
	else
		c.portrait:Hide()
	end

	-- 96 is what is left of the notice beside the portrait.
	FitText(c.name, n.first, 96, fontName, fontNameSmall)
	FitText(c.line1, string.format("Level %d %s", n.level, RACE_NAME[n.race] or ""), 96, fontInk, fontInkSmall)
	local spec = SpecName(n.class, n.points)
	if not FitText(c.line2, spec .. " " .. ClassName(n.class), 96, fontInk, fontInkSmall) then
		-- The class is on the portrait already; the spec is what only words say.
		FitText(c.line2, spec, 96, fontInk, fontInkSmall)
	end

	for k = 1, 5 do
		local it = n.items[k]
		if it then
			ShowItem(c.items[k], it.id, it.quality)
		else
			c.items[k]:Hide()
		end
	end

	if shownZone == ALL_ZONES then
		FitText(c.zone, zones[n.zone] and zones[n.zone].name or "", 150, fontInkSmall)
		c.zone:Show()
	else
		c.zone:Hide()
	end

	c.more:SetText((n.spoils > #n.items) and ("+" .. (n.spoils - #n.items)) or "")
	if n.spoils == 0 then c.empty:Show() else c.empty:Hide() end

	c.footer:SetText("Player kills: " .. n.kills)
	SetInk(c.footer, n.kills > 0 and BLOOD or INK)
	if n.kills > 0 then
		c.skullLeft:Show()
		c.skullRight:Show()
	else
		c.skullLeft:Hide()
		c.skullRight:Hide()
	end
	c:Show()
end

------------------------------------------------------------------
-- the poster
------------------------------------------------------------------
local poster = CreateFrame("Frame", nil, area)
poster:SetWidth(390)
poster:SetHeight(411)
poster:SetPoint("TOPLEFT", area, "TOPLEFT", 70, -10)
poster:Hide()

local posterShadow = poster:CreateTexture(nil, "BACKGROUND")
posterShadow:SetTexture("Interface\\Buttons\\WHITE8X8")
posterShadow:SetVertexColor(0, 0, 0, 0.47)
posterShadow:SetPoint("TOPLEFT", poster, "TOPLEFT", 6, -7)
posterShadow:SetPoint("BOTTOMRIGHT", poster, "BOTTOMRIGHT", 6, -7)

local posterPaper = poster:CreateTexture(nil, "BORDER")
posterPaper:SetTexture("Interface\\AchievementFrame\\UI-Achievement-Parchment")
posterPaper:SetAllPoints(poster)
posterPaper:SetTexCoord(0.03, 0.97, 0.02, 0.98)

local pWanted = poster:CreateFontString(nil, "OVERLAY")
pWanted:SetFontObject(fontWantedXL)
pWanted:SetPoint("CENTER", poster, "TOP", 0, -28)
pWanted:SetText("Wanted")

local pSkullLeft = poster:CreateTexture(nil, "OVERLAY")
pSkullLeft:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
pSkullLeft:SetWidth(24)
pSkullLeft:SetHeight(24)
pSkullLeft:SetPoint("CENTER", poster, "TOP", -98, -28)
local pSkullRight = poster:CreateTexture(nil, "OVERLAY")
pSkullRight:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
pSkullRight:SetWidth(24)
pSkullRight:SetHeight(24)
pSkullRight:SetPoint("CENTER", poster, "TOP", 98, -28)

local pPortrait = poster:CreateTexture(nil, "ARTWORK")
pPortrait:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
pPortrait:SetWidth(46)
pPortrait:SetHeight(46)
pPortrait:SetPoint("TOP", poster, "TOP", 0, -51)

local pRing = poster:CreateTexture(nil, "OVERLAY")
pRing:SetTexture("Interface\\AchievementFrame\\UI-Achievement-IconFrame")
pRing:SetWidth(60)
pRing:SetHeight(60)
pRing:SetPoint("TOP", poster, "TOP", 0, -44)
pRing:SetTexCoord(0, 0.5625, 0, 0.5625)

local pName = poster:CreateFontString(nil, "OVERLAY")
pName:SetFontObject(fontNameXL)
pName:SetPoint("CENTER", poster, "TOP", 0, -118)

local pDesc = poster:CreateFontString(nil, "OVERLAY")
pDesc:SetFontObject(fontInkMed)
pDesc:SetPoint("CENTER", poster, "TOP", 0, -136)

local pKills = poster:CreateFontString(nil, "OVERLAY")
pKills:SetFontObject(fontInkMed)
pKills:SetPoint("CENTER", poster, "TOP", 0, -150)

local pRule = poster:CreateTexture(nil, "ARTWORK")
pRule:SetTexture("Interface\\QuestFrame\\UI-HorizontalBreak")
pRule:SetPoint("TOPLEFT", poster, "TOPLEFT", 20, -156)
pRule:SetWidth(350)
pRule:SetHeight(16)

local function Heading(text, y)
	local fs = poster:CreateFontString(nil, "OVERLAY")
	fs:SetFontObject(fontHeading)
	fs:SetPoint("LEFT", poster, "TOPLEFT", 22, -y)
	fs:SetText(text)
	return fs
end

local pDisciplineHead = Heading("Discipline", 182)

local pTrees = {}
for i = 1, 3 do
	local t = {}
	t.icon = poster:CreateTexture(nil, "ARTWORK")
	t.icon:SetWidth(26)
	t.icon:SetHeight(26)
	t.icon:SetPoint("TOPLEFT", poster, "TOPLEFT", 22 + (i - 1) * 120, -192)
	t.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
	t.name = poster:CreateFontString(nil, "OVERLAY")
	t.name:SetFontObject(fontInkMed)
	t.name:SetPoint("LEFT", t.icon, "RIGHT", 4, 6)
	t.points = poster:CreateFontString(nil, "OVERLAY")
	t.points:SetFontObject(fontInk)
	t.points:SetPoint("LEFT", t.icon, "RIGHT", 4, -7)
	pTrees[i] = t
end

-- The talent split is all a notice says about the build: which trees, how
-- deep. The individual talents were too much.
local pBodyHead = Heading("On their body", 234)
local pBody = {}
for k = 1, 20 do
	local b = MakeItemButton(poster, 30)
	b:SetPoint("TOPLEFT", poster, "TOPLEFT", 22 + ((k - 1) % 10) * 34, -244 - math.floor((k - 1) / 10) * 33)
	pBody[k] = b
end

-- Two rows for the packs now that the talents are gone: a bot hoards.
local pPacksHead = Heading("In their packs", 320)
local pPacks = {}
for k = 1, 20 do
	local b = MakeItemButton(poster, 30)
	b:SetPoint("TOPLEFT", poster, "TOPLEFT", 22 + ((k - 1) % 10) * 34, -330 - math.floor((k - 1) / 10) * 33)
	pPacks[k] = b
end

local pPacksMore = poster:CreateFontString(nil, "OVERLAY")
pPacksMore:SetFontObject(fontInkLarge)
pPacksMore:SetPoint("LEFT", poster, "TOPLEFT", 22 + 9 * 34 + 4, -378)

local pBodyNone = poster:CreateFontString(nil, "OVERLAY")
pBodyNone:SetFontObject(fontInkMed)
pBodyNone:SetPoint("LEFT", poster, "TOPLEFT", 22, -258)
pBodyNone:SetText("Nothing worth the taking.")

local pPacksNone = poster:CreateFontString(nil, "OVERLAY")
pPacksNone:SetFontObject(fontInkMed)
pPacksNone:SetPoint("LEFT", poster, "TOPLEFT", 22, -344)
pPacksNone:SetText("Nothing worth the taking.")

local pHint = poster:CreateFontString(nil, "OVERLAY")
pHint:SetFontObject(fontInk)
pHint:SetPoint("CENTER", poster, "BOTTOM", 0, 12)
pHint:SetText("Hover for the item, shift-click to link, ctrl-click to try on.")

-- What shows while the notice is being fetched, or once it has gone.
local pStatus = poster:CreateFontString(nil, "OVERLAY")
pStatus:SetFontObject(fontInkLarge)
pStatus:SetPoint("CENTER", poster, "TOP", 0, -260)
pStatus:SetWidth(330)

-- Everything below the rule, hidden together while there is nothing to show.
local posterBody = { pDisciplineHead, pBodyHead, pPacksHead, pHint }

local backButton = CreateFrame("Button", nil, area, "UIPanelButtonTemplate")
backButton:SetWidth(140)
backButton:SetHeight(22)
backButton:SetPoint("BOTTOM", area, "BOTTOM", 0, 8)
backButton:SetText("Back to the board")
backButton:SetScript("OnClick", function()
	PlaySound("igQuestLogClose")
	shownPoster = nil
	DrawBoard()
end)
backButton:Hide()

local function FindNotice(guid)
	for _, list in pairs(notices) do
		for i = 1, #list do
			if list[i].guid == guid then
				return list[i]
			end
		end
	end
end

DrawPoster = function()
	local guid = shownPoster
	local n = guid and FindNotice(guid)
	local p = guid and posters[guid]
	if not n or not p then
		return
	end

	local tc = CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[CLASS_TOKEN[n.class] or ""]
	if tc then
		pPortrait:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
	end
	pName:SetText(n.name)
	pDesc:SetText(string.format("Level %d %s %s, sighted in %s", n.level, RACE_NAME[n.race] or "",
		ClassName(n.class), zones[n.zone] and zones[n.zone].name or GetRealZoneText()))
	pKills:SetText("Player kills: " .. n.kills)
	SetInk(pKills, n.kills > 0 and BLOOD or INK)
	if n.kills > 0 then
		pSkullLeft:Show()
		pSkullRight:Show()
	else
		pSkullLeft:Hide()
		pSkullRight:Hide()
	end

	local ready = p.state == "ok"
	for _, region in ipairs(posterBody) do
		if ready then region:Show() else region:Hide() end
	end

	for i = 1, 3 do
		local t = pTrees[i]
		local tree = TREES[n.class] and TREES[n.class][i]
		if ready and tree then
			t.icon:SetTexture("Interface\\Icons\\" .. tree[2])
			t.icon:SetDesaturated((p.points[i] or 0) == 0)
			t.name:SetText(tree[1])
			t.points:SetText((p.points[i] or 0) .. " points")
			local main = i == TreeOf(p.points)
			SetInk(t.name, main and { 0, 0, 0 } or INK)
			t.icon:Show()
			t.name:Show()
			t.points:Show()
		else
			t.icon:Hide()
			t.name:Hide()
			t.points:Hide()
		end
	end

	-- Worn and carried, each in the order the server ranked them: best first.
	local body, packs = {}, {}
	if ready then
		for i = 1, #p.items do
			local it = p.items[i]
			if it.slot >= 0 then
				table.insert(body, it)
			else
				table.insert(packs, it)
			end
		end
	end

	for k = 1, #pBody do
		local it = body[k]
		if it then ShowItem(pBody[k], it.id, it.quality, it.link) else pBody[k]:Hide() end
	end

	-- Two rows for the packs: nineteen and a count when they would overflow it.
	local packSlots = (#packs > #pPacks) and (#pPacks - 1) or #pPacks
	for k = 1, #pPacks do
		local it = (k <= packSlots) and packs[k]
		if it then ShowItem(pPacks[k], it.id, it.quality, it.link) else pPacks[k]:Hide() end
	end
	pPacksMore:SetText((#packs > packSlots) and ("+" .. (#packs - packSlots)) or "")

	if ready and #body == 0 then pBodyNone:Show() else pBodyNone:Hide() end
	if ready and #packs == 0 then pPacksNone:Show() else pPacksNone:Hide() end

	if p.state == "loading" then
		pStatus:SetText("Reading the notice...")
		pStatus:Show()
	elseif p.state == "gone" then
		pStatus:SetText("This notice has been torn down. Whoever it named is dead, or has moved on.")
		pStatus:Show()
	else
		pStatus:Hide()
	end
end

------------------------------------------------------------------
-- drawing the board
------------------------------------------------------------------
DrawZones = function()
	if #zoneOrder > ZONE_ROWS then
		zonesUp:Show()
		zonesDown:Show()
		if zoneScroll > 0 then zonesUp:Enable() else zonesUp:Disable() end
		if zoneScroll < #zoneOrder - ZONE_ROWS then zonesDown:Enable() else zonesDown:Disable() end
		zonesBar:SetMinMaxValues(0, #zoneOrder - ZONE_ROWS)
		zonesBar:SetValue(zoneScroll)
		zonesBar:Show()
		zonesTrackTop:Show()
		zonesTrackBottom:Show()
	else
		zonesUp:Hide()
		zonesDown:Hide()
		zonesBar:Hide()
		zonesTrackTop:Hide()
		zonesTrackBottom:Hide()
	end

	for i = 1, ZONE_ROWS do
		local b = zoneButtons[i]
		local zoneId = zoneOrder[i + zoneScroll]
		local z = zoneId and (zoneId == ALL_ZONES and allZones or zones[zoneId])
		if z then
			b.zoneId = zoneId
			FitText(b.label, z.name, 116, GameFontNormal, GameFontNormalSmall)
			b.count:SetText(z.count)
			if zoneId == shownZone then
				b.sel:Show()
				b.label:SetTextColor(1, 1, 1)
			else
				b.sel:Hide()
				b.label:SetTextColor(1, 0.82, 0)
			end
			b:Show()
		else
			b.zoneId = nil
			b:Hide()
		end
	end
end

DrawBoard = function()
	DrawZones()
	if shownZone == ALL_ZONES then
		plateZone:SetText("Every contested zone")
	else
		plateZone:SetText(shownZone and zones[shownZone] and zones[shownZone].name or GetRealZoneText())
	end

	if shownPoster then
		for i = 1, #cards do cards[i]:Hide() end
		emptyText:Hide()
		pageText:Hide()
		prevPage:Hide()
		nextPage:Hide()
		for _, r in ipairs({ filterLabel, classDrop, levelLabel, levelMin, levelTo, levelMax }) do r:Hide() end
		poster:Show()
		backButton:Show()
		DrawPoster()
		return
	end

	poster:Hide()
	backButton:Hide()
	for _, r in ipairs({ filterLabel, classDrop, levelLabel, levelMin, levelTo, levelMax }) do r:Show() end

	-- What is on the board: one zone's notices, or every zone's merged, and
	-- then whatever the filter lets through.
	local source, waiting
	if shownZone == ALL_ZONES then
		source = {}
		for _, zoneId in ipairs(zoneOrder) do
			if zoneId ~= ALL_ZONES then
				if notices[zoneId] then
					for _, n in ipairs(notices[zoneId]) do table.insert(source, n) end
				else
					waiting = true
				end
			end
		end
		table.sort(source, function(a, b)
			if a.level ~= b.level then return a.level > b.level end
			return a.guid < b.guid
		end)
		if waiting and #source == 0 then source = nil end
	else
		source = shownZone and notices[shownZone]
	end

	local list
	if source then
		list = {}
		for _, n in ipairs(source) do
			if Matches(n) then table.insert(list, n) end
		end
	end
	local pages = list and math.max(1, math.ceil(#list / NOTICES_PER_PAGE)) or 1
	page = math.max(1, math.min(page, pages))

	for i = 1, NOTICES_PER_PAGE do
		local n = list and list[(page - 1) * NOTICES_PER_PAGE + i]
		if n then
			FillCard(cards[i], n)
		else
			cards[i].guid = nil
			cards[i]:Hide()
		end
	end

	if not list then
		emptyText:SetText("Reading the board...")
		emptyText:Show()
	elseif #list == 0 then
		local name = (shownZone == ALL_ZONES) and "any contested zone"
			or (zones[shownZone] and zones[shownZone].name or GetRealZoneText())
		if #source > 0 and IsFiltering() then
			emptyText:SetText("No notice in " .. name .. " matches your filter.")
		elseif waiting then
			emptyText:SetText("Reading the board...")
		else
			emptyText:SetText("No notices are posted for " .. name .. ".")
		end
		emptyText:Show()
	else
		emptyText:Hide()
	end

	if waiting and list and #list > 0 then
		pageText:SetText("Reading...")
	else
		pageText:SetText(pages > 1 and string.format("Page %d of %d", page, pages) or "")
	end
	pageText:Show()
	prevPage:Show()
	nextPage:Show()
	if page > 1 then prevPage:Enable() else prevPage:Disable() end
	if page < pages then nextPage:Enable() else nextPage:Disable() end
end

ShowZone = function(zoneId)
	shownZone = zoneId
	shownPoster = nil
	page = 1
	if zoneId == ALL_ZONES then
		-- Every zone, asked for one at a time a few a second: the server answers
		-- a reader at a board only so fast. A zone read in the last minute is
		-- current enough to reuse.
		fetchQueue = {}
		for _, z in ipairs(zoneOrder) do
			if z ~= ALL_ZONES and not (notices[z] and fetchedAt[z] and GetTime() - fetchedAt[z] < 60) then
				notices[z] = nil
				table.insert(fetchQueue, z)
			end
		end
	else
		fetchQueue = {}
		-- Asked for every time it is chosen: the fleet moves, and a board is only
		-- worth reading if it is current.
		Request("ZONE:" .. zoneId)
	end
	DrawBoard()
end

local fetchTimer = 0
local fetcher = CreateFrame("Frame")
fetcher:SetScript("OnUpdate", function(self, elapsed)
	if #fetchQueue == 0 or not board:IsShown() then
		return
	end
	fetchTimer = fetchTimer + elapsed
	if fetchTimer < 0.35 then
		return
	end
	fetchTimer = 0
	Request("ZONE:" .. table.remove(fetchQueue, 1))
end)

ShowPoster = function(guid)
	shownPoster = guid
	posters[guid] = { state = "loading", items = {}, points = { 0, 0, 0 } }
	PlaySound("igQuestLogOpen")
	Request("BOT:" .. guid)
	DrawBoard()
end

------------------------------------------------------------------
-- open, close, walk away
------------------------------------------------------------------
local openX, openY

-- Where the player stands on their own zone's map. The map is pointed at the
-- current zone only when the board opens - doing it every half second would
-- fight anybody browsing the world map - so a reading taken while the map
-- shows somewhere else comes back 0,0 and is ignored.
local function MapPosition(pointMap)
	if WorldMapFrame and WorldMapFrame:IsShown() then
		return nil
	end
	if pointMap then
		SetMapToCurrentZone()
	end
	local x, y = GetPlayerMapPosition("player")
	if not x or (x == 0 and y == 0) then
		return nil
	end
	return x, y
end

local function OpenBoard(zoneId)
	boardZone = zoneId
	shownZone = zoneId
	shownPoster = nil
	page = 1
	zoneScroll = 0
	notices[zoneId] = nil

	-- The board's own zone is listed even before the zone list lands, and even
	-- if it has nobody in it to post.
	zones[zoneId] = zones[zoneId] or { name = GetRealZoneText(), count = 0 }

	fetchQueue = {}
	ShowFilter()
	openX, openY = MapPosition(true)
	if not board:IsShown() then
		PlaySound("igCharacterInfoOpen")
	end
	board:Show()
	Request("OPEN:" .. zoneId)
	DrawBoard()
end

board:SetScript("OnHide", function()
	PlaySound("igCharacterInfoClose")
	shownPoster = nil
end)

-- A board stays where it was nailed up: walk away from it and it closes, the
-- way a vendor's window does. The server refuses anything asked from afar
-- anyway (BBCL); this just does not wait to be told.
local walkTimer = 0
board:SetScript("OnUpdate", function(self, elapsed)
	walkTimer = walkTimer + elapsed
	if walkTimer < 0.5 then
		return
	end
	walkTimer = 0
	if not openX then
		openX, openY = MapPosition(true)
		return
	end
	local x, y = MapPosition()
	if x and (math.abs(x - openX) > 0.006 or math.abs(y - openY) > 0.006) then
		board:Hide()
	end
end)

------------------------------------------------------------------
-- the wire
------------------------------------------------------------------
local function ParseNotice(zoneId, row)
	local guid, level, race, class, t1, t2, t3, kills, spoils, items, name = string.match(row,
		"^(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),([%d:/]*),(.+)$")
	if not guid then
		return nil
	end

	local n = {
		guid = tonumber(guid), zone = zoneId, level = tonumber(level), race = tonumber(race),
		class = tonumber(class), points = { tonumber(t1), tonumber(t2), tonumber(t3) },
		kills = tonumber(kills) or 0, spoils = tonumber(spoils) or 0, items = {}, name = name,
		first = string.match(name, "^(%S+)") or name,
	}
	for id, quality in string.gmatch(items, "(%d+):(%d+)") do
		table.insert(n.items, { id = tonumber(id), quality = tonumber(quality) })
		Warm("item:" .. id)
	end
	return n
end

local function ParseSpoil(row)
	local slot, id, quality, ilvl, ench, g1, g2, g3, prop, seed = string.match(row,
		"^(%-?%d+),(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),(%d+),(%-?%d+),(%d+)$")
	if not slot then
		return nil
	end
	-- item:id:enchant:gem1:gem2:gem3:gem4:suffix:uniqueId:linkLevel - the piece
	-- itself, suffix and enchant included, which is what the cache hands over.
	local link = string.format("item:%s:%s:%s:%s:%s:0:%s:%s:0", id, ench, g1, g2, g3, prop, seed)
	Warm(link)
	return { slot = tonumber(slot), id = tonumber(id), quality = tonumber(quality), ilvl = tonumber(ilvl), link = link }
end

local function CommitZones()
	zones = incomingZones
	incomingZones = {}
	if boardZone and not zones[boardZone] then
		zones[boardZone] = { name = GetRealZoneText(), count = 0 }
	end

	zoneOrder = {}
	for zoneId in pairs(zones) do
		if zoneId ~= boardZone then
			table.insert(zoneOrder, zoneId)
		end
	end
	table.sort(zoneOrder, function(a, b) return zones[a].name < zones[b].name end)
	if boardZone then
		table.insert(zoneOrder, 1, boardZone)
	end
	table.insert(zoneOrder, 1, ALL_ZONES)

	allZones.count = 0
	for zoneId, z in pairs(zones) do
		allZones.count = allZones.count + (z.count or 0)
	end
end

local handlers = {}

handlers.BBOP = function(payload)
	local zoneId = tonumber(payload)
	if zoneId then
		expectGossipUntil = GetTime() + 2
		OpenBoard(zoneId)
	end
end

handlers.BBZL = function(payload)
	for row in string.gmatch(payload, "([^;]+)") do
		local zoneId, count, name = string.match(row, "^(%d+),(%d+),(.+)$")
		if zoneId then
			incomingZones[tonumber(zoneId)] = { name = name, count = tonumber(count) }
		end
	end
end

handlers.BBZE = function()
	CommitZones()
	if board:IsShown() then DrawZones() end
end

handlers.BBRS = function(payload)
	local zoneId, rows = string.match(payload, "^(%d+)|(.*)$")
	zoneId = tonumber(zoneId)
	if not zoneId then
		return
	end
	incomingNotices[zoneId] = incomingNotices[zoneId] or {}
	for row in string.gmatch(rows, "([^;]+)") do
		local n = ParseNotice(zoneId, row)
		if n then
			table.insert(incomingNotices[zoneId], n)
		end
	end
end

handlers.BBRE = function(payload)
	local zoneId = tonumber(string.match(payload, "^(%d+)|"))
	if not zoneId then
		return
	end
	notices[zoneId] = incomingNotices[zoneId] or {}
	incomingNotices[zoneId] = nil
	fetchedAt[zoneId] = GetTime()
	-- The count beside the zone follows what was actually posted.
	if zones[zoneId] then
		zones[zoneId].count = #notices[zoneId]
	end
	allZones.count = 0
	for _, z in pairs(zones) do allZones.count = allZones.count + (z.count or 0) end
	if board:IsShown() and (zoneId == shownZone or shownZone == ALL_ZONES) and not shownPoster then
		DrawBoard()
	elseif board:IsShown() then
		DrawZones()
	end
end

handlers.BBPI = function(payload)
	local guid, rows = string.match(payload, "^(%d+)|(.*)$")
	local p = guid and posters[tonumber(guid)]
	if not p or p.state ~= "loading" then
		return
	end
	for row in string.gmatch(rows, "([^;]+)") do
		local it = ParseSpoil(row)
		if it then
			table.insert(p.items, it)
		end
	end
end

-- The talent split. Anything after it - a server from before the individual
-- talents came off the poster still sends their spell ids - is ignored.
handlers.BBPT = function(payload)
	local guid, t1, t2, t3 = string.match(payload, "^(%d+)|(%d+),(%d+),(%d+)")
	local p = guid and posters[tonumber(guid)]
	if not p then
		return
	end
	p.points = { tonumber(t1), tonumber(t2), tonumber(t3) }
end

handlers.BBPE = function(payload)
	local guid, ok = string.match(payload, "^(%d+)|(%d)$")
	guid = tonumber(guid)
	local p = guid and posters[guid]
	if not p then
		return
	end
	p.state = (ok == "1") and "ok" or "gone"
	if board:IsShown() and shownPoster == guid then
		DrawPoster()
	end
end

handlers.BBCL = function()
	if board:IsShown() then
		board:Hide()
		if UIErrorsFrame and ERR_USE_TOO_FAR then
			UIErrorsFrame:AddMessage(ERR_USE_TOO_FAR, 1.0, 0.1, 0.1, 1.0)
		end
	end
end

local driver = CreateFrame("Frame")
driver:RegisterEvent("CHAT_MSG_ADDON")
driver:RegisterEvent("GOSSIP_SHOW")
driver:RegisterEvent("ZONE_CHANGED_NEW_AREA")
driver:SetScript("OnEvent", function(self, event, prefix, message)
	if event == "CHAT_MSG_ADDON" then
		if prefix ~= "CCGAME" or type(message) ~= "string" then
			return
		end
		local tag, payload = string.match(message, "^(BB%u%u):(.*)$")
		local handler = tag and handlers[tag]
		if handler then
			handler(payload)
		end
	elseif event == "GOSSIP_SHOW" then
		-- The board's own gossip menu, the fallback for a client without this
		-- addon. GossipFrame has already shown it by the time this runs, and
		-- closing it here happens before anything is drawn.
		if GetTime() <= expectGossipUntil then
			expectGossipUntil = 0
			CloseGossip()
		end
	elseif event == "ZONE_CHANGED_NEW_AREA" then
		if board:IsShown() then
			board:Hide()
		end
	end
end)

-- EnergyTicker.lua - 3.3.5a / vanilla-compatible shim
-- Energy tick bar that mimics EnergyWatch_30000 v2.06 behavior:
--  - Only watches UNIT_ENERGY
--  - A "tick" is strictly: currentEnergy == lastEnergy + 20
--  - Bar is a simple 2.0s modulo from last tick time
-- Shows ONLY for: Rogues, or Druids in Cat Form
-- Move with: /et unlock   and   /et lock

local ADDON_NAME = ...
local ET = CreateFrame("Frame", "EnergyTickerFrame", UIParent)

------------------------------------------------------------
-- CONFIG
------------------------------------------------------------
ET.debug = false
ET.width = 120
ET.height = 10
ET.tickColor = {1, 1, 0, 1}   -- yellow
ET.bgColor   = {0, 0, 0, 0.4}
ET.locked = true

-- hard-coded tick length, like EnergyWatch
ET.tickLength = 2.0

------------------------------------------------------------
-- COLOR HELPER
------------------------------------------------------------
local function SetTexColor(tex, r, g, b, a)
    if tex.SetColorTexture then
        tex:SetColorTexture(r, g, b, a)
    else
        tex:SetTexture(r, g, b, a)
    end
end

------------------------------------------------------------
-- STATE
------------------------------------------------------------
ET.playerGUID    = nil
ET.lastEnergy    = nil        -- last energy value we saw
ET.lastTickTime  = 0          -- GetTime() when we last detected a tick
ET.lastRemainder = 0          -- for wrap detection (debug only)

------------------------------------------------------------
-- UI
------------------------------------------------------------
local f = ET
f:SetSize(ET.width, ET.height)
f:SetPoint("CENTER", UIParent, "CENTER", 0, -120)
f:Hide()

f:SetMovable(true)
f:EnableMouse(true)
f:RegisterForDrag("LeftButton")

-- background
local bg = f:CreateTexture(nil, "BACKGROUND")
bg:SetAllPoints(true)
SetTexColor(bg, ET.bgColor[1], ET.bgColor[2], ET.bgColor[3], ET.bgColor[4])

-- bar
local bar = f:CreateTexture(nil, "ARTWORK")
bar:SetPoint("LEFT", f, "LEFT", 0, 0)
bar:SetHeight(ET.height)
bar:SetWidth(1)
SetTexColor(bar, ET.tickColor[1], ET.tickColor[2], ET.tickColor[3], ET.tickColor[4])
f.bar = bar

-- border
f:SetBackdrop({
    bgFile = nil,
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 10,
})
f:SetBackdropBorderColor(1, 1, 1, 0.4)

------------------------------------------------------------
-- HELPERS
------------------------------------------------------------
local function ET_Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffcc00[EnergyTicker]|r " .. msg)
    end
end

-- compatibility: return current druid form id using whatever the client has
local function GetCurrentFormID()
    if GetShapeshiftFormID then
        return GetShapeshiftFormID() or 0
    elseif GetShapeshiftForm then
        -- classic / 1.12: cat was form 3
        return GetShapeshiftForm() or 0
    end
    return 0
end

-- only rogues, or druids in cat (or any energy form, just in case)
local function ShouldShowTicker()
    local _, class = UnitClass("player")
    if class == "ROGUE" then
        return true
    elseif class == "DRUID" then
        local form = GetCurrentFormID()
        if form == 3 then
            return true
        end
        local pow = UnitPowerType("player")
        if pow == 3 then
            return true
        end
    else
        -- other classes can be energy on some weird servers; honor that
        if UnitPowerType("player") == 3 then
            return true
        end
    end
    return false
end

------------------------------------------------------------
-- DRAG
------------------------------------------------------------
f:SetScript("OnDragStart", function(self)
    if not ET.locked then
        self:StartMoving()
    end
end)

f:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
end)

------------------------------------------------------------
-- ENERGY HANDLER (EnergyWatch-style)
------------------------------------------------------------
function ET:OnEnergy(unit)
    if unit ~= "player" then return end
    if not ShouldShowTicker() then return end

    -- EnergyWatch uses UnitMana("player"); here we use energy explicitly.
    local current = UnitPower("player", 3)

    -- first time: just baseline
    if self.lastEnergy == nil then
        self.lastEnergy = current
        if ET.debug then
            ET_Print("baseline energy = " .. current)
        end
        return
    end

    local diff = current - self.lastEnergy
    self.lastEnergy = current

    if ET.debug and diff ~= 0 then
        ET_Print("UNIT_ENERGY diff=" .. diff)
    end

    -- EXACT EnergyWatch behavior:
    -- tick only when current == last + 20
    if diff == 20 then
        self.lastTickTime = GetTime()
        if ET.debug then
            ET_Print("EnergyWatch-style tick detected (+20)")
        end
    end
end

------------------------------------------------------------
-- UPDATE (EnergyWatch-style modulo 2s)
------------------------------------------------------------
function ET:OnUpdate(elapsed)
    if not ShouldShowTicker() then
        self:Hide()
        return
    end

    if self.lastTickTime == 0 then
        -- Pre-first-tick: EnergyWatch just runs from time=0,
        -- so we do the same: treat lastTickTime as 0 anchor.
        -- This still gives a moving bar; first +20 will re-anchor it.
    end

    local now = GetTime()
    local delta = now - self.lastTickTime
    -- mimic mod((GetTime() - ENERGYWATCH_ENERGYTIME), 2)
    local remainder = math.fmod(delta, ET.tickLength)
    if remainder < 0 then
        remainder = remainder + ET.tickLength
    end

    -- Debug: detect wrap (would be where EnergyWatch plays sounds)
    if remainder < (self.lastRemainder or 0) then
        if ET.debug then
            ET_Print("tick wrap (bar looped 0 -> 2s)")
        end
    end
    self.lastRemainder = remainder

    -- Map [0, tickLength] to [0, 1] width
    local pct = remainder / ET.tickLength
    if pct < 0 then pct = 0 end
    if pct > 1 then pct = 1 end
    self.bar:SetWidth(self:GetWidth() * pct)
end

------------------------------------------------------------
-- VISIBILITY
------------------------------------------------------------
function ET:RefreshVisibility()
    if ShouldShowTicker() then
        self:Show()
    else
        self:Hide()
    end
end

------------------------------------------------------------
-- EVENTS
------------------------------------------------------------
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("UNIT_ENERGY")
f:RegisterEvent("UNIT_DISPLAYPOWER")
f:RegisterEvent("UPDATE_SHAPESHIFT_FORM")

f:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        ET.playerGUID = UnitGUID("player")
        ET.lastEnergy = UnitPower("player", 3)
        ET.lastTickTime = 0
        ET.lastRemainder = 0
        ET:RefreshVisibility()
        if ET.debug then
            ET_Print("PLAYER_LOGIN: energy=" .. (ET.lastEnergy or 0))
        end
    elseif event == "UNIT_ENERGY" then
        ET:OnEnergy(...)
    elseif event == "UNIT_DISPLAYPOWER" or event == "UPDATE_SHAPESHIFT_FORM" then
        -- EnergyWatch doesn't reset timing here; it just hides/shows.
        ET.lastEnergy = UnitPower("player", 3)
        ET:RefreshVisibility()
        if ET.debug then
            ET_Print(event .. ": visibility refresh, energy=" .. (ET.lastEnergy or 0))
        end
    end
end)

f:SetScript("OnUpdate", function(self, elapsed)
    if self:IsShown() then
        ET:OnUpdate(elapsed)
    end
end)

------------------------------------------------------------
-- SLASH
------------------------------------------------------------
SLASH_ENERGYTICKER1 = "/et"
SlashCmdList["ENERGYTICKER"] = function(msg)
    msg = (msg or ""):lower()
    if msg == "debug" then
        ET.debug = not ET.debug
        ET_Print("debug = " .. tostring(ET.debug))
    elseif msg == "unlock" then
        ET.locked = false
        ET:Show()
        ET_Print("unlocked - drag with left mouse")
    elseif msg == "lock" then
        ET.locked = true
        ET_Print("locked")
    else
        ET_Print("commands: /et lock | /et unlock | /et debug")
    end
end

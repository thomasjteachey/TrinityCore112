
centurion = {
		{
			["key1"] = "BUTTON2",
			["command"] = "TURNORACTION",
			["key2"] = "_NULL",
		}, -- [1]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_MOVEMENT",
			["key2"] = "_NULL",
		}, -- [2]
		{
			["key1"] = "BUTTON3",
			["command"] = "MOVEANDSTEER",
			["key2"] = "_NULL",
		}, -- [3]
		{
			["key1"] = "W",
			["command"] = "MOVEFORWARD",
			["key2"] = "UP",
		}, -- [4]
		{
			["key1"] = "S",
			["command"] = "MOVEBACKWARD",
			["key2"] = "DOWN",
		}, -- [5]
		{
			["key1"] = "LEFT",
			["command"] = "TURNLEFT",
			["key2"] = "_NULL",
		}, -- [6]
		{
			["key1"] = "RIGHT",
			["command"] = "TURNRIGHT",
			["key2"] = "_NULL",
		}, -- [7]
		{
			["key1"] = "A",
			["command"] = "STRAFELEFT",
			["key2"] = "_NULL",
		}, -- [8]
		{
			["key1"] = "D",
			["command"] = "STRAFERIGHT",
			["key2"] = "_NULL",
		}, -- [9]
		{
			["key1"] = "SPACE",
			["command"] = "JUMP",
			["key2"] = "SHIFT-SPACE",
		}, -- [10]
		{
			["key1"] = "_NULL",
			["command"] = "SITORSTAND",
			["key2"] = "_NULL",
		}, -- [11]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLESHEATH",
			["key2"] = "_NULL",
		}, -- [12]
		{
			["key1"] = "NUMLOCK",
			["command"] = "TOGGLEAUTORUN",
			["key2"] = "_NULL",
		}, -- [13]
		{
			["key1"] = "INSERT",
			["command"] = "PITCHUP",
			["key2"] = "_NULL",
		}, -- [14]
		{
			["key1"] = "DELETE",
			["command"] = "PITCHDOWN",
			["key2"] = "_NULL",
		}, -- [15]
		{
			["key1"] = "NUMPADDIVIDE",
			["command"] = "TOGGLERUN",
			["key2"] = "_NULL",
		}, -- [16]
		{
			["key1"] = "_NULL",
			["command"] = "FOLLOWTARGET",
			["key2"] = "_NULL",
		}, -- [17]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_CHAT",
			["key2"] = "_NULL",
		}, -- [18]
		{
			["key1"] = "ENTER",
			["command"] = "OPENCHAT",
			["key2"] = "_NULL",
		}, -- [19]
		{
			["key1"] = "/",
			["command"] = "OPENCHATSLASH",
			["key2"] = "_NULL",
		}, -- [20]
		{
			["key1"] = "PAGEUP",
			["command"] = "CHATPAGEUP",
			["key2"] = "_NULL",
		}, -- [21]
		{
			["key1"] = "PAGEDOWN",
			["command"] = "CHATPAGEDOWN",
			["key2"] = "_NULL",
		}, -- [22]
		{
			["key1"] = "SHIFT-PAGEDOWN",
			["command"] = "CHATBOTTOM",
			["key2"] = "_NULL",
		}, -- [23]
		{
			["key1"] = ".",
			["command"] = "REPLY",
			["key2"] = "_NULL",
		}, -- [24]
		{
			["key1"] = "_NULL",
			["command"] = "REPLY2",
			["key2"] = "_NULL",
		}, -- [25]
		{
			["key1"] = "CTRL-PAGEUP",
			["command"] = "COMBATLOGPAGEUP",
			["key2"] = "_NULL",
		}, -- [26]
		{
			["key1"] = "CTRL-PAGEDOWN",
			["command"] = "COMBATLOGPAGEDOWN",
			["key2"] = "_NULL",
		}, -- [27]
		{
			["key1"] = "CTRL-SHIFT-PAGEDOWN",
			["command"] = "COMBATLOGBOTTOM",
			["key2"] = "_NULL",
		}, -- [28]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_ACTIONBAR",
			["key2"] = "_NULL",
		}, -- [29]
		{
			["key1"] = "1",
			["command"] = "ACTIONBUTTON1",
			["key2"] = "_NULL",
		}, -- [30]
		{
			["key1"] = "2",
			["command"] = "ACTIONBUTTON2",
			["key2"] = "_NULL",
		}, -- [31]
		{
			["key1"] = "3",
			["command"] = "ACTIONBUTTON3",
			["key2"] = "_NULL",
		}, -- [32]
		{
			["key1"] = "4",
			["command"] = "ACTIONBUTTON4",
			["key2"] = "_NULL",
		}, -- [33]
		{
			["key1"] = "5",
			["command"] = "ACTIONBUTTON5",
			["key2"] = "_NULL",
		}, -- [34]
		{
			["key1"] = "6",
			["command"] = "ACTIONBUTTON6",
			["key2"] = "_NULL",
		}, -- [35]
		{
			["key1"] = "SHIFT-1",
			["command"] = "ACTIONBUTTON7",
			["key2"] = "_NULL",
		}, -- [36]
		{
			["key1"] = "SHIFT-2",
			["command"] = "ACTIONBUTTON8",
			["key2"] = "_NULL",
		}, -- [37]
		{
			["key1"] = "SHIFT-3",
			["command"] = "ACTIONBUTTON9",
			["key2"] = "_NULL",
		}, -- [38]
		{
			["key1"] = "SHIFT-4",
			["command"] = "ACTIONBUTTON10",
			["key2"] = "_NULL",
		}, -- [39]
		{
			["key1"] = "SHIFT-5",
			["command"] = "ACTIONBUTTON11",
			["key2"] = "_NULL",
		}, -- [40]
		{
			["key1"] = "SHIFT-6",
			["command"] = "ACTIONBUTTON12",
			["key2"] = "_NULL",
		}, -- [41]
		{
			["key1"] = "CTRL-F1",
			["command"] = "SHAPESHIFTBUTTON1",
			["key2"] = "_NULL",
		}, -- [42]
		{
			["key1"] = "CTRL-F2",
			["command"] = "SHAPESHIFTBUTTON2",
			["key2"] = "_NULL",
		}, -- [43]
		{
			["key1"] = "CTRL-F3",
			["command"] = "SHAPESHIFTBUTTON3",
			["key2"] = "_NULL",
		}, -- [44]
		{
			["key1"] = "CTRL-F4",
			["command"] = "SHAPESHIFTBUTTON4",
			["key2"] = "_NULL",
		}, -- [45]
		{
			["key1"] = "CTRL-F5",
			["command"] = "SHAPESHIFTBUTTON5",
			["key2"] = "_NULL",
		}, -- [46]
		{
			["key1"] = "CTRL-F6",
			["command"] = "SHAPESHIFTBUTTON6",
			["key2"] = "_NULL",
		}, -- [47]
		{
			["key1"] = "CTRL-F7",
			["command"] = "SHAPESHIFTBUTTON7",
			["key2"] = "_NULL",
		}, -- [48]
		{
			["key1"] = "CTRL-F8",
			["command"] = "SHAPESHIFTBUTTON8",
			["key2"] = "_NULL",
		}, -- [49]
		{
			["key1"] = "CTRL-F9",
			["command"] = "SHAPESHIFTBUTTON9",
			["key2"] = "_NULL",
		}, -- [50]
		{
			["key1"] = "CTRL-F10",
			["command"] = "SHAPESHIFTBUTTON10",
			["key2"] = "_NULL",
		}, -- [51]
		{
			["key1"] = "CTRL-1",
			["command"] = "BONUSACTIONBUTTON1",
			["key2"] = "_NULL",
		}, -- [52]
		{
			["key1"] = "CTRL-2",
			["command"] = "BONUSACTIONBUTTON2",
			["key2"] = "_NULL",
		}, -- [53]
		{
			["key1"] = "CTRL-3",
			["command"] = "BONUSACTIONBUTTON3",
			["key2"] = "_NULL",
		}, -- [54]
		{
			["key1"] = "CTRL-4",
			["command"] = "BONUSACTIONBUTTON4",
			["key2"] = "_NULL",
		}, -- [55]
		{
			["key1"] = "CTRL-5",
			["command"] = "BONUSACTIONBUTTON5",
			["key2"] = "_NULL",
		}, -- [56]
		{
			["key1"] = "CTRL-6",
			["command"] = "BONUSACTIONBUTTON6",
			["key2"] = "_NULL",
		}, -- [57]
		{
			["key1"] = "CTRL-7",
			["command"] = "BONUSACTIONBUTTON7",
			["key2"] = "_NULL",
		}, -- [58]
		{
			["key1"] = "CTRL-8",
			["command"] = "BONUSACTIONBUTTON8",
			["key2"] = "_NULL",
		}, -- [59]
		{
			["key1"] = "CTRL-9",
			["command"] = "BONUSACTIONBUTTON9",
			["key2"] = "_NULL",
		}, -- [60]
		{
			["key1"] = "CTRL-0",
			["command"] = "BONUSACTIONBUTTON10",
			["key2"] = "_NULL",
		}, -- [61]
		{
			["key1"] = "_NULL",
			["command"] = "ACTIONPAGE1",
			["key2"] = "_NULL",
		}, -- [62]
		{
			["key1"] = "_NULL",
			["command"] = "ACTIONPAGE2",
			["key2"] = "_NULL",
		}, -- [63]
		{
			["key1"] = "_NULL",
			["command"] = "ACTIONPAGE3",
			["key2"] = "_NULL",
		}, -- [64]
		{
			["key1"] = "_NULL",
			["command"] = "ACTIONPAGE4",
			["key2"] = "_NULL",
		}, -- [65]
		{
			["key1"] = "_NULL",
			["command"] = "ACTIONPAGE5",
			["key2"] = "_NULL",
		}, -- [66]
		{
			["key1"] = "_NULL",
			["command"] = "ACTIONPAGE6",
			["key2"] = "_NULL",
		}, -- [67]
		{
			["key1"] = "SHIFT-UP",
			["command"] = "PREVIOUSACTIONPAGE",
			["key2"] = "_NULL",
		}, -- [68]
		{
			["key1"] = "SHIFT-DOWN",
			["command"] = "NEXTACTIONPAGE",
			["key2"] = "_NULL",
		}, -- [69]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEACTIONBARLOCK",
			["key2"] = "_NULL",
		}, -- [70]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEAUTOSELFCAST",
			["key2"] = "_NULL",
		}, -- [71]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_MULTICASTFUNCTIONS",
			["key2"] = "_NULL",
		}, -- [72]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTSUMMONBUTTON1",
			["key2"] = "_NULL",
		}, -- [73]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON1",
			["key2"] = "_NULL",
		}, -- [74]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON2",
			["key2"] = "_NULL",
		}, -- [75]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON3",
			["key2"] = "_NULL",
		}, -- [76]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON4",
			["key2"] = "_NULL",
		}, -- [77]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_BLANK",
			["key2"] = "_NULL",
		}, -- [78]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTSUMMONBUTTON2",
			["key2"] = "_NULL",
		}, -- [79]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON5",
			["key2"] = "_NULL",
		}, -- [80]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON6",
			["key2"] = "_NULL",
		}, -- [81]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON7",
			["key2"] = "_NULL",
		}, -- [82]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON8",
			["key2"] = "_NULL",
		}, -- [83]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_BLANK2",
			["key2"] = "_NULL",
		}, -- [84]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTSUMMONBUTTON3",
			["key2"] = "_NULL",
		}, -- [85]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON9",
			["key2"] = "_NULL",
		}, -- [86]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON10",
			["key2"] = "_NULL",
		}, -- [87]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON11",
			["key2"] = "_NULL",
		}, -- [88]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTACTIONBUTTON12",
			["key2"] = "_NULL",
		}, -- [89]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_BLANK3",
			["key2"] = "_NULL",
		}, -- [90]
		{
			["key1"] = "_NULL",
			["command"] = "MULTICASTRECALLBUTTON1",
			["key2"] = "_NULL",
		}, -- [91]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_TARGETING",
			["key2"] = "_NULL",
		}, -- [92]
		{
			["key1"] = "TAB",
			["command"] = "TARGETNEARESTENEMY",
			["key2"] = "_NULL",
		}, -- [93]
		{
			["key1"] = "SHIFT-TAB",
			["command"] = "TARGETPREVIOUSENEMY",
			["key2"] = "_NULL",
		}, -- [94]
		{
			["key1"] = "CTRL-TAB",
			["command"] = "TARGETNEARESTFRIEND",
			["key2"] = "_NULL",
		}, -- [95]
		{
			["key1"] = "CTRL-SHIFT-TAB",
			["command"] = "TARGETPREVIOUSFRIEND",
			["key2"] = "_NULL",
		}, -- [96]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETNEARESTENEMYPLAYER",
			["key2"] = "_NULL",
		}, -- [97]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPREVIOUSENEMYPLAYER",
			["key2"] = "_NULL",
		}, -- [98]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETNEARESTFRIENDPLAYER",
			["key2"] = "_NULL",
		}, -- [99]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPREVIOUSFRIENDPLAYER",
			["key2"] = "_NULL",
		}, -- [100]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETSELF",
			["key2"] = "_NULL",
		}, -- [101]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYMEMBER1",
			["key2"] = "_NULL",
		}, -- [102]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYMEMBER2",
			["key2"] = "_NULL",
		}, -- [103]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYMEMBER3",
			["key2"] = "_NULL",
		}, -- [104]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYMEMBER4",
			["key2"] = "_NULL",
		}, -- [105]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPET",
			["key2"] = "_NULL",
		}, -- [106]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYPET1",
			["key2"] = "_NULL",
		}, -- [107]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYPET2",
			["key2"] = "_NULL",
		}, -- [108]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYPET3",
			["key2"] = "_NULL",
		}, -- [109]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETPARTYPET4",
			["key2"] = "_NULL",
		}, -- [110]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETLASTHOSTILE",
			["key2"] = "_NULL",
		}, -- [111]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETLASTTARGET",
			["key2"] = "_NULL",
		}, -- [112]
		{
			["key1"] = "_NULL",
			["command"] = "NAMEPLATES",
			["key2"] = "_NULL",
		}, -- [113]
		{
			["key1"] = "_NULL",
			["command"] = "FRIENDNAMEPLATES",
			["key2"] = "_NULL",
		}, -- [114]
		{
			["key1"] = "_NULL",
			["command"] = "ALLNAMEPLATES",
			["key2"] = "_NULL",
		}, -- [115]
		{
			["key1"] = "_NULL",
			["command"] = "INTERACTMOUSEOVER",
			["key2"] = "_NULL",
		}, -- [116]
		{
			["key1"] = "_NULL",
			["command"] = "INTERACTTARGET",
			["key2"] = "_NULL",
		}, -- [117]
		{
			["key1"] = "_NULL",
			["command"] = "ASSISTTARGET",
			["key2"] = "_NULL",
		}, -- [118]
		{
			["key1"] = "_NULL",
			["command"] = "ATTACKTARGET",
			["key2"] = "_NULL",
		}, -- [119]
		{
			["key1"] = "_NULL",
			["command"] = "STARTATTACK",
			["key2"] = "_NULL",
		}, -- [120]
		{
			["key1"] = "_NULL",
			["command"] = "PETATTACK",
			["key2"] = "_NULL",
		}, -- [121]
		{
			["key1"] = "_NULL",
			["command"] = "FOCUSTARGET",
			["key2"] = "_NULL",
		}, -- [122]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETFOCUS",
			["key2"] = "_NULL",
		}, -- [123]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETMOUSEOVER",
			["key2"] = "_NULL",
		}, -- [124]
		{
			["key1"] = "_NULL",
			["command"] = "TARGETTALKER",
			["key2"] = "_NULL",
		}, -- [125]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_INTERFACE",
			["key2"] = "_NULL",
		}, -- [126]
		{
			["key1"] = "I",
			["command"] = "TOGGLECHARACTER0",
			["key2"] = "_NULL",
		}, -- [127]
		{
			["key1"] = "F12",
			["command"] = "TOGGLEBACKPACK",
			["key2"] = "_NULL",
		}, -- [128]
		{
			["key1"] = "F8",
			["command"] = "TOGGLEBAG1",
			["key2"] = "_NULL",
		}, -- [129]
		{
			["key1"] = "F9",
			["command"] = "TOGGLEBAG2",
			["key2"] = "_NULL",
		}, -- [130]
		{
			["key1"] = "F10",
			["command"] = "TOGGLEBAG3",
			["key2"] = "_NULL",
		}, -- [131]
		{
			["key1"] = "F11",
			["command"] = "TOGGLEBAG4",
			["key2"] = "_NULL",
		}, -- [132]
		{
			["key1"] = "_NULL",
			["command"] = "OPENALLBAGS",
			["key2"] = "_NULL",
		}, -- [133]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEKEYRING",
			["key2"] = "_NULL",
		}, -- [134]
		{
			["key1"] = "P",
			["command"] = "TOGGLESPELLBOOK",
			["key2"] = "_NULL",
		}, -- [135]
		{
			["key1"] = "SHIFT-I",
			["command"] = "TOGGLEPETBOOK",
			["key2"] = "_NULL",
		}, -- [136]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEINSCRIPTION",
			["key2"] = "_NULL",
		}, -- [137]
		{
			["key1"] = "N",
			["command"] = "TOGGLETALENTS",
			["key2"] = "_NULL",
		}, -- [138]
		{
			["key1"] = "H",
			["command"] = "TOGGLECHARACTER4",
			["key2"] = "_NULL",
		}, -- [139]
		{
			["key1"] = "SHIFT-P",
			["command"] = "TOGGLECHARACTER3",
			["key2"] = "_NULL",
		}, -- [140]
		{
			["key1"] = "U",
			["command"] = "TOGGLECHARACTER2",
			["key2"] = "_NULL",
		}, -- [141]
		{
			["key1"] = "K",
			["command"] = "TOGGLECHARACTER1",
			["key2"] = "_NULL",
		}, -- [142]
		{
			["key1"] = "L",
			["command"] = "TOGGLEQUESTLOG",
			["key2"] = "_NULL",
		}, -- [143]
		{
			["key1"] = "ESCAPE",
			["command"] = "TOGGLEGAMEMENU",
			["key2"] = "_NULL",
		}, -- [144]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEMINIMAP",
			["key2"] = "_NULL",
		}, -- [145]
		{
			["key1"] = "M",
			["command"] = "TOGGLEWORLDMAP",
			["key2"] = "_NULL",
		}, -- [146]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEWORLDMAPSIZE",
			["key2"] = "_NULL",
		}, -- [147]
		{
			["key1"] = "O",
			["command"] = "TOGGLESOCIAL",
			["key2"] = "_NULL",
		}, -- [148]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEFRIENDSTAB",
			["key2"] = "_NULL",
		}, -- [149]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEWHOTAB",
			["key2"] = "_NULL",
		}, -- [150]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEGUILDTAB",
			["key2"] = "_NULL",
		}, -- [151]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLECHATTAB",
			["key2"] = "_NULL",
		}, -- [152]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLERAIDTAB",
			["key2"] = "_NULL",
		}, -- [153]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLELFGPARENT",
			["key2"] = "_NULL",
		}, -- [154]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLELFRPARENT",
			["key2"] = "_NULL",
		}, -- [155]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEWORLDSTATESCORES",
			["key2"] = "_NULL",
		}, -- [156]
		{
			["key1"] = "SHIFT-M",
			["command"] = "TOGGLEBATTLEFIELDMINIMAP",
			["key2"] = "_NULL",
		}, -- [157]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEMINIMAPROTATION",
			["key2"] = "_NULL",
		}, -- [158]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLECHANNELPULLOUT",
			["key2"] = "_NULL",
		}, -- [159]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEACHIEVEMENT",
			["key2"] = "_NULL",
		}, -- [160]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLESTATISTICS",
			["key2"] = "_NULL",
		}, -- [161]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLECURRENCY",
			["key2"] = "_NULL",
		}, -- [162]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_MISC",
			["key2"] = "_NULL",
		}, -- [163]
		{
			["key1"] = "_NULL",
			["command"] = "STOPCASTING",
			["key2"] = "_NULL",
		}, -- [164]
		{
			["key1"] = "_NULL",
			["command"] = "STOPATTACK",
			["key2"] = "_NULL",
		}, -- [165]
		{
			["key1"] = "_NULL",
			["command"] = "DISMOUNT",
			["key2"] = "_NULL",
		}, -- [166]
		{
			["key1"] = "_NULL",
			["command"] = "MINIMAPZOOMIN",
			["key2"] = "_NULL",
		}, -- [167]
		{
			["key1"] = "_NULL",
			["command"] = "MINIMAPZOOMOUT",
			["key2"] = "_NULL",
		}, -- [168]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEMUSIC",
			["key2"] = "_NULL",
		}, -- [169]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLESOUND",
			["key2"] = "_NULL",
		}, -- [170]
		{
			["key1"] = "_NULL",
			["command"] = "MASTERVOLUMEUP",
			["key2"] = "_NULL",
		}, -- [171]
		{
			["key1"] = "_NULL",
			["command"] = "MASTERVOLUMEDOWN",
			["key2"] = "_NULL",
		}, -- [172]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLESELFMUTE",
			["key2"] = "_NULL",
		}, -- [173]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEUI",
			["key2"] = "_NULL",
		}, -- [174]
		{
			["key1"] = "_NULL",
			["command"] = "TOGGLEFPS",
			["key2"] = "_NULL",
		}, -- [175]
		{
			["key1"] = "PRINTSCREEN",
			["command"] = "SCREENSHOT",
			["key2"] = "_NULL",
		}, -- [176]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_CAMERA",
			["key2"] = "_NULL",
		}, -- [177]
		{
			["key1"] = "END",
			["command"] = "NEXTVIEW",
			["key2"] = "_NULL",
		}, -- [178]
		{
			["key1"] = "HOME",
			["command"] = "PREVVIEW",
			["key2"] = "_NULL",
		}, -- [179]
		{
			["key1"] = "MOUSEWHEELUP",
			["command"] = "CAMERAZOOMIN",
			["key2"] = "SHIFT-MOUSEWHEELUP",
		}, -- [180]
		{
			["key1"] = "MOUSEWHEELDOWN",
			["command"] = "CAMERAZOOMOUT",
			["key2"] = "SHIFT-MOUSEWHEELDOWN",
		}, -- [181]
		{
			["key1"] = "_NULL",
			["command"] = "SETVIEW1",
			["key2"] = "_NULL",
		}, -- [182]
		{
			["key1"] = "_NULL",
			["command"] = "SETVIEW2",
			["key2"] = "_NULL",
		}, -- [183]
		{
			["key1"] = "_NULL",
			["command"] = "SETVIEW3",
			["key2"] = "_NULL",
		}, -- [184]
		{
			["key1"] = "_NULL",
			["command"] = "SETVIEW4",
			["key2"] = "_NULL",
		}, -- [185]
		{
			["key1"] = "_NULL",
			["command"] = "SETVIEW5",
			["key2"] = "_NULL",
		}, -- [186]
		{
			["key1"] = "_NULL",
			["command"] = "SAVEVIEW1",
			["key2"] = "_NULL",
		}, -- [187]
		{
			["key1"] = "_NULL",
			["command"] = "SAVEVIEW2",
			["key2"] = "_NULL",
		}, -- [188]
		{
			["key1"] = "_NULL",
			["command"] = "SAVEVIEW3",
			["key2"] = "_NULL",
		}, -- [189]
		{
			["key1"] = "_NULL",
			["command"] = "SAVEVIEW4",
			["key2"] = "_NULL",
		}, -- [190]
		{
			["key1"] = "_NULL",
			["command"] = "SAVEVIEW5",
			["key2"] = "_NULL",
		}, -- [191]
		{
			["key1"] = "_NULL",
			["command"] = "RESETVIEW1",
			["key2"] = "_NULL",
		}, -- [192]
		{
			["key1"] = "_NULL",
			["command"] = "RESETVIEW2",
			["key2"] = "_NULL",
		}, -- [193]
		{
			["key1"] = "_NULL",
			["command"] = "RESETVIEW3",
			["key2"] = "_NULL",
		}, -- [194]
		{
			["key1"] = "_NULL",
			["command"] = "RESETVIEW4",
			["key2"] = "_NULL",
		}, -- [195]
		{
			["key1"] = "_NULL",
			["command"] = "RESETVIEW5",
			["key2"] = "_NULL",
		}, -- [196]
		{
			["key1"] = "_NULL",
			["command"] = "FLIPCAMERAYAW",
			["key2"] = "_NULL",
		}, -- [197]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_MULTIACTIONBAR",
			["key2"] = "_NULL",
		}, -- [198]
		{
			["key1"] = "Q",
			["command"] = "MULTIACTIONBAR1BUTTON1",
			["key2"] = "_NULL",
		}, -- [199]
		{
			["key1"] = "SHIFT-Q",
			["command"] = "MULTIACTIONBAR1BUTTON2",
			["key2"] = "_NULL",
		}, -- [200]
		{
			["key1"] = "E",
			["command"] = "MULTIACTIONBAR1BUTTON3",
			["key2"] = "_NULL",
		}, -- [201]
		{
			["key1"] = "SHIFT-E",
			["command"] = "MULTIACTIONBAR1BUTTON4",
			["key2"] = "_NULL",
		}, -- [202]
		{
			["key1"] = "R",
			["command"] = "MULTIACTIONBAR1BUTTON5",
			["key2"] = "_NULL",
		}, -- [203]
		{
			["key1"] = "SHIFT-R",
			["command"] = "MULTIACTIONBAR1BUTTON6",
			["key2"] = "_NULL",
		}, -- [204]
		{
			["key1"] = "CTRL-R",
			["command"] = "MULTIACTIONBAR1BUTTON7",
			["key2"] = "_NULL",
		}, -- [205]
		{
			["key1"] = "T",
			["command"] = "MULTIACTIONBAR1BUTTON8",
			["key2"] = "_NULL",
		}, -- [206]
		{
			["key1"] = "SHIFT-T",
			["command"] = "MULTIACTIONBAR1BUTTON9",
			["key2"] = "_NULL",
		}, -- [207]
		{
			["key1"] = "F",
			["command"] = "MULTIACTIONBAR1BUTTON10",
			["key2"] = "_NULL",
		}, -- [208]
		{
			["key1"] = "SHIFT-F",
			["command"] = "MULTIACTIONBAR1BUTTON11",
			["key2"] = "_NULL",
		}, -- [209]
		{
			["key1"] = "CTRL-F",
			["command"] = "MULTIACTIONBAR1BUTTON12",
			["key2"] = "_NULL",
		}, -- [210]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_BLANK4",
			["key2"] = "_NULL",
		}, -- [211]
		{
			["key1"] = "G",
			["command"] = "MULTIACTIONBAR2BUTTON1",
			["key2"] = "_NULL",
		}, -- [212]
		{
			["key1"] = "SHIFT-G",
			["command"] = "MULTIACTIONBAR2BUTTON2",
			["key2"] = "_NULL",
		}, -- [213]
		{
			["key1"] = "CTRL-G",
			["command"] = "MULTIACTIONBAR2BUTTON3",
			["key2"] = "_NULL",
		}, -- [214]
		{
			["key1"] = "Z",
			["command"] = "MULTIACTIONBAR2BUTTON4",
			["key2"] = "_NULL",
		}, -- [215]
		{
			["key1"] = "SHIFT-Z",
			["command"] = "MULTIACTIONBAR2BUTTON5",
			["key2"] = "_NULL",
		}, -- [216]
		{
			["key1"] = "X",
			["command"] = "MULTIACTIONBAR2BUTTON6",
			["key2"] = "_NULL",
		}, -- [217]
		{
			["key1"] = "SHIFT-X",
			["command"] = "MULTIACTIONBAR2BUTTON7",
			["key2"] = "_NULL",
		}, -- [218]
		{
			["key1"] = "C",
			["command"] = "MULTIACTIONBAR2BUTTON8",
			["key2"] = "_NULL",
		}, -- [219]
		{
			["key1"] = "SHIFT-C",
			["command"] = "MULTIACTIONBAR2BUTTON9",
			["key2"] = "_NULL",
		}, -- [220]
		{
			["key1"] = "V",
			["command"] = "MULTIACTIONBAR2BUTTON10",
			["key2"] = "_NULL",
		}, -- [221]
		{
			["key1"] = "SHIFT-V",
			["command"] = "MULTIACTIONBAR2BUTTON11",
			["key2"] = "_NULL",
		}, -- [222]
		{
			["key1"] = "CTRL-V",
			["command"] = "MULTIACTIONBAR2BUTTON12",
			["key2"] = "_NULL",
		}, -- [223]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_BLANK5",
			["key2"] = "_NULL",
		}, -- [224]
		{
			["key1"] = "F1",
			["command"] = "MULTIACTIONBAR3BUTTON1",
			["key2"] = "_NULL",
		}, -- [225]
		{
			["key1"] = "F2",
			["command"] = "MULTIACTIONBAR3BUTTON2",
			["key2"] = "_NULL",
		}, -- [226]
		{
			["key1"] = "F3",
			["command"] = "MULTIACTIONBAR3BUTTON3",
			["key2"] = "_NULL",
		}, -- [227]
		{
			["key1"] = "F4",
			["command"] = "MULTIACTIONBAR3BUTTON4",
			["key2"] = "_NULL",
		}, -- [228]
		{
			["key1"] = "F5",
			["command"] = "MULTIACTIONBAR3BUTTON5",
			["key2"] = "_NULL",
		}, -- [229]
		{
			["key1"] = "F6",
			["command"] = "MULTIACTIONBAR3BUTTON6",
			["key2"] = "_NULL",
		}, -- [230]
		{
			["key1"] = "7",
			["command"] = "MULTIACTIONBAR3BUTTON7",
			["key2"] = "_NULL",
		}, -- [231]
		{
			["key1"] = "8",
			["command"] = "MULTIACTIONBAR3BUTTON8",
			["key2"] = "_NULL",
		}, -- [232]
		{
			["key1"] = "9",
			["command"] = "MULTIACTIONBAR3BUTTON9",
			["key2"] = "_NULL",
		}, -- [233]
		{
			["key1"] = "0",
			["command"] = "MULTIACTIONBAR3BUTTON10",
			["key2"] = "_NULL",
		}, -- [234]
		{
			["key1"] = "SHIFT-B",
			["command"] = "MULTIACTIONBAR3BUTTON11",
			["key2"] = "_NULL",
		}, -- [235]
		{
			["key1"] = "-",
			["command"] = "MULTIACTIONBAR3BUTTON12",
			["key2"] = "_NULL",
		}, -- [236]
		{
			["key1"] = "=",
			["command"] = "HEADER_BLANK6",
			["key2"] = "_NULL",
		}, -- [237]
		{
			["key1"] = "SHIFT-F1",
			["command"] = "MULTIACTIONBAR4BUTTON1",
			["key2"] = "_NULL",
		}, -- [238]
		{
			["key1"] = "SHIFT-F2",
			["command"] = "MULTIACTIONBAR4BUTTON2",
			["key2"] = "_NULL",
		}, -- [239]
		{
			["key1"] = "SHIFT-F3",
			["command"] = "MULTIACTIONBAR4BUTTON3",
			["key2"] = "_NULL",
		}, -- [240]
		{
			["key1"] = "SHIFT-F4",
			["command"] = "MULTIACTIONBAR4BUTTON4",
			["key2"] = "_NULL",
		}, -- [241]
		{
			["key1"] = "SHIFT-F5",
			["command"] = "MULTIACTIONBAR4BUTTON5",
			["key2"] = "_NULL",
		}, -- [242]
		{
			["key1"] = "SHIFT-F6",
			["command"] = "MULTIACTIONBAR4BUTTON6",
			["key2"] = "_NULL",
		}, -- [243]
		{
			["key1"] = "_NULL",
			["command"] = "MULTIACTIONBAR4BUTTON7",
			["key2"] = "_NULL",
		}, -- [244]
		{
			["key1"] = "_NULL",
			["command"] = "MULTIACTIONBAR4BUTTON8",
			["key2"] = "_NULL",
		}, -- [245]
		{
			["key1"] = "_NULL",
			["command"] = "MULTIACTIONBAR4BUTTON9",
			["key2"] = "_NULL",
		}, -- [246]
		{
			["key1"] = "_NULL",
			["command"] = "MULTIACTIONBAR4BUTTON10",
			["key2"] = "_NULL",
		}, -- [247]
		{
			["key1"] = "B",
			["command"] = "MULTIACTIONBAR4BUTTON11",
			["key2"] = "_NULL",
		}, -- [248]
		{
			["key1"] = "_NULL",
			["command"] = "MULTIACTIONBAR4BUTTON12",
			["key2"] = "_NULL",
		}, -- [249]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_RAID_TARGET",
			["key2"] = "_NULL",
		}, -- [250]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET1",
			["key2"] = "_NULL",
		}, -- [251]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET2",
			["key2"] = "_NULL",
		}, -- [252]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET3",
			["key2"] = "_NULL",
		}, -- [253]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET4",
			["key2"] = "_NULL",
		}, -- [254]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET5",
			["key2"] = "_NULL",
		}, -- [255]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET6",
			["key2"] = "_NULL",
		}, -- [256]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET7",
			["key2"] = "_NULL",
		}, -- [257]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGET8",
			["key2"] = "_NULL",
		}, -- [258]
		{
			["key1"] = "_NULL",
			["command"] = "RAIDTARGETNONE",
			["key2"] = "_NULL",
		}, -- [259]
		{
			["key1"] = "_NULL",
			["command"] = "HEADER_VEHICLE",
			["key2"] = "_NULL",
		}, -- [260]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLEEXIT",
			["key2"] = "_NULL",
		}, -- [261]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLEPREVSEAT",
			["key2"] = "_NULL",
		}, -- [262]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLENEXTSEAT",
			["key2"] = "_NULL",
		}, -- [263]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLEAIMUP",
			["key2"] = "_NULL",
		}, -- [264]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLEAIMDOWN",
			["key2"] = "_NULL",
		}, -- [265]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLEAIMINCREMENT",
			["key2"] = "_NULL",
		}, -- [266]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLEAIMDECREMENT",
			["key2"] = "_NULL",
		}, -- [267]
		{
			["key1"] = "_NULL",
			["command"] = "VEHICLECAMERAZOOMIN",
			["key2"] = "_NULL",
		}, -- [268]
	}
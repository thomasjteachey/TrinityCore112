-- ClassicResTimers.lua (WotLK 3.3.5a / 12340)
-- Rez wave tracker for supported battlegrounds + CTF flag carrier names (click to /target)
-- Thomas build base, with:
--   - BG-instance awareness (no subzone bugs)
--   - Sturdier CTF flag logic for WSG/TP (auto drops/returns, proper reset)
--   - Own-team FC detection via raid auras (works if you join mid)
--   - Enemy FC detection via target/focus/mouseover auras
--   - Rez timers using real elapsed time, plus smoothed Spirit Healer sync:
--       * Internal timers tick in real seconds
--       * Local SH graveyard shows a slightly delayed copy of GetAreaSpiritHealerTime()
--         so you don't run ~0.5s ahead of Blizzard's UI

local ADDON_NAME = ...
local CRT = CreateFrame("Frame", "ClassicResTimerFrame", UIParent)
local wipe = wipe or function(t) for k in pairs(t) do t[k] = nil end end

-- =========================
-- Config / State
-- =========================
CRT.UpdateInterval      = 0.50
CRT.TimeSinceLastUpdate = 0
-- Server wave-to-wave interval. Do not include the separate ~0.5s
-- spirit-heal visual delay here or the predicted phase will drift each wave.
CRT.DefaultResInterval  = 30
CRT.ResInterval         = CRT.DefaultResInterval
CRT.ExtraNowSeconds     = 2  -- grace before an unsynced remote timer wraps
CRT.userYOffset         = nil

-- Spirit Healer smoothing:
-- The server resurrects just over 0.5s after its wave timer reaches zero.
-- With a 0.5s update cadence, 0.4s intentionally defers adoption until the
-- next addon update and therefore yields approximately the same 0.5s buffer.
CRT.localSHDelay        = 0.4

CRT.timeleft, CRT.lastlost, CRT.lastsync, CRT.reporting = {}, {}, {}, {}
CRT.lastdead = 0

-- BGs we support
CRT.bgNames = {
  ["Alterac Valley"] = true,
  ["Arathi Basin"]   = true,
  ["Warsong Gulch"]  = true,
  ["Twin Peaks"]     = true,
  ["Battle for Gilneas"] = true,
  ["The Scarlet Chapel"] = true,
  ["Blackrock Throne"] = true,
  ["Obsidian Colosseum"] = true,
}

-- =========================
-- Score highlight config
-- =========================
CRT.scoreHighlightConfig = {
  enabled = true,

  -- The rectangle encloses the row's score text and stops there, so it grows
  -- with the text on its own ("0/30" in the Scarlet Chapel against
  -- "Bases: 3  Resources: 640/1600" in Arathi Basin). These are the few pixels
  -- of breathing room on each side; raise them to loosen the box.
  padLeft = 4,
  padRight = 4,
  padTop = 2,
  padBottom = 2,

  -- Final nudge after sizing.
  xOffset = 0,
  yOffset = 0,

  -- Plain rectangle color.
  r = 0.0,
  g = 0.5,
  b = 0.0,
  a = 0.5,
}

-- How far under the last worldstate score row the timer sits. The timer is
-- anchored to that row rather than to the top of the screen, so a battleground
-- with taller or fewer rows does not need its own number here.
CRT.timerGapBelowRows = -10

-- Only used before the worldstate rows exist (the moment you zone in) or in a
-- battleground that draws none. Keep them in step with timerGapBelowRows so
-- the timer does not visibly jump once the rows arrive.
CRT.defaultpos = {
  ["Alterac Valley"] = { x = 0, y = -80 },
  ["Arathi Basin"]   = { x = 0, y = -80 },
  ["Warsong Gulch"]  = { x = 0, y = -80 },
  ["Twin Peaks"]     = { x = 0, y = -80 },
  ["Battle for Gilneas"] = { x = 0, y = -80 },
  ["The Scarlet Chapel"] = { x = 0, y = -80 },
  ["Blackrock Throne"] = { x = 0, y = -80 },
  ["Obsidian Colosseum"] = { x = 0, y = -80 },
}

CRT.prettynames = {
  ["Alterac Valley"] = {
    ["Dun Baldar"]            = "Stormpike Aid Station",
    ["Frostwolf Keep"]        = "Frostwolf Relief Hut",
    ["Stonehearth Graveyard"] = "Stonehearth Graveyard",
    ["Stormpike Graveyard"]   = "Stormpike Graveyard",
    ["Iceblood Graveyard"]    = "Iceblood Graveyard",
    ["Frostwolf Graveyard"]   = "Frostwolf Graveyard",
    ["Snowfall Graveyard"]    = "Snowfall Graveyard",
  },
  ["Arathi Basin"] = {
    ["Stables"]        = "Stables",
    ["Farm"]           = "Farm",
    ["Lumber Mill"]    = "Lumber Mill",
    ["Blacksmith"]     = "Blacksmith",
    ["Gold Mine"]      = "Gold Mine",
    ["Trollbane Hall"] = "Trollbane Hall",
    ["Defiler's Den"]  = "Defiler's Den",
  },
  ["Warsong Gulch"] = {
    ["Alliance Flag Room"] = "Alliance Flag Room",
    ["Horde Flag Room"]    = "Horde Flag Room",
    ["Alliance Tunnel"]    = "Alliance Tunnel",
    ["Horde Tunnel"]       = "Horde Tunnel",
    -- safety/self-maps for clients that show these labels:
    ["Warsong Flag Room"]  = "Warsong Flag Room",
    ["Warsong Lumber Mill"]= "Warsong Lumber Mill",
  },
  ["Twin Peaks"] = {
    ["Alliance Flag Room"] = "Alliance Flag Room",
    ["Horde Flag Room"]    = "Horde Flag Room",
    ["Alliance Tunnel"]    = "Alliance Tunnel",
    ["Horde Tunnel"]       = "Horde Tunnel",
    ["Wildhammer Stronghold"] = "Wildhammer Stronghold",
    ["Dragonmaw Clan Compound"] = "Dragonmaw Clan Compound",
  },
  -- These maps still get the exact local Spirit Healer countdown. Their
  -- custom graveyards do not use stock assault/capture announcement names.
  ["Battle for Gilneas"] = {},
  ["The Scarlet Chapel"] = {},
  ["Blackrock Throne"] = {},
  ["Obsidian Colosseum"] = {},
}

CRT.startText = {
  ["The Battle for Alterac Valley has begun!"] = 5,
  ["The Battle for Arathi Basin has begun!"]   = 5,
  ["Let the battle for Warsong Gulch begin!"]  = 5,
  ["The battle for Twin Peaks has begun!"]       = 5,
  ["Let the battle for Twin Peaks begin!"]       = 5,
}

-- Spirit Healer smoothing state
CRT.localSHSub           = nil
CRT.localSHRawLast       = nil
CRT.localSHDisplayLast   = nil
CRT.localSHDisplayTarget = nil
CRT.localSHDisplayDue    = 0

-- BG helper (instance-based so subzones don't matter)
local function InBG()
  local name, instType = GetInstanceInfo()
  if instType == "pvp" and CRT.bgNames[name] then
    return true, name
  end
  return false, nil
end

-- Every battleground instance, including ones whose graveyards and flag rules
-- this addon does not model. The team square only needs the scoreboard and the
-- always-up rows, so it has no reason to be held to the curated list above.
-- Arenas report "arena" here and are left alone.
local function InPvPInstance()
  local _, instType = GetInstanceInfo()
  return instType == "pvp"
end

CRT.ctfNames = {
  ["Warsong Gulch"] = true,
  ["Twin Peaks"]   = true,
}

local function IsCTFBG()
  local inBG, which = InBG()
  if inBG and CRT.ctfNames[which] then
    return true, which
  end
  return false, which
end

local function CRT_RowSideFromIcon(icon)
  local texture = string.lower(tostring(icon or ""))
  if string.find(texture, "pvp%-alliance") then
    return "Alliance"
  elseif string.find(texture, "pvp%-horde") then
    return "Horde"
  end
  return nil
end

local function CRT_GetAlwaysUpRowFrame(side)
  -- Prefer the actual visible row with a static Alliance/Horde score icon.
  -- The worldstate frame only Hides leftover rows, it never clears their icon
  -- textures, so a row left over from a previous battleground still answers
  -- "Horde" here. Skip anything that is not currently on screen.
  for i = 1, 5 do
    local frame = _G["AlwaysUpFrame" .. i]
    local icon = _G["AlwaysUpFrame" .. i .. "Icon"]
    if frame and icon and frame:IsShown() then
      local rowSide = CRT_RowSideFromIcon(icon:GetTexture())
      if rowSide == side then
        return frame, i
      end
    end
  end

  -- Fallback for stock CTF ordering if the row texture is not queryable yet.
  -- Only the CTF maps are known to order their rows this way. Guessing in any
  -- other battleground would paint the square on a row that is not a team, so
  -- everywhere else an unmatched icon simply means "no row".
  if IsCTFBG() then
    if side == "Alliance" then
      return _G["AlwaysUpFrame1"], 1
    elseif side == "Horde" then
      return _G["AlwaysUpFrame2"], 2
    end
  end
  return nil, nil
end

local function CRT_GetAlwaysUpAnchor(side)
  local frame = CRT_GetAlwaysUpRowFrame(side)
  if not frame then return nil end

  local name = frame:GetName()
  return _G[name .. "DynamicIconButton"] or _G[name .. "DynamicIconButtonIcon"] or frame
end

-- =========================
-- Frame (timer text)
-- =========================
CRT:SetSize(300, 14)
CRT:SetPoint("TOP", UIParent, "TOP", 0, -60)
CRT:SetScript("OnDragStart", function(s) s:StartMoving() end)
CRT:SetScript("OnDragStop",  function(s) s:StopMovingOrSizing() end)

CRT.timestr = CRT:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
CRT.timestr:SetPoint("TOP", CRT, "TOP", 0, 0)
CRT.timestr:SetWidth(300)
CRT.timestr:SetJustifyH("CENTER")
CRT.timestr:SetText("")

-- =========================
-- CTF Carrier Labels
-- =========================
CRT.flagCarrier = { Alliance = nil, Horde = nil }
CRT.carrierA, CRT.carrierH = nil, nil

CRT.hasAuthoritativeWSG = false
CRT.authoritativeState = { A = nil, H = nil }

local function CRT_RequestWSGFull()
  if not IsCTFBG() then return end
  if not SendAddonMessage then return end
  SendAddonMessage("CWSGREQ", "FULL", "BATTLEGROUND")
end

local function CRT_RequestCustomGameRules()
  local inBG = InBG()
  if not inBG or not SendAddonMessage then return end
  SendAddonMessage("CCGAMEREQ", "RULES", "BATTLEGROUND")
end

local function CRT_ApplyCustomGameRules(prefix, msg)
  if prefix ~= "CCGAME" or type(msg) ~= "string" then return false end

  local seconds = tonumber(string.match(msg, "^REZ:(%d+)$"))
  if not seconds or seconds < 1 or seconds > 300 then return false end

  CRT.ResInterval = seconds
  return true
end

local function CRT_SplitColon(msg)
  local out, start = {}, 1
  while true do
    local i = string.find(msg, ":", start, true)
    if not i then
      table.insert(out, string.sub(msg, start))
      break
    end
    table.insert(out, string.sub(msg, start, i - 1))
    start = i + 1
  end
  return out
end

local function CRT_ApplyAuthoritativeWSG(aCarrier, hCarrier, aState, hState)
  CRT.hasAuthoritativeWSG = true
  CRT.authoritativeState.A = aState
  CRT.authoritativeState.H = hState

  -- Row 1 / Alliance side carries the Horde (red) flag.
  if hState == "PLAYER" and hCarrier and hCarrier ~= "" then
    CRT.flagCarrier.Alliance = hCarrier
  else
    CRT.flagCarrier.Alliance = nil
  end

  -- Row 2 / Horde side carries the Alliance (blue) flag.
  if aState == "PLAYER" and aCarrier and aCarrier ~= "" then
    CRT.flagCarrier.Horde = aCarrier
  else
    CRT.flagCarrier.Horde = nil
  end

  CRT:UpdateCarrierLabels()
end

local function CRT_ParseAuthoritativeWSG(prefix, payload)
  if prefix ~= "CWSG" or not payload or payload == "" then return false end

  local parts = CRT_SplitColon(payload)

  if parts[1] == "FULL" then
    CRT_ApplyAuthoritativeWSG(parts[2] or "", parts[3] or "", parts[4] or "", parts[5] or "")
    return true
  end

  local side = parts[1]
  local action = parts[2]
  local who = parts[3]
  if not side or not action or (side ~= "A" and side ~= "H") then return false end

  if who == "" then
    who = nil
  end

  CRT.hasAuthoritativeWSG = true

  if action == "PICKUP" then
    CRT.authoritativeState[side] = "PLAYER"
  elseif action == "DROP" then
    CRT.authoritativeState[side] = "GROUND"
  elseif action == "RETURN" then
    CRT.authoritativeState[side] = "BASE"
  elseif action == "CAPTURE" then
    CRT.authoritativeState[side] = "WAIT"
  elseif action == "WAIT" then
    CRT.authoritativeState[side] = "WAIT"
  end

  if side == "A" then
    -- Physical Alliance flag (blue) => Horde-side carrier label.
    if action == "PICKUP" and who then
      CRT.flagCarrier.Horde = who
    elseif action == "DROP" or action == "RETURN" or action == "CAPTURE" or action == "WAIT" then
      CRT.flagCarrier.Horde = nil
    end
  else
    -- Physical Horde flag (red) => Alliance-side carrier label.
    if action == "PICKUP" and who then
      CRT.flagCarrier.Alliance = who
    elseif action == "DROP" or action == "RETURN" or action == "CAPTURE" or action == "WAIT" then
      CRT.flagCarrier.Alliance = nil
    end
  end

  CRT:UpdateCarrierLabels()
  return true
end

local function FindTopButtons()
  -- Prefer the dynamic icon button so the name sits beside the actual flag icon.
  -- Detect rows by their static faction icon; this makes WSG and Twin Peaks work
  -- even if the client orders the AlwaysUp rows differently.
  local a = CRT_GetAlwaysUpAnchor("Alliance")
  local h = CRT_GetAlwaysUpAnchor("Horde")
  return a, h
end

local function MakeCarrierButton(anchor)
  if not anchor then return nil end
  local b = CreateFrame("Button", nil, UIParent, "SecureActionButtonTemplate")
  b:SetFrameStrata("HIGH")
  b:SetToplevel(true)
  b:SetSize(160, 16)
  b:ClearAllPoints()
  b:SetPoint("LEFT", anchor, "RIGHT", 6, 0)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  b.text:SetPoint("LEFT", b, "LEFT", 0, 0)
  b.text:SetJustifyH("LEFT")
  b:RegisterForClicks("AnyUp")
  b:SetHitRectInsets(0, -24, 0, 0)
  b:Hide()
  return b
end

local function EnsureCarrierButtons()
  local A, H = FindTopButtons()
  if A then
    if not CRT.carrierA then
      CRT.carrierA = MakeCarrierButton(A)
    else
      CRT.carrierA:ClearAllPoints()
      CRT.carrierA:SetPoint("LEFT", A, "RIGHT", 6, 0)
    end
  end
  if H then
    if not CRT.carrierH then
      CRT.carrierH = MakeCarrierButton(H)
    else
      CRT.carrierH:ClearAllPoints()
      CRT.carrierH:SetPoint("LEFT", H, "RIGHT", 6, 0)
    end
  end
end


local function MakeScoreHighlight(rowFrame)
  if not rowFrame then return nil end

  local tex = rowFrame:CreateTexture(nil, "BACKGROUND")
  tex:SetTexture("Interface\\Buttons\\WHITE8X8")
  tex:Hide()
  return tex
end

local function ApplyScoreHighlightStyle(tex)
  if not tex then return end
  local cfg = CRT.scoreHighlightConfig or {}
  tex:SetVertexColor(cfg.r or 0.0, cfg.g or 1.0, cfg.b or 0.0, cfg.a or 1.0)
end

local function LayoutScoreHighlight(tex, rowFrame)
  if not tex or not rowFrame then return end

  local cfg = CRT.scoreHighlightConfig or {}
  local rowName = rowFrame:GetName()
  local textRegion = _G[rowName .. "Text"]

  local padLeft   = cfg.padLeft or 2
  local padRight  = cfg.padRight or 2
  local padTop    = cfg.padTop or 2
  local padBottom = cfg.padBottom or 2
  local xOffset   = cfg.xOffset or 0
  local yOffset   = cfg.yOffset or 0

  -- Box the row's score text and nothing else. The faction icon is deliberately
  -- left out: its REGION is larger than the shield drawn in it, because the PvP
  -- faction textures carry transparent padding, so including it always left a
  -- band of dead space that no amount of padding tuning could close.
  --
  -- Anchors, never measured coordinates: GetLeft() and friends return nil until
  -- the worldstate frame has laid the row out, which silently turned every
  -- measured rectangle into a stub somewhere off the row.
  if not textRegion then
    -- Falling back to the row frame puts the box somewhere the content is not,
    -- so say so once instead of silently drawing it in the wrong place.
    if not CRT.warnedMissingRowRegions then
      CRT.warnedMissingRowRegions = true
      DEFAULT_CHAT_FRAME:AddMessage(string.format(
        "|cffff4444[CRT]|r %s: no Text region - team square falling back to the row frame (/crt rows)",
        tostring(rowName)))
    end
    tex:ClearAllPoints()
    tex:SetPoint("TOPLEFT", rowFrame, "TOPLEFT", -padLeft + xOffset, padTop + yOffset)
    tex:SetPoint("BOTTOMRIGHT", rowFrame, "BOTTOMRIGHT", padRight + xOffset, -padBottom + yOffset)
    return
  end

  tex:ClearAllPoints()
  tex:SetPoint("LEFT", textRegion, "LEFT", -padLeft + xOffset, 0)
  tex:SetPoint("RIGHT", textRegion, "RIGHT", padRight + xOffset, 0)
  tex:SetPoint("TOP", textRegion, "TOP", 0, padTop + yOffset)
  tex:SetPoint("BOTTOM", textRegion, "BOTTOM", 0, -padBottom + yOffset)
end

local function EnsureScoreHighlights()
  local rowA = CRT_GetAlwaysUpRowFrame("Alliance")
  local rowH = CRT_GetAlwaysUpRowFrame("Horde")

  if CRT.scoreHighlightA and CRT.scoreHighlightA._row ~= rowA then
    CRT.scoreHighlightA:Hide()
    CRT.scoreHighlightA = nil
  end
  if CRT.scoreHighlightH and CRT.scoreHighlightH._row ~= rowH then
    CRT.scoreHighlightH:Hide()
    CRT.scoreHighlightH = nil
  end

  if rowA then
    if not CRT.scoreHighlightA then
      CRT.scoreHighlightA = MakeScoreHighlight(rowA)
      CRT.scoreHighlightA._row = rowA
    end
    ApplyScoreHighlightStyle(CRT.scoreHighlightA)
    LayoutScoreHighlight(CRT.scoreHighlightA, rowA)
  end

  if rowH then
    if not CRT.scoreHighlightH then
      CRT.scoreHighlightH = MakeScoreHighlight(rowH)
      CRT.scoreHighlightH._row = rowH
    end
    ApplyScoreHighlightStyle(CRT.scoreHighlightH)
    LayoutScoreHighlight(CRT.scoreHighlightH, rowH)
  end
end

CRT.scoreDataPollInterval = 2.0
CRT.scoreDataPollElapsed = 0
CRT.cachedPlayerBGRow = nil

local function CRT_BonusHonorToRow(honorGained)
  honorGained = tonumber(honorGained) or 0
  if honorGained == 1 then
    return 2 -- Horde row on this server
  end
  return 1 -- Alliance row on this server
end

local function CRT_GetPlayerBGRow()
  local myName = UnitName("player")
  if not myName or myName == "" then
    return CRT.cachedPlayerBGRow
  end
  myName = string.gsub(myName, "%-.*$", "")

  local nBF = GetNumBattlefieldScores() or 0
  local mine, sawMarker = nil, false
  for i = 1, nBF do
    local name, _, _, _, honorGained = GetBattlefieldScore(i)
    if name then
      if (tonumber(honorGained) or 0) == 1 then
        sawMarker = true
      end
      name = string.gsub(name, "%-.*$", "")
      if name == myName then
        mine = CRT_BonusHonorToRow(honorGained)
      end
    end
  end

  -- A battleground whose server side never sets the marker leaves the whole
  -- column at zero, which reads exactly like "everyone is on the Alliance
  -- row". Rather than paint the square on a row that may not be yours, wait
  -- until the column has proven it carries team data.
  if mine ~= nil and sawMarker then
    CRT.cachedPlayerBGRow = mine
  end

  return CRT.cachedPlayerBGRow
end

local function UpdateScoreHighlights()
  EnsureScoreHighlights()

  if CRT.scoreHighlightA then CRT.scoreHighlightA:Hide() end
  if CRT.scoreHighlightH then CRT.scoreHighlightH:Hide() end

  local cfg = CRT.scoreHighlightConfig or {}
  if cfg.enabled == false then return end

  -- The square marks which scoreboard team you are on, which is a question
  -- every battleground answers the same way. Whether it can be drawn is
  -- decided by the rows themselves: EnsureScoreHighlights only finds a row
  -- that carries an Alliance/Horde icon, so a battleground without those rows
  -- silently shows nothing.
  if not InPvPInstance() then return end

  local row = CRT_GetPlayerBGRow()
  if row == 1 then
    if CRT.scoreHighlightA then CRT.scoreHighlightA:Show() end
  elseif row == 2 then
    if CRT.scoreHighlightH then CRT.scoreHighlightH:Show() end
  end
end


-- ----- names (first + last) -----
-- Centurion characters have a family name, and the client knows every player
-- by the pair: UnitName, the raid roster and the scoreboard all say
-- "Elgrom Fernbloom". The server's CWSG flag messages only carry the first
-- name ("Elgrom"), so a carrier name has to be matched against the pair, and
-- /targetexact needs the pair or it matches nobody.

local function CRT_StripRealm(name)
  if not name then return nil end
  return (string.gsub(name, "%-.*$", ""))
end

local function CRT_FirstWord(name)
  return name and string.match(name, "^(%S+)") or nil
end

-- Same person? Exact match, or the same first name where one side has no
-- family name (the server's first-only name against the client's pair).
local function CRT_NamesMatch(a, b)
  a, b = CRT_StripRealm(a), CRT_StripRealm(b)
  if not a or not b or a == "" or b == "" then return false end
  if a == b then return true end
  local aHasLast = string.find(a, " ", 1, true) ~= nil
  local bHasLast = string.find(b, " ", 1, true) ~= nil
  if aHasLast and bHasLast then return false end
  return string.lower(CRT_FirstWord(a) or "") == string.lower(CRT_FirstWord(b) or "")
end

-- The full name the client knows for a first name, if exactly one player it can
-- see answers to it; otherwise the name unchanged (never a guess between two).
local function CRT_ResolveFullName(name)
  name = CRT_StripRealm(name)
  if not name or name == "" or string.find(name, " ", 1, true) then
    return name
  end

  local found, seen = nil, {}
  local function consider(candidate)
    candidate = CRT_StripRealm(candidate)
    if not candidate or seen[candidate] then return end
    seen[candidate] = true
    if candidate ~= name and CRT_NamesMatch(candidate, name) then
      if found and found ~= candidate then
        found = false -- two players share the first name
      elseif found == nil then
        found = candidate
      end
    end
  end

  consider(UnitName("player"))
  for i = 1, (GetNumRaidMembers() or 0) do
    consider(UnitName("raid" .. i))
  end
  for i = 1, (GetNumBattlefieldScores() or 0) do
    consider((GetBattlefieldScore(i)))
  end
  for _, unit in ipairs({ "target", "focus", "mouseover" }) do
    if UnitExists(unit) and UnitIsPlayer(unit) then
      consider(UnitName(unit))
    end
  end

  return found or name
end

-- ----- class color helpers -----
local CRT_CLASS_LOCALE_TO_TOKEN = {}
for token, loc in pairs(LOCALIZED_CLASS_NAMES_MALE or {}) do
  CRT_CLASS_LOCALE_TO_TOKEN[loc] = token
end
for token, loc in pairs(LOCALIZED_CLASS_NAMES_FEMALE or {}) do
  CRT_CLASS_LOCALE_TO_TOKEN[loc] = token
end

local function CRT_ClassColorForName(name)
  if not name or name == "" then return nil end
  name = name:gsub("%-.*$", "") -- strip realm if present

  local myName = UnitName("player")
  if myName then
    if CRT_NamesMatch(myName, name) then
      local _, classToken = UnitClass("player")
      if classToken and RAID_CLASS_COLORS[classToken] then
        return RAID_CLASS_COLORS[classToken]
      end
    end
  end

  local nRaid = GetNumRaidMembers() or 0
  for i = 1, nRaid do
    local unit = "raid" .. i
    local unitName = UnitName(unit)
    if unitName then
      if CRT_NamesMatch(unitName, name) then
        local _, classToken = UnitClass(unit)
        if classToken and RAID_CLASS_COLORS[classToken] then
          return RAID_CLASS_COLORS[classToken]
        end
      end
    end
  end

  for i = 1, nRaid do
    local n, _, _, _, _, classToken = GetRaidRosterInfo(i)
    if n then
      if CRT_NamesMatch(n, name) and classToken and RAID_CLASS_COLORS[classToken] then
        return RAID_CLASS_COLORS[classToken]
      end
    end
  end

  local nBF = GetNumBattlefieldScores() or 0
  for i = 1, nBF do
    local n, _, _, _, _, _, _, classLoc, classToken = GetBattlefieldScore(i)
    if n then
      if CRT_NamesMatch(n, name) then
        classToken = classToken or CRT_CLASS_LOCALE_TO_TOKEN[classLoc]
        if classToken and RAID_CLASS_COLORS[classToken] then
          return RAID_CLASS_COLORS[classToken]
        end
      end
    end
  end

  return nil
end

local function GetWSGWorldStateForSide(side)
  if not IsCTFBG() then return nil end

  local numUI = GetNumWorldStateUI and GetNumWorldStateUI() or 0
  for idx = 1, numUI do
    local uiType, state, text, icon, dynamicIcon, tooltip, dynamicTooltip =
      GetWorldStateUIInfo(idx)

    if CRT_RowSideFromIcon(icon) == side then
      return {
        state = state,
        hidden = nil,
        text = text,
        icon = icon,
        dynamicIcon = dynamicIcon,
        tooltip = tooltip,
        dynamicTooltip = dynamicTooltip,
        hasEnemyFlag = (state == 2),
      }
    end
  end

  -- Fallback for stock ordering while the row/icon cache is still settling.
  local idx = (side == "Alliance") and 1 or 2
  local uiType, state, text, icon, dynamicIcon, tooltip, dynamicTooltip =
    GetWorldStateUIInfo(idx)

  return {
    state = state,
    hidden = nil,
    text = text,
    icon = icon,
    dynamicIcon = dynamicIcon,
    tooltip = tooltip,
    dynamicTooltip = dynamicTooltip,
    hasEnemyFlag = (state == 2),
  }
end

local function SyncCarrierStateFromWorldState()
  if CRT.hasAuthoritativeWSG then
    return
  end

  local a = GetWSGWorldStateForSide("Alliance")
  local h = GetWSGWorldStateForSide("Horde")
  if a and not a.hasEnemyFlag then
    CRT.flagCarrier.Alliance = nil
  end
  if h and not h.hasEnemyFlag then
    CRT.flagCarrier.Horde = nil
  end
end

local function CRT_IsEnemyCarrierFlagSide(flagSide)
  local row = CRT_GetPlayerBGRow()
  if row == 1 then
    return flagSide == "Horde"
  elseif row == 2 then
    return flagSide == "Alliance"
  end
  return false
end

local function SetSecureTarget(btn, name, flagSide)
  if not btn then return end
  if not name or name == "" then
    -- Protected buttons cannot be hidden during combat.  Clear the unprotected
    -- font string immediately so a dropped/returned flag never leaves a stale
    -- carrier name on screen, then finish the protected cleanup after combat.
    btn.text:SetText("")
    btn._deferred = nil
    btn._widthDeferred = nil
    btn._showDeferred = nil
    if InCombatLockdown() then
      btn._hideDeferred = true
    else
      btn:SetAttribute("type", nil)
      btn:SetAttribute("macrotext", nil)
      btn._hideDeferred = nil
      btn:Hide()
    end
    return
  end

  btn._hideDeferred = nil
  -- The server names the carrier by first name only; show and target the pair.
  name = CRT_ResolveFullName(name)
  btn.text:SetText(name)
  local myName = UnitName("player")

  local col = CRT_ClassColorForName(name)
  if col then
    btn.text:SetTextColor(col.r, col.g, col.b)
  else
    if myName and CRT_NamesMatch(name, myName) then
      local c = NORMAL_FONT_COLOR or { r = 1, g = 0.82, b = 0 }
      btn.text:SetTextColor(c.r, c.g, c.b)
    elseif CRT_IsEnemyCarrierFlagSide(flagSide) then
      btn.text:SetTextColor(1, 0.1, 0.1)
    else
      local c = NORMAL_FONT_COLOR or { r = 1, g = 0.82, b = 0 }
      btn.text:SetTextColor(c.r, c.g, c.b)
    end
  end

  if InCombatLockdown() then
    btn._widthDeferred = btn.text:GetStringWidth() + 10
    btn._deferred = "/targetexact " .. name
    if not btn:IsShown() then
      btn._showDeferred = true
    end
  else
    btn:SetWidth(btn.text:GetStringWidth() + 10)
    btn:SetAttribute("type", "macro")
    btn:SetAttribute("macrotext", "/targetexact " .. name)
    btn._deferred = nil
    btn._widthDeferred = nil
    btn._showDeferred = nil
    btn:Show()
  end
end

local function FinishDeferred()
  if InCombatLockdown() then return end
  for _, b in pairs({ CRT.carrierA, CRT.carrierH }) do
    if b then
      if b._hideDeferred then
        b:SetAttribute("type", nil)
        b:SetAttribute("macrotext", nil)
        b._hideDeferred = nil
        b._widthDeferred = nil
        b._showDeferred = nil
        b:Hide()
      elseif b._deferred then
        if b._widthDeferred then
          b:SetWidth(b._widthDeferred)
          b._widthDeferred = nil
        end
        b:SetAttribute("type", "macro")
        b:SetAttribute("macrotext", b._deferred)
        b._deferred = nil
        if b._showDeferred then
          b._showDeferred = nil
          b:Show()
        end
      end
    end
  end
end

function CRT:UpdateCarrierLabels()
  UpdateScoreHighlights()

  if not IsCTFBG() then
    if CRT.carrierA then CRT.carrierA:Hide() end
    if CRT.carrierH then CRT.carrierH:Hide() end
    return
  end

  EnsureCarrierButtons()

  if CRT.carrierA then
    SetSecureTarget(CRT.carrierA, CRT.flagCarrier.Alliance, "Alliance")
  end
  if CRT.carrierH then
    SetSecureTarget(CRT.carrierH, CRT.flagCarrier.Horde, "Horde")
  end

  FinishDeferred()
end

-- =========================
-- Flag message patterns
-- =========================

-- Patterns (tolerate “flag”/“Flag”) with player names
local FLAG = {
  { side = "Horde", pats = {
      "The Alliance [Ff]lag was picked up by (.+)!",
      "Alliance [Ff]lag was picked up by (.+)!",
      "The Alliance [Ff]lag has been taken by (.+)!",
    }
  },
  { side = "Horde", reset = {
      "The Alliance [Ff]lag was dropped by (.+)!",
      "Alliance [Ff]lag was dropped by (.+)!",
      "The Alliance [Ff]lag was returned to its base by (.+)!",
      "Alliance [Ff]lag was returned to its base by (.+)!",
    }
  },
  { side = "Alliance", pats = {
      "The Horde [Ff]lag was picked up by (.+)!",
      "Horde [Ff]lag was picked up by (.+)!",
      "The Horde [Ff]lag has been taken by (.+)!",
    }
  },
  { side = "Alliance", reset = {
      "The Horde [Ff]lag was dropped by (.+)!",
      "Horde [Ff]lag was dropped by (.+)!",
      "The Horde [Ff]lag was returned to its base by (.+)!",
      "Horde [Ff]lag was returned to its base by (.+)!",
    }
  },
}

-- Capture messages (either side scores)
local CAP = {
  "captured the Alliance [Ff]lag!",
  "captured the Horde [Ff]lag!",
}

-- Auto drop / auto return messages (no player name given)
local AUTO = {
  -- Alliance flag (carried by Horde)
  { side = "Horde", pats = {
      "the alliance flag has returned to its base",
      "the alliance flag has been returned to its base",
      "the alliance flag was returned to its base",
      "the alliance flag was dropped",
    }
  },
  -- Horde flag (carried by Alliance)
  { side = "Alliance", pats = {
      "the horde flag has returned to its base",
      "the horde flag has been returned to its base",
      "the horde flag was returned to its base",
      "the horde flag was dropped",
    }
  },
}

local function ParseCarrier(msg)
  if not IsCTFBG() then return end
  if CRT.hasAuthoritativeWSG then return end
  if not msg or msg == "" then return end

  local raw = msg
  local m   = raw:lower()

  -- 1) Auto drop / auto return (no player name)
  for _, blk in ipairs(AUTO) do
    for _, pat in ipairs(blk.pats) do
      if m:find(pat, 1, true) then
        if blk.side == "Alliance" then
          CRT.flagCarrier.Alliance = nil
        else
          CRT.flagCarrier.Horde = nil
        end
        CRT:UpdateCarrierLabels()
        return
      end
    end
  end

  -- 2) Normal pickup / drop / manual return (with player name)
  for _, blk in ipairs(FLAG) do
    if blk.pats then
      for _, p in ipairs(blk.pats) do
        local who = raw:match(p)
        if who then
          if blk.side == "Alliance" then
            CRT.flagCarrier.Alliance = who
          else
            CRT.flagCarrier.Horde = who
          end
          CRT:UpdateCarrierLabels()
          return
        end
      end
    end
    if blk.reset then
      for _, p in ipairs(blk.reset) do
        if raw:match(p) then
          if blk.side == "Alliance" then
            CRT.flagCarrier.Alliance = nil
          else
            CRT.flagCarrier.Horde = nil
          end
          CRT:UpdateCarrierLabels()
          return
        end
      end
    end
  end

  -- 3) Capture messages (either flag scored)
  for _, p in ipairs(CAP) do
    if raw:match(p) then
      CRT.flagCarrier.Alliance, CRT.flagCarrier.Horde = nil, nil
      CRT:UpdateCarrierLabels()
      return
    end
  end
end

-- =========================
-- Aura-based FC detection
-- =========================

-- Find OUR FC (enemy flag on a raid member)
local function ScanOwnFlagCarrier()
  if not IsCTFBG() then return end
  if CRT.hasAuthoritativeWSG then return end

  local myFaction = UnitFactionGroup("player")
  if not myFaction then return end

  -- Enemy flag aura from my POV
  local enemyFlagName
  if myFaction == "Alliance" then
    enemyFlagName = GetSpellInfo("Horde Flag")
  else
    enemyFlagName = GetSpellInfo("Alliance Flag")
  end
  if not enemyFlagName then return end

  local side = (myFaction == "Alliance") and "Alliance" or "Horde"
  local num = GetNumRaidMembers() or 0
  local found

  for i = 1, num do
    local unit = "raid" .. i
    if UnitExists(unit) then
      for j = 1, 40 do
        local name = UnitBuff(unit, j)
        if not name then break end
        if name == enemyFlagName then
          found = UnitName(unit)
          break
        end
      end
      if found then break end
    end
  end

  if found then
    CRT.flagCarrier[side] = found
  else
    local ws = GetWSGWorldStateForSide(side)
    if not ws or not ws.hasEnemyFlag then
      CRT.flagCarrier[side] = nil
    end
  end

  CRT:UpdateCarrierLabels()
end

-- Find ENEMY FC from units we actually "see" (target/focus/mouseover)
local function ScanUnitForFlag(unit)
  if not UnitExists(unit) then return nil end

  local myFaction = UnitFactionGroup("player")
  if not myFaction then return nil end

  -- My own flag aura from my POV
  local myFlagName
  if myFaction == "Alliance" then
    myFlagName = GetSpellInfo("Alliance Flag")
  else
    myFlagName = GetSpellInfo("Horde Flag")
  end
  if not myFlagName then return nil end

  for i = 1, 40 do
    local name = UnitBuff(unit, i)
    if not name then break end
    if name == myFlagName then
      return UnitName(unit)
    end
  end
  return nil
end

local function ScanVisibleForEnemyFC()
  if not IsCTFBG() then return end
  if CRT.hasAuthoritativeWSG then return end

  local myFaction = UnitFactionGroup("player")
  if not myFaction then return end

  local side = (myFaction == "Alliance") and "Horde" or "Alliance"
  local name = ScanUnitForFlag("target")
            or ScanUnitForFlag("focus")
            or ScanUnitForFlag("mouseover")

  if name then
    CRT.flagCarrier[side] = name
  else
    local ws = GetWSGWorldStateForSide(side)
    if not ws or not ws.hasEnemyFlag then
      CRT.flagCarrier[side] = nil
    end
  end

  CRT:UpdateCarrierLabels()
end

-- =========================
-- Rez Timer Core
-- =========================
local function CurrentDeadCount()
  local inBG = InBG()
  if not inBG then return 0 end
  local c, n = 0, GetNumRaidMembers() or 0
  for i = 1, n do
    if UnitIsDeadOrGhost("raid" .. i) then
      c = c + 1
    end
  end
  return c
end

local function CRT_LowestAlwaysUpRow()
  local lowest, lowestBottom = nil, nil
  for i = 1, 5 do
    local frame = _G["AlwaysUpFrame" .. i]
    if frame and frame:IsShown() then
      local b = frame:GetBottom()
      if b and (not lowestBottom or b < lowestBottom) then
        lowest, lowestBottom = frame, b
      end
    end
  end
  return lowest
end

function CRT.UpdatePosition(self)
  local _, bg = InBG()
  local base = CRT.defaultpos[bg or ""] or { x = 0, y = -80 }
  local userY = CRT.userYOffset or 0

  CRT:ClearAllPoints()

  -- Hang the timer off the last score row instead of off the top of the
  -- screen. A fixed screen offset cannot know how many rows a battleground
  -- draws or how tall they are, which is why the timer sat on top of the
  -- second row in Arathi Basin and the Scarlet Chapel while looking right in
  -- Warsong Gulch.
  local lastRow = CRT_LowestAlwaysUpRow()
  if lastRow then
    CRT:SetPoint("TOP", lastRow, "BOTTOM", base.x or 0, (CRT.timerGapBelowRows or -10) + userY)
    return
  end

  CRT:SetPoint("TOP", UIParent, "TOP", base.x or 0, base.y + userY)
end

function CRT.SeedFromSpiritHealer(self)
  local inBG = InBG()
  if not inBG then return end
  local t = GetAreaSpiritHealerTime()
  if t and t > 0 then
    local sub = GetSubZoneText()
    if sub and sub ~= "" then
      CRT.timeleft[sub] = t
    end
  end
end

local function ResetLocalSHState()
  CRT.localSHSub           = nil
  CRT.localSHRawLast       = nil
  CRT.localSHDisplayLast   = nil
  CRT.localSHDisplayTarget = nil
  CRT.localSHDisplayDue    = 0
end

function CRT.Reset(self)
  wipe(CRT.timeleft)
  wipe(CRT.lastlost)
  wipe(CRT.reporting)
  CRT.lastdead = 0
  CRT.ResInterval = CRT.DefaultResInterval

  -- wipe flag carriers between games so names never leak across matches
  CRT.flagCarrier.Alliance = nil
  CRT.flagCarrier.Horde   = nil
  CRT.hasAuthoritativeWSG = false
  CRT.authoritativeState.A = nil
  CRT.authoritativeState.H = nil

  ResetLocalSHState()
  CRT.scoreDataPollElapsed = 0
  CRT.cachedPlayerBGRow = nil

  local inBG = InBG()
  if not inBG then
    CRT.timestr:SetText("")
    CRT:Hide()
    if CRT.carrierA then CRT.carrierA:Hide() end
    if CRT.carrierH then CRT.carrierH:Hide() end
    return
  end

  CRT:Show()
  CRT.UpdatePosition(self)
  CRT.SeedFromSpiritHealer(self)
  CRT:UpdateCarrierLabels()
  CRT_RequestWSGFull()
  CRT_RequestCustomGameRules()
end

function CRT.OnUpdate(self, elapsed)
  CRT.TimeSinceLastUpdate = CRT.TimeSinceLastUpdate + elapsed

  local inBG, bgName = InBG()
  local inPvPInstance = InPvPInstance()
  if not inBG and not inPvPInstance then
    CRT.timestr:SetText("")
    CRT.timestr:Hide()
    return
  end

  if CRT.TimeSinceLastUpdate < CRT.UpdateInterval then
    return
  end

  local step = CRT.TimeSinceLastUpdate  -- actual accumulated time since last tick
  CRT.TimeSinceLastUpdate = 0

  -- The team square rides the battlefield scoreboard, so it is kept fed in
  -- every battleground rather than only the CTF ones. This runs before the
  -- rez-timer work below so it also reaches battlegrounds that are not in
  -- CRT.bgNames at all.
  if inPvPInstance then
    CRT.scoreDataPollElapsed = (CRT.scoreDataPollElapsed or 0) + step
    if CRT.scoreDataPollElapsed >= (CRT.scoreDataPollInterval or 2.0) then
      CRT.scoreDataPollElapsed = 0
      if RequestBattlefieldScoreData then
        RequestBattlefieldScoreData()
      end
    end
    UpdateScoreHighlights()
  end

  if not inBG then
    CRT.timestr:SetText("")
    CRT.timestr:Hide()
    return
  end

  if CRT.ctfNames[bgName] then
    -- Make flag state self-heal even if a chat event is missed.
    SyncCarrierStateFromWorldState()
    ScanOwnFlagCarrier()
    ScanVisibleForEnemyFC()
  end

  local currentdead = CurrentDeadCount()

  -- Tick all existing timers forward by the real elapsed time
  for k, v in pairs(CRT.timeleft) do
    if (CRT.lastdead - currentdead) > 1 and v > 1 and v < (CRT.ResInterval - 1) then
      CRT.timeleft[k] = CRT.ResInterval - 2
    else
      CRT.timeleft[k] = v - step
    end

    -- Wrap to the next wave once we're confidently past this one
    if CRT.timeleft[k] <= -CRT.ExtraNowSeconds then
      CRT.timeleft[k] = CRT.ResInterval + CRT.timeleft[k]
    end
  end

  CRT.lastdead = currentdead

  local now = GetTime()

  -- Spirit Healer sync + smoothing
  CRT.localSHSub = nil
  if UnitIsGhost("player") then
    local t = GetAreaSpiritHealerTime()
    if t and t > 0 then
      local sub = GetSubZoneText()
      if sub and sub ~= "" then
        CRT.localSHSub = sub
        CRT.timeleft[sub] = t  -- keep internal model roughly in sync

        if CRT.localSHRawLast == nil then
          -- First time we see this timer
          CRT.localSHRawLast       = t
          CRT.localSHDisplayLast   = t
          CRT.localSHDisplayTarget = nil
          CRT.localSHDisplayDue    = now
        else
          if t ~= CRT.localSHRawLast then
            -- Raw timer integer changed; schedule display to catch up after a small delay
            CRT.localSHRawLast       = t
            CRT.localSHDisplayTarget = t
            CRT.localSHDisplayDue    = now + (CRT.localSHDelay or 0.4)
          end
        end
      end
    end
  else
    -- Leaving ghost state; keep last display for that GY until timers naturally advance
    CRT.localSHRawLast       = nil
    CRT.localSHDisplayTarget = nil
    CRT.localSHDisplayDue    = 0
  end

  -- If scheduled, advance smoothed SH display once the delay has elapsed
  if CRT.localSHDisplayTarget and now >= CRT.localSHDisplayDue then
    CRT.localSHDisplayLast = CRT.localSHDisplayTarget
    CRT.localSHDisplayTarget = nil
  end

  -- Build lines:
  --   - local SH GY (while ghost) uses smoothed GetAreaSpiritHealerTime()
  --   - other GYs use ceil() of internal timer
  local names = CRT.prettynames[bgName] or {}
  local lines = {}

  for gy, val in pairs(CRT.timeleft) do
    local pretty = names[gy] or gy
    local secs

    if CRT.localSHSub and gy == CRT.localSHSub and CRT.localSHDisplayLast then
      -- Local graveyard while ghost: show smoothed SH timer
      secs = CRT.localSHDisplayLast
    else
      local v = (val or 0)
      if v <= 0 then
        secs = 0
      else
        secs = math.ceil(v)
      end
    end

    if secs <= 1 then
      table.insert(lines, string.format("%s Now", pretty))
    else
      table.insert(lines, string.format("%s in %d", pretty, secs))
    end
  end

  table.sort(lines)
  CRT.timestr:SetText(table.concat(lines, "\n"))
  if #lines > 0 then
    CRT.timestr:Show()
  else
    CRT.timestr:Hide()
  end
end

-- =========================
-- Chat / Events
-- =========================
local function HandleBGMsg(event, msg, sender)
  ParseCarrier(msg)

  local inBG, bgName = InBG()
  if not inBG then return end
  local names = CRT.prettynames[bgName]
  if not names then return end

  local faction = UnitFactionGroup("player")
  local who = (event == "CHAT_MSG_BG_SYSTEM_ALLIANCE" and "Alliance")
           or (event == "CHAT_MSG_BG_SYSTEM_HORDE"   and "Horde")
           or nil

  local m = string.lower(msg or "")
  local lost  = m:find("has assaulted") or m:find("is under attack")
  local taken = m:find("has taken") or m:find("was taken") or m:find("has defended")

  for key, pretty in pairs(names) do
    if m:find(string.lower(key)) then
      if taken and (who == nil or who == faction) then
        CRT.timeleft[pretty] = CRT.ResInterval + 2
      elseif lost and who ~= nil and who ~= faction then
        CRT.timeleft[pretty] = nil
        CRT.lastlost[pretty] = GetTime()
      end
      break
    end
  end
end

function CRT.OnEvent(self, event, ...)
  if event == "CHAT_MSG_ADDON" then
    local prefix, msg = select(1, ...), select(2, ...)
    if type(prefix) == "string" and type(msg) == "string" then
      CRT_ParseAuthoritativeWSG(prefix, msg)
      CRT_ApplyCustomGameRules(prefix, msg)
    elseif type(prefix) == "string" then
      local pfx, payload = string.match(prefix, "^(CWSG)\t(.+)$")
      if pfx and payload then
        CRT_ParseAuthoritativeWSG(pfx, payload)
      end
      local rulesPrefix, rulesPayload = string.match(prefix, "^(CCGAME)\t(.+)$")
      if rulesPrefix and rulesPayload then
        CRT_ApplyCustomGameRules(rulesPrefix, rulesPayload)
      end
    end

  elseif event == "CHAT_MSG_BG_SYSTEM_NEUTRAL" then
    local msg = select(1, ...)
    HandleBGMsg(event, msg, select(2, ...))
    CRT_RequestWSGFull()
    local off = CRT.startText[msg]
    if off then
      for k, _ in pairs(CRT.timeleft) do
        CRT.timeleft[k] = CRT.ResInterval + off
      end
    end

  elseif event == "CHAT_MSG_BG_SYSTEM_ALLIANCE"
      or event == "CHAT_MSG_BG_SYSTEM_HORDE"
      or event == "CHAT_MSG_MONSTER_YELL" then

    local msg, sender = select(1, ...), select(2, ...)
    if event == "CHAT_MSG_MONSTER_YELL" and sender ~= "Herald" then return end
    HandleBGMsg(event, msg, sender)
    CRT_RequestWSGFull()

  elseif event == "UPDATE_WORLD_STATES" then
    EnsureCarrierButtons()
    CRT:UpdateCarrierLabels()
    -- The score rows do not exist yet when we first zone in, and they are
    -- rebuilt whenever the worldstate UI changes, so re-hang the timer off
    -- whatever row is now last.
    CRT.UpdatePosition(self)
    if not CRT.hasAuthoritativeWSG then
      CRT_RequestWSGFull()
    end

  elseif event == "PLAYER_REGEN_ENABLED" then
    FinishDeferred()

  elseif event == "UPDATE_BATTLEFIELD_SCORE"
      or event == "RAID_ROSTER_UPDATE" then
    if not CRT.hasAuthoritativeWSG then
      SyncCarrierStateFromWorldState()
      ScanOwnFlagCarrier()
      ScanVisibleForEnemyFC()
    elseif (CRT.flagCarrier.Alliance == nil and CRT.authoritativeState.H == "PLAYER")
        or (CRT.flagCarrier.Horde == nil and CRT.authoritativeState.A == "PLAYER") then
      CRT_RequestWSGFull()
    end
    CRT:UpdateCarrierLabels()

  elseif event == "UNIT_AURA" then
    if not CRT.hasAuthoritativeWSG then
      local unit = select(1, ...)
      if unit then
        if unit:match("^raid%d+$") then
          ScanOwnFlagCarrier()
        elseif unit == "target" or unit == "focus" or unit == "mouseover" then
          ScanVisibleForEnemyFC()
        end
      end
      SyncCarrierStateFromWorldState()
    end
    CRT:UpdateCarrierLabels()

  elseif event == "PLAYER_TARGET_CHANGED"
      or event == "PLAYER_FOCUS_CHANGED"
      or event == "UPDATE_MOUSEOVER_UNIT" then
    if not CRT.hasAuthoritativeWSG then
      ScanVisibleForEnemyFC()
    end

  elseif event == "ZONE_CHANGED_NEW_AREA"
      or event == "PLAYER_ENTERING_WORLD" then
    CRT.Reset(self)
    EnsureCarrierButtons()
    SyncCarrierStateFromWorldState()
    ScanOwnFlagCarrier()
    ScanVisibleForEnemyFC()
    CRT:UpdateCarrierLabels()
    CRT_RequestWSGFull()
    CRT_RequestCustomGameRules()

  elseif event == "ADDON_LOADED" then
    local name = select(1, ...)
    if name == ADDON_NAME or name == "ClassicResTimers" or name == "ClassicResTimers_335" then
      CRT.Reset(self)
      EnsureCarrierButtons()
      SyncCarrierStateFromWorldState()
      ScanOwnFlagCarrier()
      CRT:UpdateCarrierLabels()
      CRT_RequestWSGFull()
      CRT_RequestCustomGameRules()
    end
  end
end

-- =========================
-- Slash: /crt, /crt fc, /crt y <pixels>
-- =========================
function CRT.Slash(self, ...)
  local a = tostring((select(1, ...) or "")):lower()

  if a == "fc" then
    DEFAULT_CHAT_FRAME:AddMessage(string.format(
      "|cff00ff88[CRT]|r Alliance FC: %s | Horde FC: %s",
      tostring(CRT.flagCarrier.Alliance or "-"),
      tostring(CRT.flagCarrier.Horde   or "-")
    ))
    return
  end

  if a == "y" then
    local yval = tonumber(select(2, ...))
    if yval then
      CRT.userYOffset = yval
      CRT.UpdatePosition(self)
      DEFAULT_CHAT_FRAME:AddMessage("|cff00ff88[CRT]|r y-offset set to " .. yval .. " (drag frame or /crt y <pixels>)")
    else
      DEFAULT_CHAT_FRAME:AddMessage("|cff00ff88[CRT]|r Usage: /crt y <pixels>  (positive = down, negative = up)")
    end
    return
  end

  if a == "rows" then
    -- Dumps what the stock worldstate frame actually laid out, so the team
    -- square can be sized against real numbers instead of guessed ones.
    local function num(v) return v and tostring(math.floor(v)) or "nil" end
    local function texState(label, tex)
      if not tex then
        DEFAULT_CHAT_FRAME:AddMessage("  " .. label .. " square: none")
        return
      end
      DEFAULT_CHAT_FRAME:AddMessage(string.format(
        "  %s square: %s size=%sx%s row=%s", label,
        tex:IsShown() and "SHOWN" or "hidden",
        num(tex:GetWidth()), num(tex:GetHeight()),
        tex._row and tostring(tex._row:GetName()) or "nil"))
    end

    DEFAULT_CHAT_FRAME:AddMessage(string.format(
      "|cff00ff88[CRT]|r player row=%s (1=Alliance 2=Horde), scores=%d",
      tostring(CRT.cachedPlayerBGRow), GetNumBattlefieldScores() or 0))
    texState("Alliance", CRT.scoreHighlightA)
    texState("Horde", CRT.scoreHighlightH)
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ff88[CRT]|r always-up rows:")
    for i = 1, 5 do
      local f = _G["AlwaysUpFrame" .. i]
      if f then
        DEFAULT_CHAT_FRAME:AddMessage(string.format(
          "  row%d %s x=%s..%s y=%s..%s", i, f:IsShown() and "shown" or "hidden",
          num(f:GetLeft()), num(f:GetRight()), num(f:GetBottom()), num(f:GetTop())))
        for _, part in ipairs({ "Icon", "Text", "DynamicIconButton" }) do
          local reg = _G["AlwaysUpFrame" .. i .. part]
          if not reg then
            DEFAULT_CHAT_FRAME:AddMessage("    " .. part .. " = MISSING")
          else
            local extra = ""
            if part == "Text" and reg.GetText then
              extra = " '" .. tostring(reg:GetText()) .. "'"
            elseif part == "Icon" and reg.GetTexture then
              extra = " " .. tostring(reg:GetTexture())
            end
            DEFAULT_CHAT_FRAME:AddMessage(string.format(
              "    %-17s %s x=%s..%s y=%s..%s%s", part,
              (reg.IsShown and reg:IsShown()) and "shown" or "hidden",
              num(reg:GetLeft()), num(reg:GetRight()),
              num(reg:GetBottom()), num(reg:GetTop()), extra))
          end
        end
      end
    end
    return
  end

  CRT.Reset(self)
  DEFAULT_CHAT_FRAME:AddMessage("|cff00ff88[CRT]|r reset (tip: /crt y <pixels>, /crt rows, /crt fc)")
end

SlashCmdList["ClassicResTimer"] = function(_, ...) CRT.Slash(CRT, ...) end
SLASH_ClassicResTimer1 = "/crt"

-- Wire
CRT:SetScript("OnEvent", CRT.OnEvent)
CRT:SetScript("OnUpdate", CRT.OnUpdate)

CRT:RegisterEvent("CHAT_MSG_BG_SYSTEM_NEUTRAL")
CRT:RegisterEvent("CHAT_MSG_BG_SYSTEM_ALLIANCE")
CRT:RegisterEvent("CHAT_MSG_BG_SYSTEM_HORDE")
CRT:RegisterEvent("CHAT_MSG_MONSTER_YELL")
CRT:RegisterEvent("UPDATE_WORLD_STATES")
CRT:RegisterEvent("PLAYER_REGEN_ENABLED")
CRT:RegisterEvent("UPDATE_BATTLEFIELD_SCORE")
CRT:RegisterEvent("RAID_ROSTER_UPDATE")
CRT:RegisterEvent("UNIT_AURA")
CRT:RegisterEvent("ZONE_CHANGED_NEW_AREA")
CRT:RegisterEvent("PLAYER_ENTERING_WORLD")
CRT:RegisterEvent("ADDON_LOADED")
CRT:RegisterEvent("PLAYER_TARGET_CHANGED")
CRT:RegisterEvent("PLAYER_FOCUS_CHANGED")
CRT:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
CRT:RegisterEvent("CHAT_MSG_ADDON")
